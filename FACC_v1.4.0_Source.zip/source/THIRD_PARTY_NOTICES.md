# FACC 第三方组件说明

FACC 1.1.0 · 作者 qianghw · qianghw@foxmail.com

FACC 包含 Python、NumPy、SciPy、scikit-image、Pillow、tifffile、PySide6 Essentials / Qt、Shiboken、imageio、NetworkX、lazy-loader、packaging 和 Noto Sans SC 字体。PyInstaller 用于生成 Windows 程序。第三方组件的版权属于各自作者。

随源码提供的 `ThirdPartyLicenses/` 保存了构建环境中这些组件附带的许可证文件与发行元数据；字体的 SIL Open Font License 在 `assets/fonts/OFL.txt` 中。程序包中的相应文件位于 `_internal/ThirdPartyLicenses/` 和 `_internal/assets/fonts/`。`components.json` 列出了收集时的组件版本。

PySide6 Essentials 6.11.2 与 Shiboken 的发行元数据标记为 LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only，并附带 Qt 商业许可说明文件。保留该文件不代表已购买 Qt 商业授权。本软件使用独立、动态加载的 Qt DLL；没有修改 Qt / PySide6 的源代码，也没有限制为调试 Qt 修改而替换兼容组件或重新构建本应用。

Qt / PySide6 的官方许可与源码入口：

- https://doc.qt.io/qt-6/licensing.html
- https://doc.qt.io/qtforpython-6/commercial/index.html
- https://download.qt.io/official_releases/QtForPython/pyside6-essentials/
- https://download.qt.io/official_releases/qt/6.11/6.11.2/single/
- https://www.gnu.org/licenses/lgpl-3.0.html
- https://www.gnu.org/licenses/gpl-3.0.html

本次交付保留了本地依赖所附的许可文本，并从 GNU 官方网站补充取得 LGPL v3 与 GPL v3 全文，保存在 `ThirdPartyLicenses/GNU/`。程序包中的对应位置为 `_internal/ThirdPartyLicenses/GNU/`。补充文本的官方来源及文件校验值与程序包一同保存。

FACC 源码和构建文件已一并交付给 qianghw；未替作者选定或发布 FACC 自身的开源许可证。
