import csv
import io
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
import numpy as np
from facc.image_io import from_array
from facc.models import Candidate, CountResult, Parameters
from facc.intensity import pack_roi, unpack_roi, original_roi, measure_candidates, validate_rois
from facc.storage import save_project, load_project, export_bundle


class IntensityTests(unittest.TestCase):
    def example(self):
        raw = np.full((12, 12), 50000, np.uint16)
        raw[4:7, 4:7] = np.arange(1, 10).reshape(3, 3)*1000
        c = Candidate(1, 5, 5, roi={'interior': pack_roi(np.ones((3, 3), bool), 4, 4)})
        result = CountResult([c], Parameters(boundary_width=1), {'channel': 'gray'})
        return from_array(raw), result

    def test_original_16bit_values_and_known_statistics(self):
        image, result = self.example(); measure_candidates(image, result)
        inner, band = result.candidates[0].intensity['measurements']
        self.assertEqual(inner['pixel_count'], 9); self.assertEqual(inner['mean'], 5000)
        self.assertEqual(inner['median'], 5000); self.assertEqual(inner['sum'], 45000)
        self.assertEqual(inner['min'], 1000); self.assertEqual(inner['max'], 9000)
        self.assertAlmostEqual(inner['std'], np.std(np.arange(1,10)*1000))
        self.assertEqual(band['pixel_count'], 12); self.assertEqual(band['mean'], 50000)
        self.assertEqual(band['sum'], 600000)

    def test_boundary_excludes_neighbor_and_is_saved(self):
        image, result = self.example()
        result.candidates.append(Candidate(2, 7, 5, roi={'interior':pack_roi(np.ones((3,1),bool),7,4)}))
        measure_candidates(image,result)
        first = result.candidates[0]
        self.assertEqual(first.intensity['measurements'][1]['pixel_count'],9)
        roi_before = dict(first.roi)
        result.candidates.pop(); first.x=0; first.y=0; result.renumber()
        self.assertEqual(first.roi,roi_before)
        self.assertEqual(first.intensity['measurements'][0]['mean'],5000)

    def test_measurement_channel_is_independent(self):
        image, result = self.example()
        rgb = np.stack([image.raw, image.raw//10, image.raw//100], axis=-1)
        result.parameters.intensity_channel='all'; result.parameters.intensity_regions='interior'
        measure_candidates(from_array(rgb),result)
        ms=result.candidates[0].intensity['measurements']
        self.assertEqual([m['mean'] for m in ms],[5000,500,50])
        result.parameters.intensity_channel='green'
        measure_candidates(from_array(rgb),result)
        self.assertEqual(result.candidates[0].intensity['measurements'][0]['mean'],500)

    def test_original_resolution_roi_mapping(self):
        mask=np.array([[1,0],[1,1]],bool)
        roi=original_roi(mask,(1,2,3,4),12,10,.5,.5)
        mapped,x,y=unpack_roi(roi)
        self.assertEqual((x,y),(4,2))
        np.testing.assert_array_equal(mapped,np.repeat(np.repeat(mask,2,axis=0),2,axis=1))

    def test_missing_roi_exports_blank_not_zero(self):
        with tempfile.TemporaryDirectory() as folder:
            result=CountResult([Candidate(1,5,5,origin='manual'),Candidate(2,8,8)],Parameters())
            target=Path(export_bundle(from_array(np.zeros((20,20),np.uint8)),result,folder))
            with (target/'fluorescence.csv').open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
            self.assertEqual(rows[0]['测量状态'],'人工编号无区域'); self.assertEqual(rows[1]['测量状态'],'旧项目无区域')
            self.assertEqual(rows[0]['均值'],''); self.assertEqual(rows[1]['积分强度'],'')

    def test_project_v4_retains_exact_rois_and_measurements(self):
        with tempfile.TemporaryDirectory() as folder:
            image,result=self.example(); measure_candidates(image,result)
            path=Path(folder)/'强度项目.facc'; save_project(path,image,result)
            loaded,restored=load_project(path)
            self.assertEqual(restored.candidates[0].to_dict(),result.candidates[0].to_dict())
            with zipfile.ZipFile(path) as z: self.assertEqual(json.loads(z.read('project.json'))['format_version'],4)

    def test_v1_project_backward_compatibility(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'v1.facc'; data=io.BytesIO(); np.save(data,np.zeros((20,20),np.uint8),allow_pickle=False)
            doc={'format':'facc-project','format_version':1,'image_name':'old.tif','parameters':{},'candidates':[{'id':7,'x':5,'y':5,'note':'原有人工复核','state':'confirmed'}]}
            with zipfile.ZipFile(path,'w') as z: z.writestr('project.json',json.dumps(doc)); z.writestr('raw.npy',data.getvalue())
            image,result=load_project(path)
            self.assertEqual(result.candidates[0].id,7); self.assertEqual(result.candidates[0].state,'confirmed')
            self.assertEqual(result.candidates[0].intensity,{})

    def test_roi_and_parameter_validation(self):
        image,result=self.example()
        result.candidates[0].roi['interior']['x']=99
        with self.assertRaises(ValueError): validate_rois(result.candidates[0],image)
        with self.assertRaises(ValueError): Parameters(boundary_width=0).validate()
        with self.assertRaises(ValueError): Parameters(intensity_channel='invalid').validate()


if __name__ == '__main__': unittest.main()
