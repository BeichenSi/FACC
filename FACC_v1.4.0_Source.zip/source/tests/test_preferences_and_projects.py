from dataclasses import asdict
import io
import json
from pathlib import Path
import tempfile
from threading import Event
import unittest
from unittest.mock import patch
import zipfile
import numpy as np
from facc.preferences import load_defaults, save_defaults
from facc.models import Parameters, Candidate, CountResult
from facc.image_io import from_array
from facc.storage import load_project, save_project, export_bundle, annotated_image
from facc.project_io import check_memory
from facc.engine import Cancelled
from PIL import Image


class DefaultsTests(unittest.TestCase):
    def test_all_defaults_roundtrip_and_missing_file(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'默认参数.json';self.assertEqual(load_defaults(path),Parameters())
            p=Parameters(min_area=173,max_area=9200,channel='red',central_enabled=True,recovery_enabled=True,
                         intensity_channel='all',recovery_threshold=27,recovery_min_coverage=.75,nucleus_margin=2.5)
            save_defaults(p,path);self.assertEqual(asdict(load_defaults(path)),asdict(p))

    def test_invalid_save_does_not_replace_previous_defaults(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'defaults.json';save_defaults(Parameters(min_area=151),path);before=path.read_bytes()
            with self.assertRaises(ValueError):save_defaults(Parameters(min_area=7000,max_area=100),path)
            self.assertEqual(path.read_bytes(),before)
            with patch('facc.preferences.os.replace',side_effect=OSError('read only')):
                with self.assertRaises(OSError):save_defaults(Parameters(),path)
            self.assertEqual(path.read_bytes(),before)
            self.assertEqual(list(path.parent.glob('.defaults_*')),[])

    def test_invalid_default_file_kept_and_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'defaults.json';save_defaults(Parameters(),path)
            doc=json.loads(path.read_text(encoding='utf8'));doc['parameters']['central_enabled']='false'
            path.write_text(json.dumps(doc),encoding='utf8');before=path.read_bytes()
            with self.assertRaisesRegex(ValueError,'默认参数'):load_defaults(path)
            self.assertEqual(path.read_bytes(),before)


class ProjectIOTests(unittest.TestCase):
    def make_legacy(self,path,raw=None,padding=0):
        raw=np.arange(600,dtype=np.uint16).reshape(20,30) if raw is None else raw
        doc={'format':'facc-project','format_version':4,'image_name':'large_legacy.tif','parameters':{},
             'candidates':[Candidate(3,5,7,'confirmed',note='已人工检查').to_dict()]}
        buf=io.BytesIO();np.save(buf,raw,allow_pickle=True)
        with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=1) as archive:
            archive.writestr('project.json',json.dumps(doc).encode()+b' ' * padding)
            archive.writestr('raw.npy',buf.getvalue())
        return raw,doc

    def test_legacy_record_over_sixty_megabytes(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'large.facc';raw,doc=self.make_legacy(path,padding=60_000_010)
            events=[]
            with patch('facc.project_io.available_memory',return_value=8*1024**3):
                image,result=load_project(path,lambda n,s:events.append(n))
            self.assertTrue(np.array_equal(image.raw,raw));self.assertEqual(result.candidates[0].to_dict(),doc['candidates'][0])
            self.assertEqual(events,sorted(events));self.assertEqual(events[-1],100)

    def test_memory_failure_reports_available_memory(self):
        with patch('facc.project_io.available_memory',return_value=256*1024**2):
            with self.assertRaisesRegex(ValueError,'当前内存不足'):check_memory(90_000_000,40_000_000)

    def test_cancel_before_read_and_during_raw(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'cancel.facc';self.make_legacy(path);event=Event();event.set()
            with self.assertRaises(Cancelled):load_project(path,cancel=event)
            event.clear()
            with self.assertRaises(Cancelled):load_project(path,lambda n,s:event.set() if n>=35 else None,event)

    def test_object_array_and_truncated_raw_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'object.facc';self.make_legacy(path,raw=np.array([[{'invalid':'object'}]],dtype=object))
            with self.assertRaisesRegex(ValueError,'数值像素'):load_project(path)
            valid=Path(folder)/'valid.facc';self.make_legacy(valid)
            with zipfile.ZipFile(valid) as archive:
                doc=archive.read('project.json');pixels=archive.read('raw.npy')
            with zipfile.ZipFile(path,'w') as archive:
                archive.writestr('project.json',doc);archive.writestr('raw.npy',pixels[:-2])
            with self.assertRaisesRegex(ValueError,'长度'):load_project(path)

    def test_compact_project_preserves_fortran_16bit_and_overrides(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'fortran.facc';raw,doc=self.make_legacy(path,np.asfortranarray(np.arange(600,dtype=np.uint16).reshape(20,30)))
            image,result=load_project(path);result.candidates[0].recovery={'auto_status':'negative','override':'positive'}
            result.edited=True;target=Path(folder)/'saved.facc';save_project(target,image,result)
            loaded,restored=load_project(target)
            self.assertTrue(np.array_equal(loaded.raw,raw));self.assertTrue(restored.edited)
            self.assertEqual(restored.candidates[0].recovery,result.candidates[0].recovery)
            with zipfile.ZipFile(target) as archive:self.assertNotIn(b'\n  ',archive.read('project.json'))

    def test_export_lossless_and_does_not_mutate_results(self):
        raw=np.random.default_rng(18).integers(0,65535,(80,90),dtype=np.uint16)
        image=from_array(raw,'pixel_test.tif');result=CountResult([Candidate(8,25,35,'confirmed',note='人工记录')],Parameters())
        before=result.candidates[0].to_dict();expected=np.array(annotated_image(image,result))
        with tempfile.TemporaryDirectory() as folder:
            target=Path(export_bundle(image,result,folder))
            self.assertTrue(np.array_equal(expected,np.array(Image.open(target/'numbered.png'))))
            self.assertTrue(np.array_equal(expected,np.array(Image.open(target/'numbered.tif'))))
            restored,rr=load_project(target/'project.facc');self.assertTrue(np.array_equal(restored.raw,raw))
            self.assertEqual(rr.candidates[0].to_dict(),before)
            self.assertEqual(result.candidates[0].to_dict(),before)


if __name__=='__main__':unittest.main()
