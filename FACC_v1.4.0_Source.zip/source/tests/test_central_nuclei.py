"""Known-geometry checks for myofiber, rather than nucleus, counting."""
import csv
import io
import json
from pathlib import Path
import tempfile
import unittest
import zipfile

import numpy as np

from facc.central_nuclei import (
    central_summary, classify_central_nuclei, fiber_status, nuclear_plane,
)
from facc.demo import membrane_demo
from facc.engine import count_cells
from facc.image_io import from_array
from facc.intensity import pack_roi
from facc.models import Candidate, CountResult, Parameters
from facc.storage import export_bundle, load_project, resolved_nuclei, save_project


def rectangle(fid, x, y, width=40, height=40):
    mask = np.ones((height, width), bool)
    return Candidate(fid, x + width / 2, y + height / 2,
                     roi={'interior': pack_roi(mask, x, y)})


def blue_square(raw, x, y, half=3, value=220):
    raw[y-half:y+half+1, x-half:x+half+1, 2] = value


def classify(raw, candidates, **options):
    parameters = dict(central_enabled=True, nucleus_threshold=100,
                      nucleus_min_area=5, nucleus_max_area=300)
    parameters.update(options)
    image = from_array(raw)
    result = CountResult(candidates, Parameters(**parameters))
    classify_central_nuclei(image, result)
    return image, result


class CentralNucleiTests(unittest.TestCase):
    def test_multiple_internal_nuclei_count_one_fiber(self):
        raw = np.zeros((90, 130, 3), np.uint8)
        blue_square(raw, 23, 22)
        blue_square(raw, 38, 37)
        blue_square(raw, 61, 65)  # Outside either retained fiber.
        _, result = classify(raw, [rectangle(7, 10, 10), rectangle(9, 75, 10)])
        summary = central_summary(result)
        self.assertEqual(summary['total_fibers'], 2)
        self.assertEqual(summary['central_fibers'], 1)
        self.assertEqual(summary['noncentral_fibers'], 1)
        self.assertEqual(summary['ratio'], .5)
        self.assertEqual(len(result.candidates[0].central_nuclei['nuclei']), 2)
        self.assertEqual(result.metadata['central_nuclei']['detected_nuclei'], 3)
        self.assertEqual(sum(n['accepted_fiber_id'] is not None
                             for n in result.metadata['central_nuclei']['nuclei']), 2)

    def test_centroid_must_be_inside_even_with_low_overlap_requirement(self):
        raw = np.zeros((70, 70, 3), np.uint8)
        blue_square(raw, 9, 30, half=4)  # Some pixels inside; center outside x >= 10.
        _, result = classify(raw, [rectangle(1, 10, 10)], nucleus_overlap=.1)
        self.assertEqual(fiber_status(result.candidates[0]), 'negative')
        nucleus = result.metadata['central_nuclei']['nuclei'][0]
        self.assertEqual(nucleus['overlapping_fiber_ids'], [1])
        self.assertIsNone(nucleus['accepted_fiber_id'])

    def test_boundary_fraction_and_margin_exclude_peripheral_signal(self):
        raw = np.zeros((70, 70, 3), np.uint8)
        blue_square(raw, 10, 30)
        _, permissive = classify(raw, [rectangle(1, 10, 10)], nucleus_overlap=.5)
        _, overlap = classify(raw, [rectangle(1, 10, 10)], nucleus_overlap=.8)
        _, margin = classify(raw, [rectangle(1, 10, 10)], nucleus_margin=3)
        self.assertEqual(fiber_status(permissive.candidates[0]), 'positive')
        self.assertEqual(fiber_status(overlap.candidates[0]), 'negative')
        self.assertEqual(fiber_status(margin.candidates[0]), 'negative')
        self.assertTrue(overlap.candidates[0].central_nuclei['review_flags'])
        self.assertTrue(margin.candidates[0].central_nuclei['review_flags'])

    def test_margin_is_distance_from_own_fiber_even_when_rois_touch(self):
        raw = np.zeros((70, 110, 3), np.uint8)
        blue_square(raw, 49, 30, half=2)
        _, result = classify(raw, [rectangle(1, 10, 10), rectangle(2, 50, 10)],
                             nucleus_margin=3)
        self.assertEqual(central_summary(result)['central_fibers'], 0)
        self.assertIsNone(result.metadata['central_nuclei']['nuclei'][0]['accepted_fiber_id'])

    def test_nucleus_crossing_two_fibers_has_at_most_one_owner(self):
        raw = np.zeros((70, 110, 3), np.uint8)
        blue_square(raw, 49, 30, half=3)
        _, result = classify(raw, [rectangle(3, 10, 10), rectangle(6, 50, 10)])
        self.assertEqual(central_summary(result)['central_fibers'], 1)
        nuclei = [n for c in result.candidates for n in c.central_nuclei['nuclei']]
        self.assertEqual(len(nuclei), 1)
        self.assertEqual(nuclei[0]['accepted_fiber_id'], 3)
        self.assertTrue(all(c.central_nuclei['review_flags'] for c in result.candidates))

    def test_overlapping_fiber_interiors_are_not_arbitrarily_assigned(self):
        raw = np.zeros((80, 90, 3), np.uint8)
        blue_square(raw, 35, 30)
        _, result = classify(raw, [rectangle(1, 10, 10), rectangle(2, 30, 10)])
        self.assertEqual(central_summary(result)['central_fibers'], 0)
        self.assertIsNone(result.metadata['central_nuclei']['nuclei'][0]['accepted_fiber_id'])

    def test_magenta_spectrin_is_not_detected_as_dapi(self):
        raw = np.zeros((80, 110, 3), np.uint8)
        raw[12:45, 12:45, 0] = raw[12:45, 12:45, 2] = 220
        blue_square(raw, 85, 30)
        _, result = classify(raw, [rectangle(1, 10, 10), rectangle(2, 65, 10)])
        self.assertEqual([fiber_status(c) for c in result.candidates], ['negative', 'positive'])
        self.assertEqual(result.metadata['central_nuclei']['detected_nuclei'], 1)

    def test_16bit_merged_rgb_uses_a_shared_scale(self):
        raw = np.zeros((80, 100, 3), np.uint16)
        raw[5:30, 5:30, 0] = raw[5:30, 5:30, 2] = 12000
        raw[40:70, 5:30, 0] = raw[40:70, 5:30, 2] = 50000
        raw[20:50, 50:85, 2] = 42000
        image = from_array(raw)
        plane, details = nuclear_plane(image, 'blue_residual')
        self.assertEqual(plane[15, 15], 0)
        self.assertEqual(plane[55, 15], 0)
        self.assertGreater(plane[30, 60], 100)
        self.assertIn('shared RGB', details['normalization'])
        self.assertTrue(np.array_equal(image.raw, raw))

    def test_nuclear_area_limits_remove_speckle_and_oversized_aggregates(self):
        raw = np.zeros((90, 160, 3), np.uint8)
        blue_square(raw, 20, 25, half=0)  # Single-pixel speckle.
        blue_square(raw, 75, 25, half=3)  # Valid nucleus.
        blue_square(raw, 130, 25, half=10)  # Aggregate above the area limit.
        _, result = classify(raw, [rectangle(1, 5, 5), rectangle(2, 55, 5),
                                   rectangle(3, 110, 5)],
                             nucleus_threshold=40, nucleus_min_area=8,
                             nucleus_max_area=150)
        self.assertEqual([fiber_status(c) for c in result.candidates],
                         ['negative', 'positive', 'negative'])
        self.assertEqual(result.metadata['central_nuclei']['detected_nuclei'], 1)
        self.assertGreaterEqual(result.metadata['central_nuclei']['rejected_small'], 1)
        self.assertEqual(result.metadata['central_nuclei']['rejected_large'], 1)

    def test_absence_of_dapi_is_zero_positive_fibers(self):
        raw, _ = membrane_demo()
        result = count_cells(from_array(raw), Parameters(central_enabled=True,
                                                         largest_tissue=False))
        self.assertEqual(result.count, 12)
        summary = central_summary(result)
        self.assertEqual(summary['central_fibers'], 0)
        self.assertEqual(summary['ratio'], 0)
        self.assertTrue(summary['classification_complete'])
        self.assertEqual(result.metadata['central_nuclei']['detected_nuclei'], 0)

    def test_manual_without_roi_is_unclassified_and_denominator_is_retained(self):
        raw = np.zeros((70, 70, 3), np.uint8)
        blue_square(raw, 25, 25)
        _, result = classify(raw, [rectangle(1, 10, 10),
                                   Candidate(8, 60, 60, origin='manual')])
        summary = central_summary(result)
        self.assertEqual(fiber_status(result.candidates[1]), 'unclassified')
        self.assertEqual(summary['ratio'], .5)
        self.assertEqual(summary['unclassified_fibers'], 1)
        self.assertFalse(summary['classification_complete'])
        self.assertTrue(summary['ratio_is_lower_bound'])

    def test_manual_override_reset_delete_and_renumber_recompute_counts(self):
        raw = np.zeros((80, 130, 3), np.uint8)
        blue_square(raw, 95, 30)
        _, result = classify(raw, [rectangle(4, 10, 10), rectangle(8, 75, 10)])
        first, second = result.candidates
        first.central_nuclei['override'] = 'positive'
        self.assertEqual(central_summary(result)['central_fibers'], 2)
        first.central_nuclei['override'] = 'unclassified'
        self.assertTrue(central_summary(result)['ratio_is_lower_bound'])
        first.central_nuclei['override'] = None
        self.assertEqual(central_summary(result)['ratio'], .5)
        result.candidates.remove(first)
        result.renumber()
        self.assertEqual(central_summary(result)['ratio'], 1)
        self.assertEqual(resolved_nuclei(result)[0]['accepted_fiber_id'], 1)
        self.assertIs(result.candidates[0], second)
        result.candidates.clear()
        self.assertIsNone(central_summary(result)['ratio'])
        self.assertIsNone(resolved_nuclei(result)[0]['accepted_fiber_id'])

    def test_zero_denominator_has_no_numeric_ratio(self):
        summary = central_summary(CountResult([], Parameters(central_enabled=True)))
        self.assertEqual(summary['total_fibers'], 0)
        self.assertEqual(summary['central_fibers'], 0)
        self.assertIsNone(summary['ratio'])
        self.assertIsNone(summary['ratio_percent'])

    def test_central_analysis_requires_merge_and_forces_spectrin_segmentation(self):
        with self.assertRaises(ValueError):
            count_cells(from_array(np.zeros((80, 80), np.uint8)), Parameters(central_enabled=True))
        raw, centers = membrane_demo()
        raw = raw.copy()
        for x, y in centers[:2]:
            blue_square(raw, x, y)
        raw[20:80, 20:80, 1] = 250  # A bright green object must not set the denominator.
        params = Parameters(central_enabled=True, mode='bright', channel='green',
                            largest_tissue=False, nucleus_threshold=100)
        result = count_cells(from_array(raw), params)
        self.assertEqual(result.count, 12)
        self.assertEqual(central_summary(result)['central_fibers'], 2)
        self.assertEqual(result.parameters.mode, 'membrane')
        self.assertEqual(result.parameters.channel, 'red')
        self.assertEqual(result.metadata['channel'], 'red')
        self.assertEqual(params.mode, 'bright')  # The caller's preset is not mutated.
        self.assertEqual(params.channel, 'green')

    def test_project_and_csv_keep_final_fiber_classification_and_current_ids(self):
        raw = np.zeros((80, 130, 3), np.uint8)
        blue_square(raw, 95, 23)
        blue_square(raw, 100, 40)
        image, result = classify(raw, [rectangle(4, 10, 10), rectangle(8, 75, 10)])
        result.candidates[0].central_nuclei['override'] = 'positive'
        result.renumber()
        with tempfile.TemporaryDirectory() as folder:
            project = Path(folder) / 'central.facc'
            save_project(project, image, result)
            loaded_image, loaded = load_project(project)
            self.assertEqual([c.to_dict() for c in loaded.candidates],
                             [c.to_dict() for c in result.candidates])
            self.assertEqual(central_summary(loaded)['ratio'], 1)
            target = Path(export_bundle(loaded_image, loaded, folder))
            summary = json.loads((target / 'summary.json').read_text(encoding='utf-8'))
            self.assertEqual(summary['central_nucleation']['central_fibers'], 2)
            self.assertEqual(summary['central_nucleation']['ratio'], 1)
            with (target / 'central_fibers.csv').open(encoding='utf-8-sig', newline='') as handle:
                fibers = list(csv.DictReader(handle))
            with (target / 'nuclei.csv').open(encoding='utf-8-sig', newline='') as handle:
                nuclei = list(csv.DictReader(handle))
            self.assertEqual(len(fibers), 2)
            self.assertEqual([r['状态代码'] for r in fibers], ['positive', 'positive'])
            self.assertEqual([int(r['自动内部核数']) for r in fibers], [0, 2])
            self.assertEqual(len(nuclei), 2)
            self.assertEqual({r['当前归属肌纤维编号'] for r in nuclei}, {'2'})
            self.assertTrue((target / 'central_nucleation.png').is_file())
            self.assertFalse((target / 'EXPORT_INCOMPLETE.txt').exists())
            loaded.candidates.pop()
            changed_target = Path(export_bundle(loaded_image, loaded, folder))
            with (changed_target / 'nuclei.csv').open(encoding='utf-8-sig', newline='') as handle:
                detached = list(csv.DictReader(handle))
            self.assertEqual(len(detached), 2)
            self.assertEqual({r['当前归属肌纤维编号'] for r in detached}, {''})
            changed_summary = json.loads((changed_target / 'summary.json').read_text(encoding='utf-8'))
            self.assertEqual(changed_summary['central_nucleation']['total_fibers'], 1)
            self.assertTrue(all(n['accepted_fiber_id'] is None
                                for n in changed_summary['analysis']['central_nuclei']['nuclei']))

    def test_v2_project_retains_intensity_without_inventing_central_classification(self):
        raw = np.full((30, 30), 1234, np.uint16)
        roi = pack_roi(np.ones((3, 3), bool), 10, 10)
        intensity = {'status': 'measured', 'raw_dtype': 'uint16', 'boundary_width_px': 1,
                     'measurements': [{'region': 'interior', 'channel': 'gray',
                                       'pixel_count': 9, 'mean': 1234, 'median': 1234,
                                       'min': 1234, 'max': 1234, 'std': 0, 'sum': 11106}]}
        legacy_candidate = {'id': 7, 'x': 11, 'y': 11, 'state': 'confirmed',
                            'roi': {'interior': roi}, 'intensity': intensity,
                            'note': '旧版保留的人工复核'}
        doc = {'format': 'facc-project', 'format_version': 2, 'image_name': 'v2_16bit.tif',
               'parameters': {'boundary_width': 1, 'intensity_channel': 'gray'},
               'candidates': [legacy_candidate], 'analysis': {'channel': 'gray'}}
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'v2.facc'
            payload = io.BytesIO()
            np.save(payload, raw, allow_pickle=False)
            with zipfile.ZipFile(path, 'w') as archive:
                archive.writestr('project.json', json.dumps(doc))
                archive.writestr('raw.npy', payload.getvalue())
            image, result = load_project(path)
            candidate = result.candidates[0]
            self.assertTrue(np.array_equal(image.raw, raw))
            self.assertEqual(candidate.id, 7)
            self.assertEqual(candidate.state, 'confirmed')
            self.assertEqual(candidate.note, '旧版保留的人工复核')
            self.assertEqual(candidate.roi['interior'], roi)
            self.assertEqual(candidate.intensity, intensity)
            self.assertFalse(result.parameters.central_enabled)
            self.assertEqual(candidate.central_nuclei, {})
            self.assertEqual(fiber_status(candidate), 'unclassified')


if __name__ == '__main__':
    unittest.main()
