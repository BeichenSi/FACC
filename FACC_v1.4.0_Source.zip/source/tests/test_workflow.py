import json
import os
from pathlib import Path
import tempfile
from threading import Event
import unittest
import numpy as np
from scipy.spatial.distance import cdist
import tifffile
from PIL import Image
from facc.demo import membrane_demo, bright_demo
from facc.image_io import from_array, load_image, analysis_plane, frame_count
from facc.engine import count_cells, Cancelled
from facc.models import Parameters, Candidate, CountResult
from facc.storage import save_project, load_project, export_bundle


class WorkflowTests(unittest.TestCase):
    def test_closed_membrane_count_and_locations(self):
        raw, centers = membrane_demo(); image = from_array(raw)
        result = count_cells(image, Parameters(largest_tissue=False))
        self.assertEqual(result.count, 12)
        distances = cdist(centers, [(c.x, c.y) for c in result.candidates])
        self.assertTrue(np.all(distances.min(axis=1) < 5))
        self.assertEqual([c.id for c in result.candidates], list(range(1, 13)))

    def test_touching_bright_objects_16bit(self):
        raw, centers = bright_demo(); image = from_array(raw)
        result = count_cells(image, Parameters(mode='bright', min_area=200, max_area=5000, peak_distance=10))
        self.assertEqual(result.count, 3)
        self.assertLess(cdist(centers, [(c.x, c.y) for c in result.candidates]).min(axis=1).max(), 5)
        self.assertEqual(image.raw.dtype, np.uint16)

    def test_blank_and_constant_images(self):
        for value in (0, 255):
            result = count_cells(from_array(np.full((120, 180), value, np.uint8)))
            self.assertEqual(result.count, 0)

    def test_cancel_before_work(self):
        event = Event(); event.set()
        with self.assertRaises(Cancelled): count_cells(from_array(np.zeros((100, 100), np.uint8)), cancel=event)

    def test_channel_selection(self):
        a = np.zeros((80, 100, 3), np.uint16); a[20:50, 20:70, 1] = 50000
        plane, channel, limits = analysis_plane(from_array(a), 'auto')
        self.assertEqual(channel, 'green'); self.assertGreater(plane.max(), 200)
        r, _, _ = analysis_plane(from_array(a), 'red'); self.assertEqual(r.max(), 0)

    def test_downsampling_preserves_original_coordinates(self):
        raw, centers = membrane_demo(); raw = np.repeat(np.repeat(raw, 2, axis=0), 2, axis=1)
        result = count_cells(from_array(raw), Parameters(largest_tissue=False, min_area=400, max_area=26000, max_dimension=680))
        self.assertEqual(result.count, 12)
        self.assertLess(cdist(np.array(centers)*2, [(c.x, c.y) for c in result.candidates]).min(axis=1).max(), 8)

    def test_unicode_tiff_pages_and_project(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder); path = root / '细胞_16位.tif'
            a, _ = bright_demo()
            with tifffile.TiffWriter(path) as tf:
                tf.write(a); tf.write(a // 2)
            self.assertEqual(frame_count(path), 2)
            image = load_image(path, 1); self.assertTrue(np.array_equal(image.raw, a//2))
            result = CountResult([Candidate(4, 20, 20, 'confirmed', ['manual'], 'manual', None, '测试备注')], Parameters(), edited=True)
            project = root / '复核项目.facc'; save_project(project, image, result)
            loaded, restored = load_project(project)
            self.assertTrue(np.array_equal(loaded.raw, image.raw)); self.assertEqual(restored.candidates[0].to_dict(), result.candidates[0].to_dict()); self.assertTrue(restored.edited)

    def test_lzw_tiff_rgb_and_16bit_roundtrip(self):
        with tempfile.TemporaryDirectory() as folder:
            for name, raw in [('rgb.tif', membrane_demo()[0]), ('16位.tif', bright_demo()[0])]:
                path = Path(folder) / name
                Image.fromarray(raw).save(path, compression='tiff_lzw')
                restored = load_image(path)
                self.assertEqual(restored.raw.dtype, raw.dtype)
                self.assertTrue(np.array_equal(restored.raw, raw))

    def test_export_count_pixels_and_escaping(self):
        with tempfile.TemporaryDirectory() as folder:
            raw, _ = membrane_demo(); image = from_array(raw, '</script>sample.png')
            result = CountResult([Candidate(1, 100, 100), Candidate(3, 250, 250, 'pending', ['manual'])], Parameters())
            target = Path(export_bundle(image, result, folder))
            doc = json.loads((target/'summary.json').read_text(encoding='utf-8'))
            self.assertEqual(doc['total_candidates'], 2); self.assertEqual(doc['author'], 'qianghw'); self.assertEqual(doc['contact'], 'qianghw@foxmail.com')
            self.assertTrue(np.array_equal(np.array(Image.open(target/'numbered.png')), np.array(Image.open(target/'numbered.tif'))))
            self.assertTrue(np.array_equal(load_image(target/'numbered.tif').raw, np.array(Image.open(target/'numbered.png'))))
            self.assertIn('\\u003c/script>', (target/'viewer.html').read_text(encoding='utf-8'))
            self.assertFalse((target/'EXPORT_INCOMPLETE.txt').exists())
            second = Path(export_bundle(image, result, folder)); self.assertNotEqual(target, second)

    def test_invalid_parameters(self):
        with self.assertRaises(ValueError): Parameters(min_area=200, max_area=100).validate()
        with self.assertRaises(ValueError): Parameters(mode='other').validate()

if __name__ == '__main__': unittest.main()
