import csv,json,tempfile,unittest,zipfile
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from facc.demo import membrane_demo
from facc.image_io import from_array
from facc.models import Parameters,Candidate,CountResult
from facc.engine import count_cells
from facc.recovery import recovery_summary,recovery_status,classify_recovery
from facc.storage import save_project,load_project,export_bundle

def demo():
    raw,centers=membrane_demo();a=raw.copy();g=Image.new('L',(a.shape[1],a.shape[0]),0);d=ImageDraw.Draw(g)
    for x,y in centers[:2]:d.ellipse((x-40,y-40,x+40,y+40),outline=210,width=4)
    x,y=centers[2];d.arc((x-40,y-40,x+40,y+40),0,45,fill=210,width=4)
    x,y=centers[3];d.ellipse((x-15,y-15,x+15,y+15),fill=255)
    a[...,1]=np.asarray(g);return from_array(a,'recovery_demo.png')

def analyze(im=None,**kw):
    options=dict(recovery_enabled=True,largest_tissue=False,recovery_threshold=60,intensity_channel='all');options.update(kw)
    return count_cells(im or demo(),Parameters(**options))

class RecoveryTests(unittest.TestCase):
    def test_known_full_partial_and_internal_green(self):
        r=analyze();s=recovery_summary(r)
        self.assertEqual((s['total_fibers'],s['recovered_fibers'],s['negative_fibers'],s['unclassified_fibers']),(12,2,10,0))
        self.assertAlmostEqual(s['ratio'],2/12)
    def test_purple_spectrin_and_blue_do_not_count_as_green(self):
        a,_=membrane_demo();a=a.copy();a[...,2]=255
        self.assertEqual(recovery_summary(analyze(from_array(a)))['recovered_fibers'],0)
    def test_diffuse_green_background_not_membrane_recovery(self):
        a,_=membrane_demo();a=a.copy();a[...,1]=100
        self.assertEqual(recovery_summary(analyze(from_array(a),recovery_threshold=0))['recovered_fibers'],0)
    def test_stricter_circumference_condition_changes_partial_fiber(self):
        a,_=membrane_demo();a=a.copy();g=Image.new('L',(680,510),0);ImageDraw.Draw(g).arc((60,60,140,140),0,150,fill=210,width=4);a[...,1]=g
        self.assertEqual(recovery_summary(analyze(from_array(a)))['recovered_fibers'],1)
        self.assertEqual(recovery_summary(analyze(from_array(a),recovery_min_coverage=.75))['recovered_fibers'],0)
    def test_16bit_uses_common_scale_and_keeps_raw(self):
        im=from_array(demo().raw.astype(np.uint16)*257);before=im.raw.copy();r=analyze(im)
        self.assertTrue(np.array_equal(im.raw,before));self.assertEqual(recovery_summary(r)['recovered_fibers'],2)
        self.assertGreater(max(c.recovery['measurements']['membrane_green_mean_raw'] for c in r.candidates),20000)
    def test_manual_no_roi_stays_denominator_until_classified(self):
        r=analyze();r.candidates.append(Candidate(13,10,10,origin='manual'))
        self.assertEqual(recovery_summary(r)['unclassified_fibers'],1);self.assertAlmostEqual(recovery_summary(r)['ratio'],2/13)
        r.candidates[-1].recovery={'override':'positive'};self.assertEqual(recovery_summary(r)['recovered_fibers'],3)
        r.candidates[-1].recovery['override']=None;self.assertEqual(recovery_summary(r)['recovered_fibers'],2)
        r.candidates.pop();r.renumber();self.assertAlmostEqual(recovery_summary(r)['ratio'],2/12)
    def test_zero_denominator_is_undefined(self):
        r=analyze(from_array(np.zeros((100,100,3),np.uint8)))
        self.assertIsNone(recovery_summary(r)['ratio'])
    def test_rgb_required_and_red_forced(self):
        with self.assertRaises(ValueError):analyze(from_array(np.zeros((100,100),np.uint8)))
        r=analyze(mode='bright',channel='green');self.assertEqual((r.parameters.mode,r.metadata['channel']),('membrane','red'))
    def test_missing_spectrin_is_unclassified_for_saved_roi(self):
        im=demo();r=analyze(im);im.raw[...,0]=0
        classify_recovery(im,r);s=recovery_summary(r)
        self.assertEqual(s['unclassified_fibers'],12);self.assertTrue(s['ratio_is_lower_bound'])
    def test_project_exports_and_manual_override(self):
        im=demo();r=analyze(im);r.candidates[0].recovery['override']='negative'
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(export_bundle(im,r,tmp));a,b=load_project(target/'project.facc')
            self.assertTrue(np.array_equal(a.raw,im.raw));self.assertEqual(recovery_summary(b),recovery_summary(r))
            self.assertEqual(b.candidates[0].recovery,r.candidates[0].recovery)
            with (target/'recovery_fibers.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
            self.assertEqual(len(rows),12);self.assertEqual(sum(x['恢复状态代码']=='positive' for x in rows),1)
            s=json.loads((target/'summary.json').read_text(encoding='utf8'))
            self.assertEqual(s['dystrophin_recovery']['recovered_fibers'],1)
            self.assertTrue((target/'recovery_coverage_sensitivity.csv').is_file())
    def test_legacy_v3_does_not_invent_recovery(self):
        im=demo();r=count_cells(im,Parameters(largest_tissue=False))
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'new.facc';save_project(p,im,r)
            with zipfile.ZipFile(p) as z:doc=json.loads(z.read('project.json'));raw=z.read('raw.npy')
            doc['format_version']=3
            for c in doc['candidates']:c.pop('recovery',None)
            for key in list(doc['parameters']):
                if key.startswith('recovery_'):doc['parameters'].pop(key)
            q=Path(tmp)/'old.facc'
            with zipfile.ZipFile(q,'w') as z:z.writestr('project.json',json.dumps(doc));z.writestr('raw.npy',raw)
            a,b=load_project(q);self.assertFalse(b.parameters.recovery_enabled);self.assertEqual(recovery_summary(b)['unclassified_fibers'],r.count)
    def test_both_analyses_and_progress_order(self):
        progress=[];r=count_cells(demo(),Parameters(largest_tissue=False,recovery_enabled=True,central_enabled=True),lambda n,s:progress.append(n))
        self.assertEqual(r.count,12);self.assertIn('central_nuclei',r.metadata);self.assertIn('recovery',r.metadata)
        self.assertEqual(progress,sorted(progress))
