from dataclasses import asdict, dataclass, field
from typing import Any
import numpy as np


REASONS = {
    "small": "对象较小，需区分肌纤维、间隙或其他结构",
    "irregular": "轮廓细长或不规则",
    "sensitive": "对边界识别参数敏感",
    "bright_interior": "内部荧光较强",
    "edge": "位于图像或组织边缘",
    "split": "由相邻粘连候选自动拆分",
    "manual": "人工补充的候选，尚未确认",
}
STATE_LABELS = {"automatic": "自动识别", "pending": "待复核", "confirmed": "已人工确认"}


@dataclass
class Parameters:
    mode: str = "membrane"
    channel: str = "auto"
    min_area: float = 100.0
    max_area: float = 6500.0
    smooth_sigma: float = 0.8
    local_sigma: float = 15.0
    threshold_factor: float = 0.65
    min_intensity: float = 6.0
    closing_radius: int = 1
    min_solidity: float = 0.35
    largest_tissue: bool = True
    auto_split: bool = True
    exclude_image_edge: bool = False
    max_dimension: int = 4096
    bright_threshold: float = 0.0  # 0 selects Otsu's method on the 0–255 analysis plane.
    peak_distance: int = 8
    intensity_channel: str = 'counting'
    intensity_regions: str = 'both'
    boundary_width: int = 3
    central_enabled: bool = False
    nuclei_channel: str = 'blue_residual'
    nucleus_threshold: float = 0.0
    nucleus_min_area: float = 8.0
    nucleus_max_area: float = 400.0
    nucleus_overlap: float = 0.5
    nucleus_margin: float = 0.0
    recovery_enabled: bool = False
    recovery_band_width: int = 5
    recovery_threshold: float = 0.0
    recovery_background_sigma: float = 3.0
    recovery_min_contrast: float = 10.0
    recovery_min_coverage: float = 0.30
    recovery_min_spectrin_coverage: float = 0.50

    def validate(self):
        if self.mode not in ("membrane", "bright"):
            raise ValueError("未知计数模式。")
        if self.channel not in ("auto", "red", "green", "blue", "gray"):
            raise ValueError("未知荧光通道。")
        if not 1 <= self.min_area < self.max_area <= 1e9:
            raise ValueError("最小面积必须大于 0，并且小于最大面积。")
        if not 0 <= self.smooth_sigma <= 10:
            raise ValueError("平滑强度应在 0–10 之间。")
        if not 2 <= self.local_sigma <= 150:
            raise ValueError("局部背景半径应在 2–150 之间。")
        if not 0.1 <= self.threshold_factor <= 2:
            raise ValueError("边界阈值系数应在 0.1–2.0 之间。")
        if not 0 <= self.min_intensity <= 255 or not 0 <= self.bright_threshold <= 255:
            raise ValueError("强度阈值应在 0–255 之间。")
        if not 0 <= self.closing_radius <= 10 or not 0 <= self.min_solidity <= 1:
            raise ValueError("轮廓连接半径或形状参数无效。")
        if not 512 <= self.max_dimension <= 10000 or not 2 <= self.peak_distance <= 200:
            raise ValueError("分析分辨率或峰间距参数无效。")
        if self.intensity_channel not in ('counting', 'all', 'red', 'green', 'blue', 'gray'):
            raise ValueError('未知荧光测量通道。')
        if self.intensity_regions not in ('both', 'interior', 'boundary') or not 1 <= self.boundary_width <= 30:
            raise ValueError('荧光测量区域或周带宽度无效。')
        if self.nuclei_channel not in ('blue_residual', 'blue', 'red', 'green', 'gray'):
            raise ValueError('未知细胞核识别通道。')
        if not 0 <= self.nucleus_threshold <= 255:
            raise ValueError('细胞核阈值应在 0–255 之间（0 为自动）。')
        if not 1 <= self.nucleus_min_area < self.nucleus_max_area <= 1e7:
            raise ValueError('核最小面积必须大于 0 且小于核最大面积。')
        if not 0.01 <= self.nucleus_overlap <= 1 or not 0 <= self.nucleus_margin <= 100:
            raise ValueError('核内部比例应在 0.01–1 之间，距边界距离应在 0–100 像素之间。')
        if not 1 <= self.recovery_band_width <= 30 or not 0 <= self.recovery_threshold <= 255:
            raise ValueError('恢复分析的膜搜索宽度应在 1–30 px，强度阈值应在 0–255 之间。')
        if not 0 <= self.recovery_background_sigma <= 10 or not 0 <= self.recovery_min_contrast <= 255:
            raise ValueError('背景倍数应在 0–10，最低膜背景差应在 0–255 之间。')
        if not 0.01 <= self.recovery_min_coverage <= 1 or not 0.01 <= self.recovery_min_spectrin_coverage <= 1:
            raise ValueError('DYS 阳性覆盖与最低血影蛋白支持比例应在 0.01–1 之间。')
        return self

    @classmethod
    def from_dict(cls, data: dict[str, Any]):
        fields = cls.__dataclass_fields__
        return cls(**{k: v for k, v in data.items() if k in fields}).validate()


@dataclass
class ImageData:
    name: str
    source_path: str
    raw: np.ndarray
    display: np.ndarray
    page: int = 0
    metadata: dict = field(default_factory=dict)

    @property
    def width(self):
        return int(self.display.shape[1])

    @property
    def height(self):
        return int(self.display.shape[0])


@dataclass
class Candidate:
    id: int
    x: float
    y: float
    state: str = "automatic"
    flags: list[str] = field(default_factory=list)
    origin: str = "automatic"
    interior_area_px: float | None = None
    note: str = ""
    roi: dict = field(default_factory=dict)
    intensity: dict = field(default_factory=dict)
    central_nuclei: dict = field(default_factory=dict)
    recovery: dict = field(default_factory=dict)

    @property
    def review_needed(self):
        return self.state == "pending"

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, data):
        fields = cls.__dataclass_fields__
        item = cls(**{k: v for k, v in data.items() if k in fields})
        if item.id < 1 or item.state not in STATE_LABELS:
            raise ValueError("项目内存在无效编号或状态。")
        if not np.isfinite(item.x) or not np.isfinite(item.y):
            raise ValueError("项目内存在无效坐标。")
        return item


@dataclass
class CountResult:
    candidates: list[Candidate]
    parameters: Parameters
    metadata: dict = field(default_factory=dict)
    edited: bool = False

    @property
    def count(self):
        return len(self.candidates)

    @property
    def review_count(self):
        return sum(c.review_needed for c in self.candidates)

    @property
    def confirmed_count(self):
        return sum(c.state == "confirmed" for c in self.candidates)

    def validate(self, image):
        ids = [c.id for c in self.candidates]
        if len(ids) != len(set(ids)):
            raise ValueError("项目中存在重复编号。")
        if any(not (0 <= c.x < image.width and 0 <= c.y < image.height) for c in self.candidates):
            raise ValueError("项目中的编号坐标超出图像范围。")
        self.parameters.validate()
        return self

    def renumber(self):
        self.candidates.sort(key=lambda c: (int(c.y // 60), c.x, c.y))
        for n, c in enumerate(self.candidates, 1):
            c.id = n
