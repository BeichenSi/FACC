import csv
from .recovery import recovery_summary,recovery_status,LABELS

HEADERS=['DYS恢复判定','恢复状态代码','绿色阳性周长比例','血影蛋白支持比例','绿色阈值_分析尺度','胞内绿色背景_分析尺度','肌膜绿色均值_原输入尺度','肌膜绿色减背景_分析尺度','恢复人工修正','恢复判定提示']

def recovery_values(c):
    d=c.recovery or {};m=d.get('measurements',{})
    return [LABELS[recovery_status(c)] if d else '未分析',recovery_status(c) if d else '',
            m.get('positive_coverage'),m.get('spectrin_support'),m.get('green_threshold'),m.get('background_green'),
            m.get('membrane_green_mean_raw'),m.get('membrane_green_minus_background'),LABELS.get(d.get('override'),''),'；'.join(d.get('review_flags',[]))]

def write_recovery_csv(path,result):
    with open(path,'w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['肌纤维编号','X像素','Y像素']+HEADERS+['肌膜采样数','血影支持采样数','绿色阳性采样数','自动判定','说明'])
        for c in result.candidates:
            d=c.recovery or {};m=d.get('measurements',{})
            w.writerow([c.id,c.x,c.y]+recovery_values(c)+[m.get('perimeter_samples'),m.get('spectrin_supported_samples'),m.get('positive_samples'),LABELS.get(d.get('auto_status'),''),d.get('reason','')])

def write_coverage_sensitivity(path,result):
    with open(path,'w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['最低阳性周长比例','自动恢复候选数','全部肌纤维数','自动恢复占比','自动未确定数','说明'])
        for threshold in sorted(set([.25,.3,.5,.75,result.parameters.recovery_min_coverage])):
            unknown=sum(c.recovery.get('auto_status','unclassified')=='unclassified' for c in result.candidates)
            n=sum(c.recovery.get('auto_status') in ('positive','negative') and (c.recovery.get('measurements',{}).get('positive_coverage') or 0)>=threshold for c in result.candidates)
            w.writerow([threshold,n,result.count,n/result.count if result.count else None,unknown,'固定强度阈值，仅改变周长阈值；使用自动测量，忽略人工分类修正'])

def recovery_note(result):
    s=recovery_summary(result);pct='无定义' if s['ratio_percent'] is None else f'{s["ratio_percent"]:.4f}%'
    return f'''\nDystrophin 恢复分析\n恢复候选 {s['recovered_fibers']} / 总肌纤维 {s['total_fibers']} = {pct}；未确定 {s['unclassified_fibers']}。
以红色血影蛋白确定分母，以绿色在受支持肌膜上的阳性周长比例判定，每根只计一次。
recovery_fibers.csv：逐根判定、阳性覆盖、膜支持、实际绿色阈值与人工修正。
recovery_numbered.png：浅绿 DYS 恢复候选、浅蓝未达到条件、灰色未确定。
recovery_coverage_sensitivity.csv：保持强度阈值不变，比较不同周长阈值；不套用人工修正。
默认膜覆盖阈值30%，自动强度来自胞内背景；设置可调整。全部保留候选均在分母，包括未确定；未确定存在时，比例为已分类的下限。
本结果是 DYS 阳性肌纤维候选比例，不代表正常蛋白表达量百分比或功能恢复；仅凭单张治疗后merge图无法剔除治疗前自发阳性纤维。
膜采样为近似定位，相邻肌纤维共享膜区、弱信号、饱和和分割错误须复核。没有阴性对照时，应报告为自动初筛结果。
project.facc 保存原图、采样坐标和人工分类，可继续修改；移动编号只改变标签位置。
方法参考：https://pmc.ncbi.nlm.nih.gov/articles/PMC9184255/ （30%周长思路；FACC不是原论文验证的软件）。\n'''
