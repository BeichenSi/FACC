"""Small deterministic images used by the demo and independent validation."""
import numpy as np
from PIL import Image, ImageDraw


def membrane_demo():
    im = Image.new('RGB', (680, 510), (2, 0, 2))
    d = ImageDraw.Draw(im)
    # Twelve separate, closed circular membranes with a generous external gap.
    centers = [(100 + col * 155, 100 + row * 155) for row in range(3) for col in range(4)]
    for x, y in centers:
        d.ellipse((x-40, y-40, x+40, y+40), outline=(210, 0, 210), width=4)
    return np.asarray(im), centers


def bright_demo():
    yy, xx = np.mgrid[:220, :300]
    a = np.zeros((220, 300), np.uint16)
    centers = [(70, 70), (105, 70), (215, 145)]
    for x, y in centers:
        a[(xx-x)**2 + (yy-y)**2 <= 23**2] = 35000
    return a, centers


def recovery_demo():
    raw,centers=membrane_demo();raw=raw.copy()
    g=Image.new('L',(raw.shape[1],raw.shape[0]),0);d=ImageDraw.Draw(g)
    for x,y in centers[:2]:d.ellipse((x-40,y-40,x+40,y+40),outline=210,width=4)
    x,y=centers[2];d.arc((x-40,y-40,x+40,y+40),0,45,fill=210,width=4)
    x,y=centers[3];d.ellipse((x-15,y-15,x+15,y+15),fill=255)
    raw[...,1]=g
    return raw,centers
