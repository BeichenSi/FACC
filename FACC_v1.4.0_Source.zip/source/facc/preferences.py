"""Explicit, per-user defaults. Opening a project never writes these settings."""
from dataclasses import asdict
from datetime import datetime
import json
import os
from pathlib import Path
import tempfile
from . import __version__
from .models import Parameters


def data_directory():
    override = os.environ.get('FACC_DATA_DIR')
    return Path(override) if override else Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'FACC'


def defaults_path():
    return data_directory() / 'default_parameters.json'


def load_defaults(path=None):
    path = Path(path) if path is not None else defaults_path()
    if not path.exists():
        return Parameters()
    try:
        if path.stat().st_size > 64 * 1024:
            raise ValueError('参数文件内容异常')
        doc = json.loads(path.read_text(encoding='utf-8-sig'))
        if doc.get('format') != 'facc-default-parameters' or doc.get('format_version') != 1:
            raise ValueError('参数文件格式不受支持')
        data = doc['parameters']
        if not isinstance(data, dict):
            raise ValueError('参数内容应为对象')
        # Reject malformed types rather than letting a string masquerade as a bool.
        for key, default in asdict(Parameters()).items():
            if key not in data:
                continue
            value = data[key]
            if isinstance(default, bool):
                valid = isinstance(value, bool)
            elif isinstance(default, str):
                valid = isinstance(value, str)
            elif isinstance(default, int):
                valid = isinstance(value, int) and not isinstance(value, bool)
            else:
                valid = isinstance(value, (int, float)) and not isinstance(value, bool)
            if not valid:
                raise ValueError(f'参数 {key} 类型不正确')
        return Parameters.from_dict(data)
    except (OSError, ValueError, TypeError, KeyError, AttributeError) as e:
        raise ValueError(f'无法读取已保存的默认参数：{e}。当前可使用出厂参数；原文件保留在 {path}') from e


def save_defaults(parameters, path=None):
    parameters.validate()
    path = Path(path) if path is not None else defaults_path()
    doc = dict(format='facc-default-parameters', format_version=1, software_version=__version__,
               saved_at=datetime.now().astimezone().isoformat(timespec='seconds'), parameters=asdict(parameters))
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.defaults_', suffix='.json', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump(doc, stream, ensure_ascii=False, indent=2)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return path
