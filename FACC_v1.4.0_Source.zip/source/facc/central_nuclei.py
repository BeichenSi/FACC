"""Operational inside-nucleus classification on saved original-pixel fiber ROIs.

This is candidate classification from a 2-D merged image, not cell identity or
proof of regeneration. One internal nucleus is sufficient; fibers count once.
"""
import time
import numpy as np
from scipy import ndimage as ndi
from skimage import filters, measure
from .image_io import analysis_plane, normalize
from .intensity import unpack_roi


STATUSES = ('positive', 'negative', 'unclassified')


def fiber_status(candidate):
    info = candidate.central_nuclei or {}
    value = info.get('override') or info.get('auto_status') or 'unclassified'
    return value if value in STATUSES else 'unclassified'


def central_summary(result):
    counts = {s: sum(fiber_status(c) == s for c in result.candidates) for s in STATUSES}
    total = len(result.candidates)
    ratio = counts['positive'] / total if total else None
    return dict(total_fibers=total, central_fibers=counts['positive'],
                noncentral_fibers=counts['negative'], unclassified_fibers=counts['unclassified'],
                ratio=ratio, ratio_percent=100*ratio if ratio is not None else None,
                classification_complete=counts['unclassified'] == 0,
                ratio_is_lower_bound=counts['unclassified'] > 0)


def nuclear_plane(image, channel):
    if image.raw.ndim != 3:
        raise ValueError('中央核分析需要同时包含血影蛋白和 DAPI 的 RGB 合并图；单通道图无法判断核与肌纤维的相对位置。')
    if channel != 'blue_residual':
        plane, chosen, limits = analysis_plane(image, channel)
        return plane, dict(channel=chosen, normalization_range=list(limits))
    # A common scale preserves magenta R/B equality, unlike separate stretching.
    raw, limits = normalize(image.raw)
    plane = np.maximum(raw[..., 2] - raw[..., 0], 0)
    return plane, dict(channel='blue_residual', expression='max(B - R, 0)',
                       normalization_range=list(limits), normalization='shared RGB scale before subtraction')


def classify_central_nuclei(image, result, progress=None):
    report = progress or (lambda value, message: None)
    p = result.parameters
    start = time.perf_counter()
    report(96, '分离 DAPI 核信号与紫色膜信号')
    plane, details = nuclear_plane(image, p.nuclei_channel)
    smooth = ndi.gaussian_filter(plane, .7)
    threshold = float(p.nucleus_threshold)
    if threshold == 0:
        threshold = max(6., float(filters.threshold_otsu(smooth))) if np.ptp(smooth) > 1e-6 else 6.
    binary = ndi.binary_fill_holes(smooth > threshold)
    labels, _ = ndi.label(binary)
    regions = measure.regionprops(labels, intensity_image=plane)
    # Fiber ROIs stay in original coordinates. Collisions are not attributed.
    fibers = np.zeros((image.height, image.width), np.int32)
    collision = np.zeros(fibers.shape, bool)
    distance = np.zeros(fibers.shape, np.float32) if p.nucleus_margin > 0 else None
    by_id = {c.id: c for c in result.candidates}
    for c in result.candidates:
        c.central_nuclei = dict(auto_status='negative' if 'interior' in c.roi else 'unclassified',
                               override=None, nuclei=[], review_flags=[])
        if 'interior' not in c.roi:
            c.central_nuclei['reason'] = '缺少肌纤维内部区域；请人工判定'
            continue
        mask, x, y = unpack_roi(c.roi['interior'])
        view = fibers[y:y+mask.shape[0], x:x+mask.shape[1]]
        collision[y:y+mask.shape[0], x:x+mask.shape[1]] |= mask & (view != 0)
        view[mask] = c.id
        if distance is not None:
            own_distance = ndi.distance_transform_edt(np.pad(mask, 1))[1:-1, 1:-1]
            distance[y:y+mask.shape[0], x:x+mask.shape[1]][mask] = own_distance[mask]
    fibers[collision] = 0
    nuclei = []
    rejected_small = rejected_large = 0
    for i, q in enumerate(regions):
        if i % 250 == 0:
            report(97 + int(2*i/max(1, len(regions))), '判断核是否位于肌纤维内部（每根纤维只计一次）')
        if q.area < p.nucleus_min_area:
            rejected_small += 1
            continue
        if q.area > p.nucleus_max_area:
            rejected_large += 1
            continue
        y, x = q.centroid
        iy, ix = int(round(y)), int(round(x))
        iy, ix = min(iy, image.height-1), min(ix, image.width-1)
        y0, x0, y1, x1 = q.bbox
        ids, sizes = np.unique(fibers[y0:y1, x0:x1][q.image], return_counts=True)
        overlaps = {int(k): float(n/q.area) for k, n in zip(ids, sizes) if k > 0}
        center_id = int(fibers[iy, ix])
        fraction = overlaps.get(center_id, 0.)
        margin_ok = distance is None or distance[iy, ix] >= p.nucleus_margin
        assigned = center_id if center_id and fraction >= p.nucleus_overlap and margin_ok else None
        flags = []
        if len(overlaps) > 1: flags.append('跨越多个肌纤维内部区域，需复核')
        if overlaps and (assigned is None or fraction < min(1., p.nucleus_overlap + .15)):
            flags.append('核贴近分割边界，需复核')
        if q.solidity < .5: flags.append('核形状不规则，需复核')
        item = dict(id=len(nuclei)+1, x=round(float(x), 3), y=round(float(y), 3),
                    area_px=int(q.area), inside_fraction=round(float(fraction), 6),
                    accepted_fiber_id=assigned, centroid_fiber_id=center_id or None,
                    overlapping_fiber_ids=list(overlaps), mean_signal=float(q.intensity_mean),
                    review_flags=flags)
        nuclei.append(item)
        if assigned is not None:
            c = by_id[assigned]
            c.central_nuclei['auto_status'] = 'positive'
            c.central_nuclei['nuclei'].append(dict(item))
        for fid in overlaps:
            info = by_id[fid].central_nuclei
            info['review_flags'] = list(dict.fromkeys(info['review_flags'] + flags))
    result.metadata['central_nuclei'] = dict(
        enabled=True, algorithm='FACC inside-nucleus v1', **details,
        resolved_threshold=threshold, threshold_method='manual' if p.nucleus_threshold else 'Otsu with floor 6',
        smoothing_sigma_px=.7, detection_resolution='original image pixels',
        nucleus_area_range_px=[p.nucleus_min_area, p.nucleus_max_area],
        minimum_inside_fraction=p.nucleus_overlap, minimum_centroid_margin_px=p.nucleus_margin,
        rule='A fiber is positive if at least one detected nucleus has its centroid inside its saved interior ROI and the required fraction of nuclear pixels inside that same ROI. Each nucleus belongs to at most one fiber; each fiber counts once.',
        denominator='all retained fiber candidates, including unclassified manual additions; incomplete classification yields a lower bound',
        limitations='RGB merge only; B-R reduces magenta membrane signal but cannot recover original DAPI channels, saturated signal, or establish cell identity in a 2-D projection. Automatic candidates require review.',
        nuclei=nuclei, detected_nuclei=len(nuclei), rejected_small=rejected_small,
        rejected_large=rejected_large, elapsed_seconds=round(time.perf_counter()-start, 3))
    return result
