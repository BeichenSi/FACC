"""Deterministic local counting; no network service or specimen-specific coordinates."""
import time
from dataclasses import asdict
from threading import Event
import numpy as np
from scipy import ndimage as ndi
from skimage import feature, filters, measure, morphology, segmentation, transform
from .image_io import analysis_plane
from .models import Parameters, Candidate, CountResult
from . import __version__
from .intensity import original_roi, measure_candidates
from .central_nuclei import classify_central_nuclei
from .recovery import classify_recovery


class Cancelled(Exception):
    pass


def count_cells(image, parameters=None, progress=None, cancel=None):
    p = Parameters.from_dict(asdict(parameters or Parameters()))
    if p.central_enabled or p.recovery_enabled:
        if image.raw.ndim != 3:
            raise ValueError('中央核或恢复分析需要含对应荧光通道的 RGB 合并图。')
        p.mode, p.channel = 'membrane', 'red'
    progress = progress or (lambda value, message: None)
    cancel = cancel or Event()
    start = time.perf_counter()

    def report(value, message):
        if cancel.is_set():
            raise Cancelled("已取消计数。")
        progress(value, message)

    report(2, "读取荧光通道")
    g, channel, limits = analysis_plane(image, p.channel)
    scale = min(1.0, p.max_dimension / max(image.width, image.height))
    if scale < 1:
        shape = (max(1, round(image.height * scale)), max(1, round(image.width * scale)))
        g = transform.resize(g, shape, preserve_range=True, anti_aliasing=True).astype(np.float32)
    sx, sy = g.shape[1] / image.width, g.shape[0] / image.height
    area_scale = sx * sy
    scale = float(np.sqrt(area_scale))
    min_area = max(5, p.min_area * area_scale)
    max_area = max(min_area + 1, p.max_area * area_scale)
    if np.max(g) - np.min(g) < 1e-4:
        report(94, "图像内未检测到可计数的荧光变化")
        result = CountResult([], p, {"version": __version__, "channel": channel, "analysis_scale": scale, "elapsed_seconds": round(time.perf_counter() - start, 3), "empty_image": True})
        if p.central_enabled:
            classify_central_nuclei(image, result, (lambda n,msg:report(96+int((n-96)*.35),msg)) if p.recovery_enabled else report)
        if p.recovery_enabled:
            classify_recovery(image,result,(lambda n,msg:report(97+int((n-96)*.65),msg)) if p.central_enabled else report)
        report(100, '未识别到肌纤维，相关比例无定义')
        return result
    smooth = ndi.gaussian_filter(g, p.smooth_sigma * scale)
    report(10, "识别图像范围")
    if p.mode == "membrane":
        tissue = ndi.gaussian_filter(g, max(0.8, 5 * scale)) > p.min_intensity
        tissue = morphology.closing(tissue, morphology.disk(max(1, round(13 * scale))))
        tissue = ndi.binary_fill_holes(tissue)
        tc, tn = ndi.label(tissue)
        sizes = np.bincount(tc.ravel())
        if len(sizes) > 1:
            sizes[0] = 0
            if p.largest_tissue:
                tissue = tc == np.argmax(sizes)
            else:
                tissue = np.isin(tc, np.where(sizes >= max(20, min_area))[0]) & (tc > 0)
        else:
            tissue[:] = False
        tissue = morphology.opening(tissue, morphology.disk(max(1, round(3 * scale))))
        report(25, "识别膜性荧光轮廓")
        local = ndi.gaussian_filter(g, max(2, p.local_sigma * scale))
        footprint = morphology.disk(max(0, round(p.closing_radius * scale)))
        membrane = smooth > np.maximum(p.min_intensity, local * p.threshold_factor)
        if p.closing_radius:
            membrane = morphology.closing(membrane, footprint)
        raw, _ = ndi.label((~membrane) & tissue)
        low = smooth > np.maximum(p.min_intensity, local * max(.1, p.threshold_factor - .20))
        if p.closing_radius:
            low = morphology.closing(low, footprint)
        low_labels, _ = ndi.label((~low) & tissue)
        low_props = {q.label: q for q in measure.regionprops(low_labels, intensity_image=g) if min_area <= q.area <= max_area}
        low_dist = ndi.distance_transform_edt((~low) & tissue) if p.auto_split else None
        normalized = smooth / np.maximum(local, p.min_intensity or 1)
        report(48, "筛选候选截面")
    else:
        threshold = p.bright_threshold if p.bright_threshold > 0 else float(filters.threshold_otsu(smooth))
        binary = smooth > max(threshold, p.min_intensity)
        binary = morphology.remove_small_objects(binary, max_size=max(2, int(min_area * .20)))
        binary = ndi.binary_fill_holes(binary)
        report(30, "分离相邻荧光对象")
        if p.auto_split:
            dist = ndi.distance_transform_edt(binary)
            peaks = feature.peak_local_max(dist, min_distance=max(2, round(p.peak_distance * scale)), labels=binary, exclude_border=False)
            markers = np.zeros(binary.shape, np.int32)
            if len(peaks):
                markers[tuple(peaks.T)] = np.arange(1, len(peaks) + 1)
                raw = segmentation.watershed(-dist, markers, mask=binary)
            else:
                raw, _ = ndi.label(binary)
        else:
            raw, _ = ndi.label(binary)
        low_labels = low_props = low_dist = normalized = None
        tissue = binary
        report(48, "筛选荧光对象")
    dist = ndi.distance_transform_edt(raw > 0)
    props = measure.regionprops(raw, intensity_image=g)
    candidates = []
    diagnostic = {"raw_components": len(props), "accepted_parent_regions": 0, "auto_split_parent_regions": 0, "filtered_area_or_shape": 0}

    def interior(q, distance):
        y0, x0, y1, x1 = q.bbox
        sub = distance[y0:y1, x0:x1] * q.image
        yy, xx = np.unravel_index(np.argmax(sub), sub.shape)
        return float(xx + x0), float(yy + y0), float(sub.max())

    def add(q, distance, origin="automatic", extra=None):
        x, y, radius = interior(q, distance)
        flags = list(extra or [])
        if q.area < max(180 * area_scale, min_area * 1.3) or radius < 4 * scale:
            flags.append("small")
        if q.solidity < .6 or q.eccentricity > .97:
            flags.append("irregular")
        if p.mode == "membrane" and q.intensity_mean > 12:
            flags.append("bright_interior")
        if min(x, y, g.shape[1] - 1 - x, g.shape[0] - 1 - y) < max(3, radius):
            flags.append("edge")
        flags = list(dict.fromkeys(flags))
        ox, oy = (x + .5) / sx - .5, (y + .5) / sy - .5
        candidates.append(Candidate(0, round(float(np.clip(ox, 0, image.width - 1)), 2), round(float(np.clip(oy, 0, image.height - 1)), 2), "pending" if flags else "automatic", flags, origin, round(float(q.area / area_scale), 2)))
        candidates[-1].roi['interior'] = original_roi(q.image, q.bbox, image.width, image.height, sx, sy)

    for idx, q in enumerate(props):
        if idx % 100 == 0:
            report(50 + int(40 * idx / max(1, len(props))), "评估轮廓并整理编号")
        if not min_area <= q.area <= max_area or q.solidity < p.min_solidity:
            diagnostic["filtered_area_or_shape"] += 1
            continue
        y0, x0, y1, x1 = q.bbox
        if p.exclude_image_edge and (y0 == 0 or x0 == 0 or y1 == g.shape[0] or x1 == g.shape[1]):
            continue
        diagnostic["accepted_parent_regions"] += 1
        flags = []
        if p.mode == "membrane":
            ll, counts = np.unique(low_labels[y0:y1, x0:x1][q.image], return_counts=True)
            children = [low_props[int(k)] for k, v in zip(ll, counts) if k in low_props and v >= min_area * .70]
            if not children:
                flags.append("sensitive")
            if p.auto_split and 2 <= len(children) <= 6:
                centers = [interior(child, low_dist) for child in children]
                plausible = all(r >= max(3, 3.5 * scale) for x, y, r in centers)
                # Reject distance maxima in the same elongated interior: a membrane ridge
                # must separate each pair along the connecting line.
                for i in range(len(centers)):
                    for j in range(i):
                        x1c, y1c, r1 = centers[i]; x2c, y2c, r2 = centers[j]
                        distance = float(np.hypot(x1c - x2c, y1c - y2c))
                        if distance < max(10 * scale, .95 * (r1 + r2)):
                            plausible = False
                            continue
                        t = np.linspace(.18, .82, max(5, round(distance)))
                        line = ndi.map_coordinates(normalized, [y1c + (y2c - y1c) * t, x1c + (x2c - x1c) * t], order=1)
                        if np.max(line) < max(.45, p.threshold_factor * .73):
                            plausible = False
                if plausible:
                    diagnostic["auto_split_parent_regions"] += 1
                    for child in children:
                        add(child, low_dist, "auto_split", ["split"])
                    continue
        add(q, dist, extra=flags)
    report(94, "检查编号与坐标")
    result = CountResult(candidates, p, {"version": __version__, "channel": channel, "normalization_range": list(limits), "analysis_scale": scale, "analysis_shape": list(g.shape), "elapsed_seconds": round(time.perf_counter() - start, 3), "diagnostics": diagnostic, "counting_unit": "candidate profile", "coordinate_system": "0-based original-image pixels; X right, Y down", "notes": "Automatic candidate count, not a validated biological ground truth. Area refers to segmented interior, not membrane-to-membrane CSA."})
    result.renumber()
    result.validate(image)
    result.metadata['segmentation_seconds'] = round(time.perf_counter() - start, 3)
    biological=p.central_enabled or p.recovery_enabled
    measure_candidates(image, result, (lambda value, msg: report(94 + int((value-94)*.3), msg)) if biological else report)
    if p.central_enabled:
        classify_central_nuclei(image, result, (lambda value,msg:report(96+int((value-96)*.35),msg)) if p.recovery_enabled else report)
    if p.recovery_enabled:
        classify_recovery(image,result,(lambda value,msg:report(97+int((value-96)*.65),msg)) if p.central_enabled else report)
    result.metadata['elapsed_seconds'] = round(time.perf_counter() - start, 3)
    report(100, f"完成：{result.count:,} 个候选，{result.review_count:,} 个待复核")
    return result
