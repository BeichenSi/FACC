"""Interaction checks available in both the source and the packaged executable."""
from dataclasses import asdict
import json
from pathlib import Path
import time
import numpy as np
from PySide6.QtCore import QEvent, QPointF, Qt
from PySide6.QtGui import QMouseEvent, QKeyEvent
from PySide6.QtWidgets import QAbstractSpinBox, QStyle, QStyleOptionSpinBox
from .models import Parameters
from .preferences import defaults_path, load_defaults
from .qa import require, finish_worker


def click(app, widget, position):
    local = QPointF(position); global_point = QPointF(widget.mapToGlobal(position))
    for event_type, buttons in [(QEvent.Type.MouseButtonPress, Qt.MouseButton.LeftButton),
                               (QEvent.Type.MouseButtonRelease, Qt.MouseButton.NoButton)]:
        event = QMouseEvent(event_type, local, global_point, Qt.MouseButton.LeftButton, buttons, Qt.KeyboardModifier.NoModifier)
        app.sendEvent(widget, event)
    app.processEvents()


def verify_settings(app, window, output):
    from .gui import MainWindow
    output = Path(output)
    window.resize(1500, 980); window.set_parameters(Parameters(central_enabled=True, recovery_enabled=True))
    if window._compact: window.side_tabs.setCurrentWidget(window.params_panel)
    errors=[]; previous_error=window._error; window._error=errors.append
    clicks=[]
    window.detail_label.setText('很长的详细说明\n'*45);window._update_detail_height()
    window.detail_label.setText('选择一个编号查看详情');window._update_detail_height()
    require(window.detail_label.height()<55,'Empty detail retained the previous tall layout')
    for key, spin in window.parameter_widgets.items():
        if not isinstance(spin, QAbstractSpinBox): continue
        window.show_parameter(key)
        for _ in range(5): app.processEvents()
        window.params_scroll.ensureWidgetVisible(spin)
        app.processEvents()
        opt=QStyleOptionSpinBox(); spin.initStyleOption(opt)
        up=spin.style().subControlRect(QStyle.ComplexControl.CC_SpinBox,opt,QStyle.SubControl.SC_SpinBoxUp,spin)
        down=spin.style().subControlRect(QStyle.ComplexControl.CC_SpinBox,opt,QStyle.SubControl.SC_SpinBoxDown,spin)
        require(up.width()>=28 and up.height()>=18 and not up.intersects(down), f'Step targets overlap or are too small: {key}')
        before=spin.value(); click(app,spin,up.center()); after=spin.value()
        require(abs(after-before-spin.singleStep())<1e-6, f'Increase button failed: {key}')
        click(app,spin,down.center()); require(abs(spin.value()-before)<1e-6, f'Decrease button failed: {key}')
        spin.setValue(spin.maximum()); click(app,spin,up.center()); require(spin.value()==spin.maximum(),f'Upper limit failed: {key}')
        spin.setValue(spin.minimum()); click(app,spin,down.center()); require(spin.value()==spin.minimum(),f'Lower limit failed: {key}')
        spin.setValue(before)
        app.sendEvent(spin,QKeyEvent(QEvent.Type.KeyPress,Qt.Key.Key_Up,Qt.KeyboardModifier.NoModifier))
        require(abs(spin.value()-before-spin.singleStep())<1e-6,f'Keyboard increase failed: {key}')
        app.sendEvent(spin,QKeyEvent(QEvent.Type.KeyPress,Qt.Key.Key_Down,Qt.KeyboardModifier.NoModifier))
        require(abs(spin.value()-before)<1e-6,f'Keyboard decrease failed: {key}')
        clicks.append(key)
    # Commit typed text even when Save Defaults is invoked from the menu.
    window.show_parameter('min_area'); window.parameter_widgets['min_area'].lineEdit().setText('137 px²')
    window.save_parameter_defaults(); require(not errors, f'Default save failed: {errors}')
    saved=window.get_parameters(); require(saved.min_area==137, 'Typed value was not committed')
    require(asdict(load_defaults())==asdict(saved), 'Default fields did not persist')
    before=defaults_path().read_bytes()
    window.restore_factory_parameters(); require(window.get_parameters()==Parameters(), 'Factory reset failed')
    require(defaults_path().read_bytes()==before, 'Factory load overwrote personal defaults')
    window.restore_parameter_defaults(); require(window.get_parameters()==saved, 'Reload defaults failed')
    reopened=MainWindow(); require(reopened.get_parameters()==saved, 'Restart did not load saved defaults')
    reopened.close(); app.processEvents()
    if window.result:
        old_result=window.result
        window._project_loaded((window.image, old_result))
        require(defaults_path().read_bytes()==before, 'Opening project overwrote personal defaults')
        require(window.get_parameters()==old_result.parameters, 'Project parameters were not applied')
    window.parameter_widgets['min_area'].setValue(7000);window.parameter_widgets['max_area'].setValue(6000)
    window.save_parameter_defaults(); require(bool(errors), 'Invalid parameters were accepted')
    require(defaults_path().read_bytes()==before, 'Invalid save damaged defaults')
    window.restore_parameter_defaults()
    window._error=previous_error
    for index, tab in enumerate(('counting','dys','central','intensity','advanced')):
        window.parameter_tabs.setCurrentIndex(index); window.params_scroll.verticalScrollBar().setValue(0)
        for _ in range(5):app.processEvents()
        window.grab().save(str(output/f'FACC_settings_{tab}.png'))
    window.parameter_tabs.setCurrentIndex(0)
    return dict(step_buttons_checked=len(clicks),step_keys=clicks,limits=True,typed_value_saved=True,
                defaults_restart=True,project_does_not_overwrite_defaults=True,factory_load_keeps_defaults=True,
                invalid_save_preserves_defaults=True,detail_height_shrinks=True,keyboard_step=True)


def verify_large_projects(app, window, output, projects):
    from .storage import save_project, load_project, export_bundle
    from .recovery import recovery_summary
    from .central_nuclei import central_summary
    reports=[]; errors=[]; window._error=errors.append
    out=Path(output)/'large_projects';out.mkdir(exist_ok=True)
    for path in projects:
        window.dirty=False; start=time.perf_counter()
        window.open_project_path(path);finish_worker(app,window,timeout=120)
        require(not errors, f'Large project GUI open failed: {errors}')
        elapsed=time.perf_counter()-start; image,result=window.image,window.result
        require(result is not None, 'Project has no result')
        saved=out/Path(path).name;save_project(saved,image,result); ri,rr=load_project(saved)
        require(np.array_equal(image.raw,ri.raw), 'Large project pixels changed')
        require([c.to_dict() for c in result.candidates]==[c.to_dict() for c in rr.candidates], 'Large project review changed')
        start=time.perf_counter(); target=export_bundle(image,result,out); export_seconds=time.perf_counter()-start
        record={'project':Path(path).name,'candidates':result.count,'load_and_display_seconds':elapsed,
                'export_seconds':export_seconds,'export':target,'raw_equal':True,'review_equal':True,
                'recovery':recovery_summary(result),'central':central_summary(result)}
        reports.append(record)
        window.resize(1500,980)
        for _ in range(5):app.processEvents()
        window.view.fit_image();window.grab().save(str(out/(Path(path).stem+'_opened.png')))
    (out/'projects.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2),encoding='utf8')
    return reports
