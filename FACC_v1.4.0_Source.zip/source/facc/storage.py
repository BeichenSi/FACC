import base64
import csv
from dataclasses import asdict, fields
from datetime import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import zipfile
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from . import __version__, AUTHOR, CONTACT, APP_FULL_NAME
from .image_io import from_array
from .models import Candidate, CountResult, Parameters, REASONS, STATE_LABELS
from .intensity import CHANNELS, REGIONS, METRICS, STATUS, intensity_status, fluorescence_rows, interior_label_image, validate_rois
from .central_nuclei import fiber_status, central_summary
from .recovery import recovery_status,recovery_summary,COLORS as RECOVERY_COLORS
from .recovery_export import HEADERS as RECOVERY_HEADERS,recovery_values,write_recovery_csv,write_coverage_sensitivity,recovery_note
from .project_io import read_project, check_cancel


CENTRAL_LABELS = {'positive': '中央核肌纤维', 'negative': '未检出内部核', 'unclassified': '未判定'}
CENTRAL_COLORS = {'positive': '#ff79c6', 'negative': '#69dbc1', 'unclassified': '#aab4c3'}


def has_central_analysis(result):
    return bool(result.parameters.central_enabled or result.metadata.get('central_nuclei') or any(c.central_nuclei for c in result.candidates))


def resolved_nuclei(result):
    """Resolve current fiber identities from saved per-candidate nuclear references.

    Original metadata IDs can become stale after deleting or renumbering fibers.
    Keep the nuclear detection record, but never reuse its original assignment.
    Manual status overrides do not create or erase a nuclear detection.
    """
    nuclei = {n['id']: dict(n) for n in result.metadata.get('central_nuclei', {}).get('nuclei', [])}
    owners = {}
    for c in result.candidates:
        for n in c.central_nuclei.get('nuclei', []):
            nuclei.setdefault(n['id'], dict(n))
            owners.setdefault(n['id'], []).append(c)
    rows = []
    for nid in sorted(nuclei):
        n = nuclei[nid]
        # These neighboring identities describe the original analysis snapshot,
        # not current candidates after review, deletion, or renumbering.
        for key in ('centroid_fiber_id', 'overlapping_fiber_ids'):
            if key in n:
                n['analysis_time_' + key] = n.pop(key)
        matches = owners.get(nid, [])
        n['accepted_fiber_id'] = matches[0].id if len(matches) == 1 else None
        n['fiber_status'] = fiber_status(matches[0]) if len(matches) == 1 else None
        n['assignment_status'] = 'assigned' if len(matches) == 1 else ('ambiguous' if matches else 'unassigned')
        if len(matches) == 1:
            reference = next(item for item in matches[0].central_nuclei.get('nuclei', []) if item['id'] == nid)
            n['inside_fraction'] = reference.get('inside_fraction', n.get('inside_fraction'))
        rows.append(n)
    return rows


def central_export_summary(result):
    return dict(central_summary(result), enabled=has_central_analysis(result),
                definition='Each accepted myofiber is counted once if at least one nucleus is assigned inside its segmented interior. Exact geometric centering is not required.',
                denominator='All current myofiber candidates, including unclassified candidates.',
                incomplete_interpretation='When unclassified_fibers > 0, the reported positive/total ratio is a lower bound pending classification; automatic segmentation and nuclear assignment also require review.')


def asset_path(name):
    root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent))
    return root / "assets" / name


def safe_stem(name):
    stem = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', Path(name).stem).strip('. ')[:100]
    return stem or 'image'


def summary_dict(image, result):
    analysis = dict(result.metadata)
    if has_central_analysis(result):
        analysis['central_nuclei'] = dict(analysis.get('central_nuclei', {}), nuclei=resolved_nuclei(result))
    return {
        "software": "FACC", "full_name": APP_FULL_NAME, "version": __version__,
        "author": AUTHOR, "contact": CONTACT, "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "image_name": image.name, "source_path": image.source_path, "page_index": image.page,
        "width": image.width, "height": image.height, "total_candidates": result.count,
        "review_needed": result.review_count, "confirmed_by_user": result.confirmed_count,
        "automatically_detected_unconfirmed": sum(c.state == 'automatic' for c in result.candidates),
        "edited_by_user": result.edited, "parameters": asdict(result.parameters),
        "analysis": analysis, "image_metadata": image.metadata,
        "coordinate_system": "0-based original-image pixel coordinates; x right, y down",
        "area_definition": "segmented interior area; not a validated full-cell cross-sectional area",
        "fluorescence": result.metadata.get('fluorescence', {}),
        "intensity_measured_candidates": sum(bool(c.intensity.get('measurements')) for c in result.candidates),
        "intensity_missing_candidates": sum(not bool(c.intensity.get('measurements')) for c in result.candidates),
        "central_nucleation": central_export_summary(result),
        "dystrophin_recovery":dict(recovery_summary(result),enabled=result.parameters.recovery_enabled),
        "interpretation": "Candidate count. Review labels are flags, not calibrated probabilities or stain-positivity categories.",
    }


def _atomic_path(path, writer):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix=".facc_", suffix=path.suffix, dir=str(path.parent))
    os.close(fd)
    try:
        writer(Path(temp))
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def candidate_records(result):
    # Read-only serialization views: no recursive copy of every ROI and membrane
    # coordinate. GUI editing is disabled while an export/save worker is active.
    keys = [field.name for field in fields(Candidate)]
    return [{key: getattr(candidate, key) for key in keys} for candidate in result.candidates]


def _write_project(path, image, summary, records):
    manifest = dict(summary, format='facc-project', format_version=4, candidates=records)
    def write(target):
        with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=1) as z:
            # Compact JSON uses the accelerated encoder and retains every value.
            z.writestr('project.json', json.dumps(manifest, ensure_ascii=False, separators=(',', ':')))
            with z.open('raw.npy', 'w', force_zip64=True) as raw_stream:
                np.save(raw_stream, image.raw, allow_pickle=False)
    _atomic_path(path, write)


def save_project(path, image, result):
    result.validate(image)
    _write_project(path, image, summary_dict(image, result), candidate_records(result))


def load_project(path, progress=None, cancel=None):
    progress = progress or (lambda n, s: None)
    doc, raw = read_project(path, progress, cancel)
    progress(80, '恢复图像显示与编号')
    image = from_array(raw, doc['image_name'], doc.get('source_path', ''), doc.get('page_index', 0), doc.get('image_metadata'))
    result = CountResult([Candidate.from_dict(c) for c in doc['candidates']], Parameters.from_dict(doc['parameters']), doc.get('analysis', {}), doc.get('edited_by_user', False))
    result.validate(image)
    progress(90, '核对测量区域与项目数据')
    for index, candidate in enumerate(result.candidates):
        if index % 100 == 0: check_cancel(cancel)
        validate_rois(candidate, image)
    check_cancel(cancel); progress(100, '项目已读取')
    return image, result


def write_csv(path, candidates, slots=None):
    slots = slots or sorted({(m['region'], m['channel']) for c in candidates for m in c.intensity.get('measurements', [])})
    extra = ['荧光测量状态', '输入数据类型', '边界周带宽度px']
    for region, channel in slots:
        prefix = REGIONS[region] + '_' + CHANNELS[channel] + '_'
        extra += [prefix+'有效像素数'] + [prefix+v for v in METRICS.values()]
    with open(path, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(['编号', 'X像素', 'Y像素', '状态', '复核原因', '候选内部面积px2', '来源', '备注'] + extra + ['中央核判定', '自动内部核数', '内部核编号', '中央核人工修正', '中央核复核提示']+RECOVERY_HEADERS)
        for c in candidates:
            values = [STATUS.get(intensity_status(c), '未测量'), c.intensity.get('raw_dtype', ''), c.intensity.get('boundary_width_px', '')]
            lookup = {(m['region'], m['channel']): m for m in c.intensity.get('measurements', [])}
            for slot in slots:
                m = lookup.get(slot, {})
                values += [m.get('pixel_count', '')] + [m.get(k, '') for k in METRICS]
            cn = c.central_nuclei
            biological = [CENTRAL_LABELS[fiber_status(c)], len(cn.get('nuclei', [])) if cn else '', ';'.join(str(n['id']) for n in cn.get('nuclei', [])), CENTRAL_LABELS.get(cn.get('override'), ''), '；'.join(cn.get('review_flags', []))]
            w.writerow([c.id, c.x, c.y, STATE_LABELS[c.state], '；'.join(REASONS.get(k, k) for k in c.flags), '' if c.interior_area_px is None else c.interior_area_px, c.origin, c.note] + values + biological+recovery_values(c))


def write_central_csv(path, candidates):
    with open(path, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(['肌纤维编号', 'X像素', 'Y像素', '中央核判定', '状态代码', '自动内部核数', '内部核编号', '自动判定', '人工修正', '复核状态', '中央核复核提示', '说明'])
        for c in candidates:
            cn = c.central_nuclei
            w.writerow([c.id, c.x, c.y, CENTRAL_LABELS[fiber_status(c)], fiber_status(c), len(cn.get('nuclei', [])) if cn else '', ';'.join(str(n['id']) for n in cn.get('nuclei', [])), CENTRAL_LABELS.get(cn.get('auto_status'), '未判定'), CENTRAL_LABELS.get(cn.get('override'), ''), STATE_LABELS[c.state], '；'.join(cn.get('review_flags', [])), cn.get('reason', '')])


def write_nuclei_csv(path, result):
    with open(path, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(['核编号', 'X像素', 'Y像素', '核面积px2', '当前归属肌纤维编号', '归属状态', '内部重叠比例', '当前肌纤维中央核判定', '复核提示'])
        for n in resolved_nuclei(result):
            w.writerow([n['id'], n.get('x', ''), n.get('y', ''), n.get('area_px', ''), n['accepted_fiber_id'], {'assigned': '已分配内部核', 'unassigned': '未分配到当前肌纤维', 'ambiguous': '多个候选引用，需复核'}[n['assignment_status']], n.get('inside_fraction', ''), CENTRAL_LABELS.get(n['fiber_status'], ''), '；'.join(n.get('review_flags', []))])


def write_fluorescence_csv(path, candidates):
    with open(path, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(['编号', '复核状态', '测量状态', '区域', '通道', '有效像素数'] + list(METRICS.values()) + ['边界周带宽度px', '输入数据类型', '单位'])
        for c, m in fluorescence_rows(candidates):
            row = [c.id, STATE_LABELS[c.state], STATUS['empty'] if m is not None and not m['pixel_count'] else STATUS.get(intensity_status(c), '未测量')]
            if m:
                row += [REGIONS[m['region']], CHANNELS[m['channel']], m['pixel_count']] + [m[k] for k in METRICS]
            else:
                row += [''] * (3+len(METRICS))
            row += [c.intensity.get('boundary_width_px', ''), c.intensity.get('raw_dtype', ''), '原始输入强度 a.u.；积分为像素强度之和']
            w.writerow(row)


def annotated_image(image, result, font_size=12, central=False, show_nuclei=False,recovery=False):
    out = Image.fromarray(image.display).copy()
    try:
        font = ImageFont.truetype('C:/Windows/Fonts/arial.ttf', int(font_size))
    except OSError:
        font = ImageFont.load_default(size=int(font_size))
    d = ImageDraw.Draw(out)
    if show_nuclei:
        for n in resolved_nuclei(result):
            x, y = n.get('x'), n.get('y')
            if x is None or y is None:
                continue
            radius = max(3, min(12, float(n.get('area_px', 30) / np.pi) ** .5))
            color = '#ffe066' if n['accepted_fiber_id'] is not None else '#93b9d6'
            d.ellipse((x-radius, y-radius, x+radius, y+radius), outline='#000000', width=3)
            d.ellipse((x-radius, y-radius, x+radius, y+radius), outline=color, width=1)
    for c in result.candidates:
        color = CENTRAL_COLORS[fiber_status(c)] if central else ((255, 174, 86) if c.review_needed else ((99, 200, 255) if c.state == 'confirmed' else (166, 239, 120)))
        if recovery:color=RECOVERY_COLORS[recovery_status(c)]
        d.text((c.x, c.y), str(c.id), font=font, fill=color, stroke_width=max(1, font_size // 12), stroke_fill=(0, 0, 0), anchor='mm')
    return out


def export_bundle(image, result, parent, progress=None, font_size=12):
    result.validate(image)
    progress = progress or (lambda value, message: None)
    parent = Path(parent)
    parent.mkdir(parents=True, exist_ok=True)
    base = safe_stem(image.name) + '_FACC_' + datetime.now().strftime('%Y%m%d_%H%M%S')
    target = parent / base
    n = 2
    while target.exists():
        target = parent / (base + '_' + str(n)); n += 1
    target.mkdir()
    incomplete = target / 'EXPORT_INCOMPLETE.txt'
    incomplete.write_text('Export in progress. This marker is removed only after all files are written.', encoding='utf-8')
    progress(5, "生成全分辨率编号图")
    rendered = annotated_image(image, result, font_size)
    rendered.save(target / 'numbered.png', compress_level=3)
    rendered.save(target / 'numbered.tif', compression='tiff_lzw')
    progress(30, "导出编号与待复核清单")
    slots = sorted({(m['region'], m['channel']) for c in result.candidates for m in c.intensity.get('measurements', [])})
    write_csv(target / 'cells.csv', result.candidates, slots)
    write_csv(target / 'review_needed.csv', [c for c in result.candidates if c.review_needed], slots)
    write_fluorescence_csv(target / 'fluorescence.csv', result.candidates)
    central_enabled = has_central_analysis(result)
    if result.parameters.recovery_enabled:
        write_recovery_csv(target/'recovery_fibers.csv',result)
        write_coverage_sensitivity(target/'recovery_coverage_sensitivity.csv',result)
        annotated_image(image,result,font_size,recovery=True).save(target/'recovery_numbered.png', compress_level=3)
    if central_enabled:
        write_central_csv(target / 'central_fibers.csv', result.candidates)
        write_nuclei_csv(target / 'nuclei.csv', result)
        annotated_image(image, result, font_size, central=True, show_nuclei=True).save(target / 'central_nucleation.png', compress_level=3)
    Image.fromarray(interior_label_image(image, result)).save(target / 'interior_roi_labels.tif', compression='tiff_adobe_deflate')
    manifest = summary_dict(image, result)
    records = candidate_records(result)
    (target / 'summary.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    progress(45, "生成离线缩放查看文件")
    source_buf = io.BytesIO(); Image.fromarray(image.display).save(source_buf, format='PNG', compress_level=3)
    encoded = base64.b64encode(source_buf.getvalue()).decode('ascii')
    data = {'summary': manifest, 'cells': [{k:v for k,v in record.items() if k != 'roi'} for record in records], 'reasons': REASONS, 'states': STATE_LABELS,
            'nuclei': resolved_nuclei(result) if central_enabled else [], 'central_labels': CENTRAL_LABELS, 'central_colors': CENTRAL_COLORS}
    serialized = json.dumps(data, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c')
    template = asset_path('viewer.html').read_text(encoding='utf-8')
    template = template.replace('__FACC_DATA__', serialized).replace('__FACC_IMAGE__', encoded)
    (target / 'viewer.html').write_text(template, encoding='utf-8')
    svg = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{image.width}" height="{image.height}" viewBox="0 0 {image.width} {image.height}">', f'<metadata>FACC {__version__}; author {AUTHOR}; {CONTACT}; {result.count} candidate profiles</metadata>', f'<image width="{image.width}" height="{image.height}" href="data:image/png;base64,{encoded}"/>', f'<g id="numbers" font-family="Arial,sans-serif" font-size="{font_size}" text-anchor="middle" dominant-baseline="central" stroke="black" stroke-width="1.5" paint-order="stroke fill">']
    for c in result.candidates:
        color = '#ffae56' if c.review_needed else ('#63c8ff' if c.state == 'confirmed' else '#a6ef78')
        svg.append(f'<text id="cell-{c.id}" x="{c.x}" y="{c.y}" fill="{color}">{c.id}</text>')
    svg.append('</g></svg>')
    (target / 'numbered.svg').write_text('\n'.join(svg), encoding='utf-8')
    progress(70, "保存可继续复核的项目")
    _write_project(target / 'project.facc', image, manifest, records)
    note = f'''FACC — {APP_FULL_NAME}
作者：{AUTHOR}
联系方式：{CONTACT}
版本：{__version__}

图像：{image.name}
候选总数：{result.count}
待复核：{result.review_count}
已由用户确认：{result.confirmed_count}
尺寸：{image.width} × {image.height} 像素

numbered.png / numbered.tif：全分辨率编号图。
numbered.svg：原图与编号图层，可编辑文字。
viewer.html：离线缩放查看器，可搜索编号、对照原图。
cells.csv：全部编号与坐标。review_needed.csv：待复核清单。
fluorescence.csv：每个编号、区域、通道一行的荧光统计；cells.csv 同时附加强度列。
interior_roi_labels.tif：候选内部测量区域图，像素值等于编号，0 为区域外；不是荧光图。
project.facc：包含图像数据与当前编号，可在 FACC 中继续复核。
summary.json：参数、分析过程信息与计数摘要。

绿色为自动识别；橙色为待复核；蓝色为用户已确认。颜色不表示染色阳性/阴性。
本结果为候选计数，自动结果尚未逐个确认。小对象、弱边界和强染色可造成漏计或误计。
坐标原点为原始图像左上角，X 向右、Y 向下，单位为像素（从 0 开始）。
“候选内部面积”不是可靠的整细胞截面积；本软件没有自动推断显微镜物理比例尺。
删除或补充编号后，编号可能不连续；可在软件内使用“重新编号”。
原始 16 位数据保存在项目中；显示和编号图为 8 位 RGB，强度缩放范围见 summary.json。

荧光数值读取输入文件的原始像素，未使用显示缩放；没有背景扣除或曝光归一化。
均值、中位数、最小值、最大值和标准差为原始输入强度单位；积分强度为像素值之和。
内部区域来自自动分割；周带为内部向外指定像素宽度的采样带，排除计数时所有已接受的内部区域。
周带是膜周边的近似区域；相邻周带可能共享膜像素，其积分不能直接相加作为全图唯一总强度。
人工补加编号没有分割区域时，强度留空；移动编号保留原测量区域。旧项目无测量数据时需重新分析。
项目保存内部与周带的实际掩膜，删除或重新编号不会改变其他候选的测量区域。
'''
    if result.parameters.recovery_enabled:note+=recovery_note(result)
    if central_enabled:
        stats = central_summary(result)
        pct = '无定义（分母为 0）' if stats['ratio_percent'] is None else f"{stats['ratio_percent']:.4f}%"
        note += f'''
中央核肌纤维分析
肌纤维候选总数：{stats['total_fibers']}；中央核肌纤维：{stats['central_fibers']}；比例：{pct}。
未检出内部核：{stats['noncentral_fibers']}；未判定：{stats['unclassified_fibers']}。
每根肌纤维只计一次：至少一个 DAPI 核符合内部归属条件，即记为中央核肌纤维，不要求核恰在几何中心。
分母为当前所有肌纤维候选，包含未判定候选；有未判定时，所列比例为完成分类前的下限。
中央核判定与“待复核/已人工确认”分开保存。人工修正可改变生物学判定，不会虚构或删除核检测记录。
central_nucleation.png：全分辨率生物学分类编号图及核圆圈；配色说明见本文件和离线查看器。
central_fibers.csv：每根肌纤维一行，含最终判定、自动内部核数、核编号及人工修正。
nuclei.csv：每个核检测对象一行；归属编号按当前候选解析，删除或重新编号不会导出旧归属编号。
viewer.html：可切换“中央核判定”配色、核标记和中央核候选筛选；显示动态核归属的静态导出快照。
粉色编号：中央核；青绿色编号：未检出内部核；灰色编号：未判定。黄色核圈：已归属内部核；浅蓝核圈：未分配。
“未检出内部核”是当前图像与参数下的结果，不等同于已证明无核；分割误差、DAPI 漏检和边缘核仍需复核。
红/紫色血影蛋白用于肌纤维分割，绿色 dystrophin 不用于选择分母。默认核信号为 max(蓝-红,0)，减少紫色膜的蓝色分量。
合并图不能恢复原始独立染色通道；伪彩比例、饱和、压缩或串色会影响核检测。优先用原始配准通道复核。
'''
    (target / '使用说明.txt').write_text(note, encoding='utf-8-sig')
    incomplete.unlink()
    progress(100, "导出完成")
    return str(target)
