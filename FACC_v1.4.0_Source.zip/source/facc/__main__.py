import argparse
import json
import logging
import os
from pathlib import Path
import sys
import traceback


def main():
    parser = argparse.ArgumentParser(description='FACC — Fully automatic cell counting. Author: qianghw <qianghw@foxmail.com>')
    parser.add_argument('--input', nargs='+', help='Images to count without opening the GUI')
    parser.add_argument('--output', help='Parent directory for exported results')
    parser.add_argument('--config', help='JSON file containing counting parameters')
    parser.add_argument('--mode', choices=['membrane', 'bright'])
    parser.add_argument('--channel', choices=['auto', 'red', 'green', 'blue', 'gray'])
    parser.add_argument('--central-nuclei', action='store_true', help='Classify myofibers with at least one internal DAPI nucleus in an RGB merge')
    parser.add_argument('--dystrophin-recovery', action='store_true', help='Count spectrin-defined fibers positive for membrane dystrophin')
    parser.add_argument('--recovery-sample', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--open', dest='open_path', help='Open an image in the GUI')
    parser.add_argument('--smoke-test', metavar='DIRECTORY', help=argparse.SUPPRESS)
    parser.add_argument('--sample', help=argparse.SUPPRESS)
    parser.add_argument('--central-sample', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--project-samples', nargs='+', help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.smoke_test:
        os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
        log_dir = Path(args.smoke_test)
    else:
        log_dir = Path(os.environ.get('FACC_DATA_DIR') or Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'FACC' / 'logs')
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        logging.basicConfig(filename=str(log_dir / 'FACC.log'), level=logging.INFO, encoding='utf-8', format='%(asctime)s %(levelname)s %(message)s')
    except OSError:
        logging.basicConfig(level=logging.INFO)
    try:
        if args.smoke_test:
            from .qa import smoke_test
            report = smoke_test(args.smoke_test, args.sample, args.central_sample, args.recovery_sample, args.project_samples)
            if sys.stdout: print(json.dumps(report, ensure_ascii=False, indent=2))
            return 0
        if args.input:
            if not args.output: parser.error('--input requires --output')
            from .image_io import load_image
            from .engine import count_cells
            from .models import Parameters
            from .storage import export_bundle
            params_data = json.loads(Path(args.config).read_text(encoding='utf-8-sig')) if args.config else {}
            if args.mode: params_data['mode'] = args.mode
            if args.channel: params_data['channel'] = args.channel
            if args.central_nuclei: params_data['central_enabled'] = True
            if args.dystrophin_recovery: params_data['recovery_enabled'] = True
            params = Parameters.from_dict(params_data)
            reports = []
            for path in args.input:
                try:
                    image = load_image(path); result = count_cells(image, params); target = export_bundle(image, result, args.output)
                    item = {'input': path, 'count': result.count, 'review_needed': result.review_count, 'output': target, 'status': 'ok'}
                    if result.parameters.central_enabled:
                        from .central_nuclei import central_summary
                        item['central_nuclei'] = central_summary(result)
                    if result.parameters.recovery_enabled:
                        from .recovery import recovery_summary
                        item['dystrophin_recovery']=recovery_summary(result)
                    reports.append(item)
                except Exception as e:
                    logging.exception('CLI input failed'); reports.append({'input': path, 'status': 'failed', 'error': str(e)})
            Path(args.output).mkdir(parents=True, exist_ok=True)
            report_path = Path(args.output) / 'FACC_cli_report.json'
            report_path.write_text(json.dumps(reports, ensure_ascii=False, indent=2), encoding='utf-8')
            if sys.stdout: print(json.dumps(reports, ensure_ascii=False, indent=2))
            return 1 if any(r['status'] != 'ok' for r in reports) else 0
        from .gui import run_gui
        return run_gui(args.open_path)
    except Exception as e:
        logging.exception('FACC fatal error')
        if args.smoke_test:
            (Path(args.smoke_test) / 'smoke_failure.txt').write_text(traceback.format_exc(), encoding='utf-8')
        if sys.stderr: traceback.print_exc()
        if not args.input and not args.smoke_test:
            from PySide6.QtWidgets import QApplication, QMessageBox
            app = QApplication.instance() or QApplication([])
            QMessageBox.critical(None, 'FACC 无法启动', str(e))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
