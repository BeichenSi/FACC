import math
import numpy as np
from PySide6.QtCore import Qt, QRectF, QPointF, Signal
from PySide6.QtGui import QColor, QImage, QPixmap, QFont, QPen, QPainter, QPainterPath
from PySide6.QtWidgets import QGraphicsView, QGraphicsScene, QGraphicsItem, QLabel
from .central_nuclei import fiber_status
from .recovery import recovery_status, COLORS as RECOVERY_COLORS


class AnnotationItem(QGraphicsItem):
    def __init__(self, width, height):
        super().__init__()
        self.rect = QRectF(0, 0, width, height)
        self.candidates = []
        self.selected_id = None
        self.show_numbers = True
        self.only_review = False
        self.central_colors = False
        self.central_filter = 'all'
        self.show_nuclei = False
        self.nuclei = []
        self.internal_nucleus_ids = set()
        self.font_size = 12
        self.classification_kind='central';self.show_membrane=False
        self.setZValue(10)

    def boundingRect(self):
        return self.rect

    def candidate_visible(self, candidate):
        if self.only_review and not candidate.review_needed: return False
        data=candidate.recovery if self.classification_kind=='recovery' else candidate.central_nuclei
        if self.central_filter == 'nuclear_review': return bool(data.get('review_flags'))
        status=recovery_status(candidate) if self.classification_kind=='recovery' else fiber_status(candidate)
        return self.central_filter == 'all' or status == self.central_filter

    def paint(self, painter, option, widget=None):
        scale = max(.001, math.hypot(painter.worldTransform().m11(), painter.worldTransform().m12()))
        exposed = option.exposedRect.adjusted(-40, -40, 40, 40)
        font = QFont('Arial'); font.setPixelSize(self.font_size)
        painter.setFont(font)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        if self.show_nuclei:
            review_ids = {n['id'] for c in self.candidates if self.candidate_visible(c) for n in (getattr(c, 'central_nuclei', {}) or {}).get('nuclei', [])} if self.only_review or self.central_filter != 'all' else None
            selected_nuclei = {n['id'] for c in self.candidates if c.id == self.selected_id for n in (getattr(c, 'central_nuclei', {}) or {}).get('nuclei', [])}
            for n in self.nuclei:
                if review_ids is not None and n['id'] not in review_ids: continue
                point = QPointF(float(n['x']), float(n['y']))
                if not exposed.contains(point): continue
                color = QColor('#ffe066' if n['id'] in self.internal_nucleus_ids else '#93b9d6')
                pen = QPen(color, 1.4 if n['id'] in self.internal_nucleus_ids else .8); pen.setCosmetic(True)
                painter.setPen(pen); painter.setBrush(Qt.BrushStyle.NoBrush)
                radius = max(2 / scale, math.sqrt(max(1, float(n.get('area_px', 8))) / math.pi))
                painter.drawEllipse(point, radius, radius)
                if scale >= 1.4 and n['id'] in selected_nuclei:
                    label_font = QFont('Arial'); label_font.setPixelSize(9)
                    path = QPainterPath(); path.addText(point.x() + radius + 2, point.y(), label_font, 'N' + str(n['id']))
                    painter.strokePath(path, QPen(QColor('#010305'), 1.4)); painter.fillPath(path, color)
        text = self.show_numbers and scale >= .5
        painter.setPen(Qt.PenStyle.NoPen)
        for c in self.candidates:
            if not self.candidate_visible(c):
                continue
            if not exposed.contains(QPointF(c.x, c.y)):
                continue
            color = QColor({'positive': '#ff79c6', 'negative': '#69dbc1', 'unclassified': '#aab4c3'}.get(fiber_status(c), '#aab4c3')) if self.central_colors else QColor('#ffae56' if c.review_needed else ('#63c8ff' if c.state == 'confirmed' else '#a6ef78'))
            if self.central_colors and self.classification_kind=='recovery':color=QColor(RECOVERY_COLORS[recovery_status(c)])
            if text:
                path = QPainterPath()
                metrics = painter.fontMetrics()
                label = str(c.id)
                path.addText(c.x - metrics.horizontalAdvance(label) / 2, c.y + (metrics.ascent() - metrics.descent()) / 2, font, label)
                # Paint the halo first: drawing a thick outline last would hide thin digits.
                painter.strokePath(path, QPen(QColor('#010305'), max(1.3, self.font_size / 8)))
                painter.fillPath(path, color)
            else:
                painter.setPen(Qt.PenStyle.NoPen); painter.setBrush(color)
                radius = max(1.6, .7 / scale)
                painter.drawEllipse(QPointF(c.x, c.y), radius, radius)
        chosen = next((c for c in self.candidates if c.id == self.selected_id), None)
        if chosen and self.candidate_visible(chosen):
            if self.show_membrane:
                data=chosen.recovery
                for (x,y),valid,positive in zip(data.get('membrane_xy',[]),data.get('spectrin_supported',[]),data.get('positive_samples',[])):
                    pen=QPen(QColor('#ffe066' if positive else ('#db88ea' if valid else '#9099a7')),2);pen.setCosmetic(True);painter.setPen(pen);painter.drawPoint(QPointF(x,y))
            pen = QPen(QColor('#ffffff'), 2); pen.setCosmetic(True)
            painter.setPen(pen); painter.setBrush(Qt.BrushStyle.NoBrush)
            radius = max(15, 16 / scale)
            painter.drawEllipse(QPointF(chosen.x, chosen.y), radius, radius)


class ImageCanvas(QGraphicsView):
    selected = Signal(int)
    add_requested = Signal(float, float)
    move_requested = Signal(int, float, float)
    zoom_changed = Signal(float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setScene(QGraphicsScene(self))
        self.setBackgroundBrush(QColor('#050810'))
        self.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.ViewportAnchor.AnchorViewCenter)
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)
        self.setFrameShape(QGraphicsView.Shape.NoFrame)
        self.overlay = None
        self.width_px = self.height_px = 0
        self.edit_mode = 'browse'
        self._press = None
        self._moving_id = None
        self.setAcceptDrops(True); self.viewport().setAcceptDrops(True)
        self.placeholder = QLabel('将图像拖入这里\n松开后使用当前参数自动分析\n\n支持 TIFF / PNG / JPEG / BMP\n多张图像可批量处理；也可拖入 FACC 项目', self.viewport())
        self.placeholder.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.placeholder.setWordWrap(True)
        self.placeholder.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.placeholder.setStyleSheet('color:#91b7cf;font-size:14px;background:transparent;padding:10px')

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, 'placeholder'):
            self.placeholder.setGeometry(12, 12, max(1, self.viewport().width()-24), max(1, self.viewport().height()-24))

    def set_image(self, array):
        self.placeholder.hide()
        a = np.ascontiguousarray(array)
        self.height_px, self.width_px = a.shape[:2]
        qimage = QImage(a.data, self.width_px, self.height_px, a.strides[0], QImage.Format.Format_RGB888).copy()
        self.scene().clear()
        self.scene().addPixmap(QPixmap.fromImage(qimage))
        self.overlay = AnnotationItem(self.width_px, self.height_px)
        self.scene().addItem(self.overlay)
        self.scene().setSceneRect(0, 0, self.width_px, self.height_px)
        self.resetTransform()
        self.fit_image()

    def set_candidates(self, candidates):
        if self.overlay:
            self.overlay.candidates = candidates
            self.overlay.internal_nucleus_ids = {n['id'] for c in candidates for n in (getattr(c, 'central_nuclei', {}) or {}).get('nuclei', [])}
            self.overlay.update()

    def set_central_data(self, nuclei):
        if self.overlay:
            self.overlay.nuclei = nuclei
            self.overlay.update()

    def fit_image(self):
        if self.width_px:
            self.fitInView(self.sceneRect(), Qt.AspectRatioMode.KeepAspectRatio)
            self.zoom_changed.emit(self.transform().m11())

    def zoom(self, factor):
        current = self.transform().m11()
        desired = min(10, max(.02, current * factor))
        self.scale(desired / current, desired / current)
        self.zoom_changed.emit(desired)

    def select_id(self, cid, center=False):
        if not self.overlay:
            return
        self.overlay.selected_id = cid
        if center:
            c = next((c for c in self.overlay.candidates if c.id == cid), None)
            if c:
                if self.transform().m11() < 1.4:
                    self.zoom(1.4 / self.transform().m11())
                self.centerOn(c.x, c.y)
        self.overlay.update()

    def set_mode(self, mode):
        self.edit_mode = mode
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag if mode == 'browse' else QGraphicsView.DragMode.NoDrag)
        self.viewport().setCursor(Qt.CursorShape.OpenHandCursor if mode == 'browse' else Qt.CursorShape.CrossCursor)

    def nearest(self, point):
        if not self.overlay:
            return None
        maximum = max(6, 14 / self.transform().m11())
        chosen = None
        for c in self.overlay.candidates:
            if not self.overlay.candidate_visible(c):
                continue
            d = math.hypot(c.x - point.x(), c.y - point.y())
            if d < maximum:
                chosen, maximum = c, d
        return chosen

    def wheelEvent(self, event):
        if self.width_px:
            self.zoom(math.exp(event.angleDelta().y() * .0015))
        event.accept()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._press = event.position()
            if self.edit_mode == 'move':
                c = self.nearest(self.mapToScene(event.position().toPoint()))
                self._moving_id = c.id if c else None
                if c:
                    self.selected.emit(c.id)
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and self._press is not None:
            point = self.mapToScene(event.position().toPoint())
            moved = (event.position() - self._press).manhattanLength() > 4
            inside = 0 <= point.x() < self.width_px and 0 <= point.y() < self.height_px
            if self.edit_mode == 'move' and self._moving_id is not None and inside:
                self.move_requested.emit(self._moving_id, point.x(), point.y())
            elif not moved and inside:
                if self.edit_mode == 'add':
                    self.add_requested.emit(point.x(), point.y())
                else:
                    c = self.nearest(point)
                    if c:
                        self.selected.emit(c.id)
            self._press = None
            self._moving_id = None
        super().mouseReleaseEvent(event)
