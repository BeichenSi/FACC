import copy
import csv
from dataclasses import asdict
from datetime import datetime
import logging
import os
from pathlib import Path
from threading import Event
import traceback
from PySide6.QtCore import Qt, QThread, Signal, QTimer, QUrl
from PySide6.QtGui import QAction, QDesktopServices, QIcon, QKeySequence, QFontDatabase, QFont, QPalette, QColor
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QComboBox, QDoubleSpinBox, QSpinBox, QCheckBox, QFormLayout,
    QGroupBox, QScrollArea, QSplitter, QFrame, QFileDialog, QMessageBox, QInputDialog,
    QProgressBar, QLineEdit, QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView,
    QButtonGroup, QTabWidget, QDialog, QDialogButtonBox)
from . import APP_FULL_NAME, AUTHOR, CONTACT, __version__
from .canvas import ImageCanvas
from .engine import count_cells, Cancelled
from .image_io import load_image, frame_count
from .models import Parameters, Candidate, CountResult, REASONS, STATE_LABELS
from .storage import export_bundle, save_project, load_project, asset_path
from .ui_helpers import FileDropFilter
from .intensity import CHANNELS, REGIONS, STATUS, intensity_status
from .central_nuclei import fiber_status, central_summary
from .recovery import recovery_status, recovery_summary, LABELS as RECOVERY_LABELS, COLORS as RECOVERY_COLORS
from .preferences import load_defaults, save_defaults, defaults_path

CENTRAL_LABELS = {'positive': '中央核', 'negative': '非中央核', 'unclassified': '未确定'}
CENTRAL_COLORS = {'positive': '#ff79c6', 'negative': '#69dbc1', 'unclassified': '#aab4c3'}


STYLES = '''
QMainWindow,QDialog{background:#101722;color:#e9f0fa} QWidget{font-family:"Noto Sans SC","Microsoft YaHei","Arial";font-size:13px;color:#dbe7f5}QWidget#parametersContent{background:#101722}
QMenuBar,QMenu{background:#182435;color:#dbe7f5}QMenu::item:selected{background:#2b415e}QStatusBar{background:#152030}
QLabel#brand{font-size:29px;font-weight:700;color:#83e1cc}QLabel#subtitle{color:#a5b5cb;font-size:12px}QLabel#muted{color:#8fa2ba;font-size:11px}
QFrame#top{background:#172333;border-bottom:1px solid #2d3e55}QFrame#card{background:#192637;border:1px solid #314159;border-radius:8px}
QLabel#count{font-size:25px;font-weight:650;color:#eef5ff}QLabel#pendingCount{font-size:25px;font-weight:650;color:#ffae56}QLabel#confirmedCount{font-size:25px;font-weight:650;color:#63c8ff}
QLabel#centralCount,QLabel#centralRatio{font-size:25px;font-weight:650;color:#ff91d1}
QPushButton{background:#22344b;border:1px solid #425771;border-radius:5px;padding:7px 10px;color:#ecf4ff;min-height:22px}QPushButton:hover{background:#2e4867}QPushButton:pressed,QPushButton:checked{background:#275e69;border-color:#6ed6c6}QPushButton:disabled{color:#718198;background:#1b293b;border-color:#2c3d51}
QPushButton#primary{background:#147a71;border-color:#24b3a3;font-weight:650;padding:10px}QPushButton#primary:hover{background:#198f83}QPushButton#primary:disabled{background:#24403f;color:#8aaba6}
QComboBox,QSpinBox,QDoubleSpinBox,QLineEdit{background:#111d2d;border:1px solid #3d506a;border-radius:4px;padding:6px;color:#e8f1ff;min-height:22px}QComboBox QAbstractItemView{background:#20324b;color:#e8f1ff;selection-background-color:#32647a}
QSpinBox,QDoubleSpinBox{padding:4px 34px 4px 8px;min-height:32px}
QSpinBox::up-button,QDoubleSpinBox::up-button{subcontrol-origin:border;subcontrol-position:top right;width:29px;border-left:1px solid #506985;border-bottom:1px solid #506985;border-top-right-radius:4px;background:#29435e}
QSpinBox::down-button,QDoubleSpinBox::down-button{subcontrol-origin:border;subcontrol-position:bottom right;width:29px;border-left:1px solid #506985;border-bottom-right-radius:4px;background:#29435e}
QSpinBox::up-button:hover,QDoubleSpinBox::up-button:hover,QSpinBox::down-button:hover,QDoubleSpinBox::down-button:hover{background:#3a647c}
QSpinBox::up-button:pressed,QDoubleSpinBox::up-button:pressed,QSpinBox::down-button:pressed,QDoubleSpinBox::down-button:pressed{background:#167f74}
QSpinBox::up-button:disabled,QDoubleSpinBox::up-button:disabled,QSpinBox::down-button:disabled,QDoubleSpinBox::down-button:disabled{background:#1d2b3d}
QSpinBox::up-arrow,QDoubleSpinBox::up-arrow{image:url(__STEP_UP__);width:12px;height:8px}
QSpinBox::down-arrow,QDoubleSpinBox::down-arrow{image:url(__STEP_DOWN__);width:12px;height:8px}
QTabWidget#parameterTabs QTabBar::tab{padding:8px 7px;min-width:25px}
QGroupBox{border:1px solid #2f415a;border-radius:6px;margin-top:12px;padding-top:15px;font-weight:600}QGroupBox::title{subcontrol-origin:margin;left:10px;padding:0 4px;color:#b7c9e0}
QScrollArea{background:#101722;border:0}QScrollBar:vertical{background:#101b2b;width:10px}QScrollBar::handle:vertical{background:#3a4e6c;min-height:20px;border-radius:4px}QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0}
QCheckBox{spacing:6px;padding:3px 0}QCheckBox::indicator{width:14px;height:14px;border:1px solid #56708e;background:#142238;border-radius:3px}QCheckBox::indicator:checked{background:#44bda8;border-color:#8be6d3}
QTableWidget{background:#111c2a;alternate-background-color:#172438;color:#dbe7f5;border:1px solid #304159;gridline-color:#263950;selection-background-color:#2a5067}QHeaderView::section{background:#23334a;border:0;padding:6px;color:#bccfe6}
QTabWidget::pane{border:1px solid #2d4059}QTabBar::tab{background:#1b2a3e;padding:8px 11px}QTabBar::tab:selected{background:#29445d;color:#a5e5d9}QProgressBar{background:#17273a;border:1px solid #354d68;border-radius:4px;text-align:center}QProgressBar::chunk{background:#238e81;border-radius:3px}
QToolTip{background:#24354e;color:#eff7ff;border:1px solid #58738d;padding:5px}
'''


class Worker(QThread):
    progress = Signal(int, str)
    result = Signal(object)
    failed = Signal(str)
    cancelled = Signal()

    def __init__(self, operation, parent=None):
        super().__init__(parent)
        self.operation = operation
        self.cancel_event = Event()

    def run(self):
        try:
            result = self.operation(lambda n, s: self.progress.emit(n, s), self.cancel_event)
            self.result.emit(result)
        except Cancelled:
            self.cancelled.emit()
        except Exception as e:
            logging.exception('FACC operation failed')
            self.failed.emit(str(e) or type(e).__name__)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        configure_application()
        self.setWindowTitle(f'FACC {__version__} — {APP_FULL_NAME}')
        self.setWindowIcon(QIcon(str(asset_path('facc.ico'))))
        available = QApplication.primaryScreen().availableGeometry()
        self.setMinimumSize(min(720, available.width()), min(480, max(1, available.height()-45)))
        self.resize(min(1500, available.width(), max(600, available.width()-70)), min(930, available.height()-40, max(380, available.height()-65)))
        self.image = None; self.result = None; self.worker = None
        self.selected_id = None; self.undo_stack = []; self.dirty = False
        self.last_dir = str(Path.cwd()); self.last_export = ''; self._rows = {}
        self.parameter_widgets = {}; self._busy = False; self._fit_pending = False
        self._setting_parameters = False
        defaults_error = None
        try: self.saved_defaults = load_defaults()
        except ValueError as error:
            self.saved_defaults = Parameters(); defaults_error = str(error)
        self._build_ui(); self._build_menu(); self._refresh()
        self.setStyleSheet(STYLES.replace('__STEP_UP__', asset_path('step-up.svg').as_posix()).replace('__STEP_DOWN__', asset_path('step-down.svg').as_posix()))
        self.set_parameters(self.saved_defaults)
        for widget in self.parameter_widgets.values():
            if isinstance(widget, QComboBox): widget.currentIndexChanged.connect(self._parameters_changed)
            elif isinstance(widget, QCheckBox): widget.toggled.connect(self._parameters_changed)
            else: widget.valueChanged.connect(self._parameters_changed)
        if defaults_error:
            logging.warning(defaults_error)
            self.default_status.setText('默认参数读取失败，已载入出厂设置')
            self.default_status.setToolTip(defaults_error)
            self.statusBar().showMessage(defaults_error)
        self.setAcceptDrops(True); self.drop_filter = FileDropFilter(self)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, 'side_tabs'):
            self._update_adaptive_layout()
            QTimer.singleShot(0, self._update_detail_height)

    def _update_adaptive_layout(self):
        short = self.height() < 720
        minimal_central = self.height() <= 620 and self._bio_active()
        self.brand_frame.setVisible(not short)
        self.canvas_hint.setVisible(not short)
        self.count_cards_panel.setVisible(not minimal_central)
        self.zoom_toolbar.setVisible(not minimal_central)
        self.compact_fit_button.setVisible(minimal_central)
        for label in (self.total_label, self.pending_label, self.confirmed_label, self.central_count_label, self.central_ratio_label):
            label.setStyleSheet('font-size:19px' if short else '')
            layout = label.parentWidget().layout()
            layout.setDirection(QHBoxLayout.Direction.LeftToRight if short else QHBoxLayout.Direction.TopToBottom)
            layout.setContentsMargins(8, 4 if short else 5, 8, 4 if short else 5)
        compact = self.width() < 1250
        if self._adapting or compact == self._compact: return
        self._adapting = True
        try:
            if compact:
                self.params_panel.setParent(None); self.review_panel.setParent(None)
                self.side_tabs.addTab(self.params_panel, '计数设置'); self.side_tabs.addTab(self.review_panel, '复核与强度')
                self.splitter.insertWidget(0, self.side_tabs); self.side_tabs.show()
                self.side_tabs.setCurrentWidget(self.review_panel if self.selected_id is not None else self.params_panel)
                self.splitter.setSizes([310, max(320, self.width()-325)])
            else:
                self.params_panel.setParent(None); self.review_panel.setParent(None)
                self.side_tabs.setParent(None); self.side_tabs.hide()
                self.splitter.insertWidget(0, self.params_panel); self.splitter.addWidget(self.review_panel)
                self.splitter.setSizes([320, max(320, self.width()-625), 295])
                self.params_panel.show(); self.review_panel.show()
            self._compact = compact
        finally:
            self._adapting = False

    def drop_files(self, paths):
        if self._busy or not paths: return
        if len(paths) == 1 and Path(paths[0]).suffix.lower() == '.facc':
            self.open_project_path(paths[0])
        elif len(paths) == 1:
            self.open_image_path(paths[0], analyze=True)
        else:
            self.batch_count(paths=paths)

    def _button(self, text, slot, primary=False):
        b = QPushButton(text); b.clicked.connect(slot)
        if primary: b.setObjectName('primary')
        return b

    def _build_ui(self):
        from .layout import build_ui
        build_ui(self)

    def _card(self, layout, title, object_name):
        frame = QFrame(); frame.setObjectName('card'); box = QVBoxLayout(frame); box.setContentsMargins(8, 5, 8, 5); box.setSpacing(2)
        value = QLabel('—'); value.setObjectName(object_name); box.addWidget(value)
        label = QLabel(title); label.setWordWrap(True); label.setObjectName('muted'); box.addWidget(label); layout.addWidget(frame, 1)
        value.caption=label
        return value

    def _spin(self, form, title, key, minimum, maximum, default, decimals=0, step=1, suffix='', integer=False):
        w = QSpinBox() if integer else QDoubleSpinBox()
        if not integer: w.setDecimals(decimals)
        w.setRange(minimum, maximum); w.setValue(default); w.setSingleStep(step); w.setSuffix(suffix); w.setMinimumWidth(170); w.setMinimumHeight(42)
        w.setAccelerated(True); w.setKeyboardTracking(False)
        w.setToolTip(f'{title}：点击右上箭头增加、右下箭头减少；也可输入数值或使用键盘上下键。')
        form.addRow(title, w); self.parameter_widgets[key] = w

    def _build_menu(self):
        self.file_actions = []
        file_menu = self.menuBar().addMenu('文件')
        for text, shortcut, slot in [('打开图像', 'Ctrl+O', self.open_image), ('打开项目', 'Ctrl+Shift+O', self.open_project), ('保存项目', 'Ctrl+S', self.save_current_project), ('导出结果', 'Ctrl+E', self.export_current), ('批量计数', '', self.batch_count), ('打开演示图', '', self.open_demo)]:
            a = QAction(text, self); a.triggered.connect(slot)
            if shortcut: a.setShortcut(QKeySequence(shortcut))
            file_menu.addAction(a); self.file_actions.append(a)
        edit_menu = self.menuBar().addMenu('编辑')
        for text, shortcut, slot in [('撤销', 'Ctrl+Z', self.undo), ('删除所选编号', 'Delete', self.delete_selected), ('重新连续编号', '', self.renumber)]:
            a = QAction(text, self); a.triggered.connect(slot)
            if shortcut: a.setShortcut(QKeySequence(shortcut))
            edit_menu.addAction(a)
        help_menu = self.menuBar().addMenu('帮助'); a = QAction('使用说明与关于 FACC', self); a.triggered.connect(self.show_about); help_menu.addAction(a)
        self.parameter_actions = []
        parameter_menu = self.menuBar().addMenu('参数')
        for title, slot in [('将当前参数设为默认', self.save_parameter_defaults), ('载入已保存的默认参数', self.restore_parameter_defaults), ('载入出厂参数', self.restore_factory_parameters)]:
            action = QAction(title, self); action.triggered.connect(slot); parameter_menu.addAction(action); self.parameter_actions.append(action)

    def _parameters_tab_changed(self, index):
        if index >= 0: self.params_scroll = self.parameter_scrolls[index]

    def show_parameter(self, key):
        widget = self.parameter_widgets[key]
        for index, scroll in enumerate(self.parameter_scrolls):
            if scroll.widget().isAncestorOf(widget):
                self.parameter_tabs.setCurrentIndex(index)
                scroll.ensureWidgetVisible(widget)
                break
        return widget

    def _parameters_changed(self, *args):
        if self._setting_parameters: return
        try:
            data = {}
            for key, widget in self.parameter_widgets.items():
                data[key] = widget.currentData() if isinstance(widget, QComboBox) else (widget.isChecked() if isinstance(widget, QCheckBox) else widget.value())
            matches = data == asdict(self.saved_defaults)
            self.default_status.setText(('默认参数：已保存' if defaults_path().exists() else '默认参数：出厂设置') if matches else '当前参数已修改 · 可设为默认')
            self.default_status.setToolTip('默认参数仅在点击“设为默认”时保存。打开项目使用项目参数，不会覆盖默认参数。')
        except (TypeError, ValueError):
            self.default_status.setText('请检查当前参数')

    def save_parameter_defaults(self):
        if self._busy: return
        try:
            parameters = self.get_parameters()
            path = save_defaults(parameters)
            self.saved_defaults = parameters; self._parameters_changed()
            self.statusBar().showMessage('默认参数已保存，下次启动自动载入：' + str(path))
        except Exception as error: self._error(str(error))

    def restore_parameter_defaults(self):
        if self._busy: return
        try:
            self.saved_defaults = load_defaults(); self.set_parameters(self.saved_defaults)
            self.statusBar().showMessage('已载入默认参数；已生成的结果保持其原分析参数。')
        except Exception as error: self._error(str(error))

    def restore_factory_parameters(self):
        if self._busy: return
        self.set_parameters(Parameters())
        self.statusBar().showMessage('当前设置已载入出厂参数；如需以后启动也使用它，请点击“设为默认”。')

    def get_parameters(self):
        data = {}
        for key, w in self.parameter_widgets.items():
            if isinstance(w, QComboBox): data[key] = w.currentData()
            elif isinstance(w, QCheckBox): data[key] = w.isChecked()
            else:
                w.interpretText(); data[key] = w.value()
        return Parameters.from_dict(data)

    def set_parameters(self, p):
        self._setting_parameters = True
        for key, value in asdict(p).items():
            w = self.parameter_widgets.get(key)
            if w is None: continue
            if isinstance(w, QComboBox): w.setCurrentIndex(w.findData(value))
            elif isinstance(w, QCheckBox): w.setChecked(value)
            else: w.setValue(value)
        self.central_settings_changed()
        self._setting_parameters = False
        if hasattr(self, 'default_status'): self._parameters_changed()

    def central_settings_changed(self, checked=False):
        enabled = self.central_check.isChecked()
        self.central_settings.setEnabled(enabled)
        self.recovery_settings.setEnabled(self.recovery_check.isChecked())
        enabled=enabled or self.recovery_check.isChecked()
        self.mode_combo.setEnabled(not enabled)
        self.channel_combo.setEnabled(not enabled)
        explanation = '中央核与 DYS 恢复分析固定使用红色膜信号分割肌纤维。' if enabled else ''
        self.mode_combo.setToolTip(explanation); self.channel_combo.setToolTip(explanation)

    def _central_active(self):
        return self.result is not None and bool(getattr(self.result.parameters, 'central_enabled', False))

    def _recovery_active(self):
        return self.result is not None and self.result.parameters.recovery_enabled

    def _bio_active(self):
        return self._central_active() or self._recovery_active()

    def _bio_kind(self):
        if self._recovery_active() and not self._central_active():return 'recovery'
        return self.analysis_view_combo.currentData() if self._recovery_active() else 'central'

    def _bio_status(self,c):
        return recovery_status(c) if self._bio_kind()=='recovery' else fiber_status(c)

    def _bio_info(self,c):
        return c.recovery if self._bio_kind()=='recovery' else c.central_nuclei

    def _guard_changes(self):
        if not self.dirty: return True
        answer = QMessageBox.question(self, '保留当前结果', '当前结果尚未保存。是否保存项目后继续？', QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel, QMessageBox.StandardButton.Save)
        if answer == QMessageBox.StandardButton.Cancel: return False
        if answer == QMessageBox.StandardButton.Discard: return True
        path, _ = QFileDialog.getSaveFileName(self, '保存项目', str(Path(self.last_dir) / 'FACC_project.facc'), 'FACC 项目 (*.facc)')
        if not path: return False
        try:
            save_project(path, self.image, self.result); self.dirty = False; return True
        except Exception as e:
            self._error(str(e)); return False

    def _start_worker(self, operation, completed, cancellable=False):
        if self._busy: return
        self._busy = True; self.progress_bar.setValue(0); self.progress_bar.show(); self.cancel_button.setVisible(cancellable); self.cancel_button.setEnabled(True)
        self.worker = Worker(operation, self); self.worker.progress.connect(self._progress); self.worker.result.connect(completed); self.worker.failed.connect(self._error); self.worker.cancelled.connect(lambda: self.statusBar().showMessage('已取消；此前的结果已保留。')); self.worker.finished.connect(self._worker_done)
        self._refresh_buttons(); self.worker.start()

    def _worker_done(self):
        old = self.worker; self.worker = None; self._busy = False; self.progress_bar.hide(); self.cancel_button.hide(); self._refresh_buttons()
        if old: old.deleteLater()

    def _progress(self, value, message):
        self.progress_bar.setValue(value); self.statusBar().showMessage(message)

    def _error(self, message):
        self.statusBar().showMessage('操作未完成：' + message)
        QMessageBox.critical(self, '操作未完成', message)

    def cancel_work(self):
        if self.worker:
            self.worker.cancel_event.set(); self.cancel_button.setEnabled(False); self.statusBar().showMessage('正在取消；当前计算步骤结束后停止。')

    def open_image(self):
        if self._busy: return
        path, _ = QFileDialog.getOpenFileName(self, '打开荧光图像', self.last_dir, '图像 (*.tif *.tiff *.png *.jpg *.jpeg *.bmp);;所有文件 (*)')
        if path: self.open_image_path(path)

    def open_demo(self):
        if self._busy or not self._guard_changes(): return
        def loaded(image):
            self.set_parameters(Parameters(largest_tissue=False))
            self._image_loaded(image)
            self.statusBar().showMessage('演示图含 12 个独立膜轮廓，已载入演示参数。点击“开始自动计数”。')
        self._start_worker(lambda progress, cancel: load_image(asset_path('demo_membrane.png')), loaded)

    def open_image_path(self, path, analyze=False):
        if self._busy or not self._guard_changes(): return
        try: frames = frame_count(path)
        except Exception as e: self._error(str(e)); return
        page = 0
        if frames > 1:
            value, ok = QInputDialog.getInt(self, '选择图像页', f'此文件含 {frames} 页。请选择需要计数的页：', 1, 1, frames)
            if not ok: return
            page = value - 1
        self.last_dir = str(Path(path).parent)
        if analyze:
            try: params = self.get_parameters()
            except Exception as e: self._error(str(e)); return
            def operation(progress, cancel):
                image = load_image(path, page)
                return image, count_cells(image, params, progress, cancel)
            def completed(data):
                image, result = data; self._image_loaded(image); self._counted(result)
            self._start_worker(operation, completed, True)
        else:
            self._start_worker(lambda progress, cancel: load_image(path, page), self._image_loaded)

    def _image_loaded(self, image):
        self.image = image; self.result = None; self.selected_id = None; self.undo_stack = []; self.dirty = False
        self.view.set_image(image.display); self.original_check.setChecked(False); self.review_check.setChecked(False)
        self.file_label.setText(f'{image.name}  ·  {image.width:,} × {image.height:,} px' + (f'  ·  第 {image.page+1} 页' if image.metadata.get('total_pages', 1) > 1 else ''))
        self._refresh(); QTimer.singleShot(0, self.view.fit_image)
        self.statusBar().showMessage('图像已打开。选择参数后点击“开始自动计数”。')

    def start_count(self):
        if self._busy or self.image is None: return
        if self.result and self.dirty:
            answer = QMessageBox.question(self, '重新计数', '重新计数将替换当前编号及修正。是否继续？', QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
            if answer != QMessageBox.StandardButton.Yes: return
        try: params = self.get_parameters()
        except Exception as e: self._error(str(e)); return
        image = self.image
        self._start_worker(lambda progress, cancel: count_cells(image, params, progress, cancel), self._counted, True)

    def _counted(self, result):
        self.result = result; self.selected_id = None; self.undo_stack = []; self.dirty = True
        self.original_check.setChecked(False); self._refresh()
        seconds = result.metadata.get('elapsed_seconds', 0)
        message = f'完成：{result.count:,} 个候选，{result.review_count:,} 个待复核，用时 {seconds:.1f} 秒。'
        if self._central_active():
            s = central_summary(result)
            fraction = '—' if s.get('ratio_percent') is None else f'{s["ratio_percent"]:.2f}%'
            message += f' 中央核 {s["central_fibers"]:,}/{s["total_fibers"]:,}（{fraction}）。'
        if self._recovery_active():
            s=recovery_summary(result);fraction='—' if s['ratio_percent'] is None else f'{s["ratio_percent"]:.2f}%'
            message+=f' DYS 恢复候选 {s["recovered_fibers"]:,}/{s["total_fibers"]:,}（{fraction}）。'
        self.statusBar().showMessage(message)

    def open_project(self):
        if self._busy: return
        path, _ = QFileDialog.getOpenFileName(self, '打开 FACC 项目', self.last_dir, 'FACC 项目 (*.facc)')
        if path: self.open_project_path(path)

    def open_project_path(self, path):
        if self._busy or not path or not self._guard_changes(): return
        self.last_dir = str(Path(path).parent)
        self._start_worker(lambda progress, cancel: load_project(path, progress, cancel), self._project_loaded, True)

    def _project_loaded(self, data):
        image, result = data; self._image_loaded(image); self.result = result; self.set_parameters(result.parameters); self.dirty = False; self._refresh()
        message = '项目已载入，可继续复核。'
        if any(not c.intensity for c in result.candidates): message += ' 旧版/人工编号可能无强度；重新分析可生成区域测量。'
        self.statusBar().showMessage(message)

    def save_current_project(self):
        if self._busy or self.result is None: return
        path, _ = QFileDialog.getSaveFileName(self, '保存 FACC 项目', str(Path(self.last_dir) / (Path(self.image.name).stem + '.facc')), 'FACC 项目 (*.facc)')
        if not path: return
        def saved(value): self.dirty = False; self.statusBar().showMessage('项目已保存：' + path)
        self._start_worker(lambda progress, cancel: save_project(path, self.image, self.result), saved)

    def export_current(self):
        if self._busy or self.result is None: return
        folder = QFileDialog.getExistingDirectory(self, '选择导出位置（将新建结果文件夹）', self.last_dir)
        if not folder: return
        self._start_worker(lambda progress, cancel: export_bundle(self.image, self.result, folder, progress), self._exported)

    def _exported(self, folder):
        self.last_export = folder; self.dirty = False
        self.statusBar().showMessage('已导出：' + folder)
        msg = QMessageBox(self); msg.setWindowTitle('导出完成'); msg.setText(f'已导出 {self.result.count:,} 个编号。'); msg.setInformativeText('结果包含 PNG、TIFF、SVG、CSV、离线查看器及可继续复核的项目。\n\n' + folder)
        open_button = msg.addButton('打开结果文件夹', QMessageBox.ButtonRole.ActionRole); msg.addButton('完成', QMessageBox.ButtonRole.AcceptRole); msg.exec()
        if msg.clickedButton() == open_button: QDesktopServices.openUrl(QUrl.fromLocalFile(folder))

    def batch_count(self, checked=False, paths=None):
        if self._busy: return
        if paths is None: paths, _ = QFileDialog.getOpenFileNames(self, '选择批量计数的图像', self.last_dir, '图像 (*.tif *.tiff *.png *.jpg *.jpeg *.bmp)')
        if not paths: return
        folder = QFileDialog.getExistingDirectory(self, '选择批量结果保存位置', self.last_dir)
        if not folder: return
        try: params = self.get_parameters()
        except Exception as e: self._error(str(e)); return
        QMessageBox.information(self, '批量计数', '将使用当前参数处理所选图像，每张图生成独立结果文件夹。多页图像仅处理第 1 页，并在汇总中注明。')
        def operation(progress, cancel):
            rows = []; total = len(paths)
            for i, path in enumerate(paths):
                if cancel.is_set(): break
                progress(int(100 * i / total), f'批量计数 {i+1}/{total}：{Path(path).name}')
                try:
                    image = load_image(path)
                    result = count_cells(image, params, lambda n, s: progress(int(100 * (i + .7 * n/100) / total), f'{i+1}/{total} · {s}'), cancel)
                    if cancel.is_set(): break
                    target = export_bundle(image, result, folder)
                    s = central_summary(result) if result.parameters.central_enabled else {}
                    rs=recovery_summary(result) if result.parameters.recovery_enabled else {}
                    rows.append([path, result.count, result.review_count, image.metadata.get('total_pages', 1), '成功', target, s.get('central_fibers', ''), s.get('ratio_percent', ''), s.get('unclassified_fibers', ''),rs.get('recovered_fibers',''),rs.get('ratio_percent',''),rs.get('unclassified_fibers','')])
                except Cancelled:
                    break
                except Exception as e:
                    logging.exception('Batch file failed'); rows.append([path, '', '', '', '失败：' + str(e), '', '', '', ''])
            report = Path(folder) / ('FACC_batch_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f') + '.csv')
            with open(report, 'w', encoding='utf-8-sig', newline='') as f:
                w = csv.writer(f); w.writerow(['图像', '候选总数', '待复核', '原文件页数_仅处理第一页', '状态', '结果文件夹', '中央核肌纤维数', '中央核占全部肌纤维_百分比', '中央核分类未确定数','DYS恢复候选数','DYS恢复占比_百分比','DYS未确定数']); w.writerows(rows)
            return dict(report=str(report), completed=len(rows), total=total, failed=sum(str(row[4]).startswith('失败') for row in rows), cancelled=cancel.is_set())
        def done(info):
            self.statusBar().showMessage(f'批量处理完成 {info["completed"]}/{info["total"]} 张。')
            QMessageBox.information(self, '批量处理结果', f'已处理 {info["completed"]}/{info["total"]} 张，失败 {info["failed"]} 张。' + ('\n任务已取消，已完成结果已保留。' if info['cancelled'] else '') + '\n\n汇总：' + info['report'])
        self._start_worker(operation, done, True)

    def _snapshot(self):
        self.undo_stack.append(copy.deepcopy(self.result.candidates))
        self.undo_stack = self.undo_stack[-30:]

    def _changed(self):
        self.result.edited = True; self.dirty = True; self.result.validate(self.image); self._refresh()

    def add_candidate(self, x, y):
        if self._busy or self.image is None or self.original_check.isChecked(): return
        if not (0 <= x < self.image.width and 0 <= y < self.image.height): return
        if self.result is None:
            try: self.result = CountResult([], self.get_parameters(), {'manual_only': True})
            except ValueError as e: self._error(str(e)); return
        if any((c.x - x)**2 + (c.y-y)**2 < 9 for c in self.result.candidates):
            self.statusBar().showMessage('此位置已有编号，请选择其他位置。'); return
        self._snapshot(); cid = max((c.id for c in self.result.candidates), default=0) + 1
        c = Candidate(cid, round(x, 2), round(y, 2), 'pending', ['manual'], 'manual', None)
        if self._central_active():
            c.central_nuclei = {'auto_status': 'unclassified', 'override': None, 'nuclei': [], 'review_flags': ['manual_no_region'], 'reason': '人工补加编号没有分割区域，请人工判定中央核分类。'}
        if self._recovery_active():
            c.recovery={'auto_status':'unclassified','override':None,'measurements':{},'review_flags':['人工补加无分割区域'],'reason':'请人工判定 DYS 恢复分类'}
        self.result.candidates.append(c); self.selected_id = cid; self._changed(); self.select_candidate(cid)

    def move_candidate(self, cid, x, y):
        if self._busy or self.result is None or self.original_check.isChecked(): return
        if not (0 <= x < self.image.width and 0 <= y < self.image.height): return
        if any(c.id != cid and (c.x-x)**2 + (c.y-y)**2 < 9 for c in self.result.candidates):
            self.statusBar().showMessage('目标位置已有其他编号。'); return
        c = next((c for c in self.result.candidates if c.id == cid), None)
        if c:
            self._snapshot(); c.x = round(x, 2); c.y = round(y, 2); c.note = '仅编号位置已移动；荧光测量和中央核判定区域保留原位置' if self._central_active() else '仅编号位置已移动；荧光测量区域保留原位置'; self.selected_id = cid; self._changed()

    def delete_selected(self):
        if self._busy or self.result is None or self.selected_id is None: return
        if not any(c.id == self.selected_id for c in self.result.candidates): return
        self._snapshot(); self.result.candidates = [c for c in self.result.candidates if c.id != self.selected_id]; self.selected_id = None; self._changed()

    def confirm_selected(self):
        if self._busy or self.result is None: return
        c = next((c for c in self.result.candidates if c.id == self.selected_id), None)
        if c:
            self._snapshot(); c.state = 'confirmed'; self._changed()

    def classify_selected(self, status):
        if self._busy or not self._bio_active() or status not in (None, 'positive', 'negative', 'unclassified'): return
        c = next((c for c in self.result.candidates if c.id == self.selected_id), None)
        if c is None: return
        self._snapshot()
        if self._bio_kind()=='recovery':
            if not c.recovery:c.recovery={'auto_status':'unclassified','measurements':{},'review_flags':[]}
            c.recovery['override']=status;self._changed()
            self.statusBar().showMessage(f'#{c.id} DYS 分类已更新；恢复比例已重算。');return
        if not c.central_nuclei:
            c.central_nuclei = {'auto_status': 'unclassified', 'override': None, 'nuclei': [], 'review_flags': [], 'reason': '此编号没有自动中央核判定。'}
        c.central_nuclei['override'] = status
        self._changed()
        self.statusBar().showMessage(f'#{c.id} 已' + ('恢复自动中央核判定。' if status is None else '人工判为' + CENTRAL_LABELS[status] + '；比例已更新。'))

    def undo(self):
        if self._busy or not self.undo_stack or self.result is None: return
        self.result.candidates = self.undo_stack.pop(); self.selected_id = None; self._changed()

    def renumber(self):
        if self._busy or self.result is None: return
        self._snapshot(); self.result.renumber(); self.selected_id = None; self._changed()

    def find_id(self):
        if self.result is None: return
        try: cid = int(self.search.text())
        except ValueError: self.statusBar().showMessage('请输入有效的整数编号。'); return
        if any(c.id == cid for c in self.result.candidates):
            self.review_check.setChecked(False); self.original_check.setChecked(False); self.central_filter.setCurrentIndex(0); self.select_candidate(cid, True)
        else: self.statusBar().showMessage('没有找到这个编号。')

    def next_review(self):
        if not self.result: return
        pending = sorted(c.id for c in self.result.candidates if c.review_needed)
        if not pending: self.statusBar().showMessage('当前没有待复核候选。'); return
        cid = next((i for i in pending if i > (self.selected_id or 0)), pending[0]); self.select_candidate(cid, True)

    def select_candidate(self, cid, center=False):
        if self._compact: self.side_tabs.setCurrentWidget(self.review_panel)
        self.selected_id = cid; self.view.select_id(cid, center); self._detail()
        row = self._rows.get(cid)
        if row is not None:
            self.table.blockSignals(True); self.table.selectRow(row); self.table.scrollToItem(self.table.item(row, 0)); self.table.blockSignals(False)
        self._refresh_buttons()

    def _table_selected(self):
        rows = self.table.selectionModel().selectedRows()
        if rows:
            cid = int(self.table.item(rows[0].row(), 0).text()); self.select_candidate(cid, True)

    def display_options(self):
        if self.view.overlay:
            self.view.overlay.show_numbers = self.numbers_check.isChecked(); self.view.overlay.only_review = self.review_check.isChecked(); self.view.overlay.show_nuclei = self._central_active() and self.nuclei_check.isChecked(); self.view.overlay.central_colors = self._bio_active() and self.central_colors_check.isChecked(); self.view.overlay.central_filter = self.central_filter.currentData() if self._bio_active() else 'all'; self.view.overlay.classification_kind=self._bio_kind();self.view.overlay.show_membrane=self._recovery_active() and self.membrane_check.isChecked();self.view.overlay.setVisible(not self.original_check.isChecked()); self.view.overlay.update()
        if self.original_check.isChecked():
            self.mode_buttons['browse'].setChecked(True); self.view.set_mode('browse')
        self._update_color_legend(); self._fill_table(); self._refresh_buttons()

    def _update_color_legend(self):
        if self._central_active() and self.central_colors_check.isChecked():
            text = '编号：粉色 中央核 · 青绿 非中央核\n灰色 未确定；此配色不表示质量复核状态。'
        else:
            text = '编号：绿色 自动识别 · 橙色 待复核\n蓝色 已人工确认；此配色不表示中央核分类。'
        if self._central_active(): text += '\n核圆环：黄色 符合内部判定 · 淡蓝 其他检出核。'
        if self._recovery_active() and self._bio_kind()=='recovery':
            text=('编号：浅绿 DYS 恢复候选 · 浅蓝 未达阳性条件 · 灰 未确定。' if self.central_colors_check.isChecked() else text)+'\n所选膜采样：黄 绿色阳性 · 紫 未达绿色阈值 · 灰 血影蛋白支持不足。'
        self.color_legend.setText(text)

    def _detail(self):
        c = next((c for c in self.result.candidates if c.id == self.selected_id), None) if self.result else None
        if not c:
            self.detail_label.setText('选择一个编号查看详情'); self._update_detail_height(); return
        detail = f'#{c.id}  ·  {STATE_LABELS[c.state]}\n坐标：{c.x:g}, {c.y:g} px'
        if c.interior_area_px is not None: detail += f'\n候选内部面积：{c.interior_area_px:g} px²'
        if self._central_active():
            cn = c.central_nuclei or {}
            detail += '\n中央核分类：' + CENTRAL_LABELS.get(fiber_status(c), '未确定')
            detail += '（人工判定）' if cn.get('override') is not None else '（自动判定）'
            detail += f'\n符合内部判定的核：{len(cn.get("nuclei", []))} 个'
            if cn.get('nuclei'): detail += '\n核编号：' + ', '.join(str(n['id']) for n in cn['nuclei'])
            if cn.get('reason'): detail += '\n' + str(cn['reason'])
            if cn.get('review_flags'): detail += '\n中央核判定提示：' + '、'.join(str(f) for f in cn['review_flags'])
        if self._recovery_active():
            d=c.recovery or {};m=d.get('measurements',{});cv=m.get('positive_coverage');sv=m.get('spectrin_support')
            detail+='\nDYS 分类：'+RECOVERY_LABELS[recovery_status(c)]+('（人工判定）' if d.get('override') else '（自动判定）')
            detail+='\n绿色阳性周长：'+('—' if cv is None else f'{cv:.1%}')+'；血影支持：'+('—' if sv is None else f'{sv:.1%}')
            if m:detail+=f'\n本纤维绿色阈值：{m["green_threshold"]:.2f}；胞内背景：{m["background_green"]:.2f}'
            if d.get('reason'):detail+='\n'+d['reason']
            if d.get('review_flags'):detail+='\n恢复判定提示：'+'；'.join(d['review_flags'])
        for m in c.intensity.get('measurements', []):
            mean = '无有效像素' if m['mean'] is None else f'{m["mean"]:.3f}'
            detail += f'\n{REGIONS[m["region"]]} · {CHANNELS[m["channel"]]}均值：{mean}'
        if not c.intensity.get('measurements'): detail += '\n荧光：' + STATUS.get(intensity_status(c), '未测量')
        if c.flags: detail += '\n' + '\n'.join(REASONS.get(f, f) for f in c.flags)
        if c.note: detail += '\n' + c.note
        self.detail_label.setText(detail)
        self._update_detail_height()

    def _update_detail_height(self):
        # Clear the previous constraint before measuring a shorter/new selection.
        # Otherwise heightForWidth can retain a long detail's old minimum height.
        width = max(180, self.review_panel.viewport().width() - 24)
        self.detail_label.setMinimumHeight(0); self.detail_label.setMaximumHeight(16777215)
        self.detail_label.setFixedHeight(max(22, self.detail_label.heightForWidth(width) + 4))

    def _fill_table(self):
        selected = self.selected_id; self.table.blockSignals(True); self.table.setUpdatesEnabled(False)
        scroll_position = self.table.verticalScrollBar().value()
        # Replacing thousands of items while a row remains selected makes Qt
        # repeatedly recompute selection and ResizeToContents geometry. Rebuild
        # an empty model and size the two short text columns once, from text.
        self.table.clearSelection(); self.table.setCurrentItem(None); self.table.setRowCount(0)
        central = self._bio_active();recovery=self._bio_kind()=='recovery'
        self.table.setColumnCount(3 if central else 2); self.table.setHorizontalHeaderLabels(['编号', '复核', 'DYS 恢复' if recovery else '中央核'] if central else ['编号', '状态'])
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.Fixed)
        candidates = self.result.candidates if self.result else []
        if self.review_check.isChecked(): candidates = [c for c in candidates if c.review_needed]
        if central:
            selected_filter = self.central_filter.currentData()
            if selected_filter == 'nuclear_review': candidates = [c for c in candidates if self._bio_info(c).get('review_flags')]
            elif selected_filter != 'all': candidates = [c for c in candidates if self._bio_status(c) == selected_filter]
        self.table.setRowCount(len(candidates)); self._rows = {}
        from PySide6.QtGui import QColor
        for row, c in enumerate(candidates):
            self._rows[c.id] = row; self.table.setItem(row, 0, QTableWidgetItem(str(c.id)))
            item = QTableWidgetItem(STATE_LABELS[c.state]); item.setForeground(QColor('#ffae56' if c.review_needed else ('#63c8ff' if c.state == 'confirmed' else '#a6ef78'))); self.table.setItem(row, 1, item)
            if central:
                status = self._bio_status(c);item=QTableWidgetItem(({'positive':'恢复候选','negative':'未达阳性','unclassified':'未确定'} if recovery else CENTRAL_LABELS)[status]);item.setForeground(QColor((RECOVERY_COLORS if recovery else CENTRAL_COLORS)[status]))
                item.setToolTip('人工判定' if self._bio_info(c).get('override') is not None else '自动判定'); self.table.setItem(row, 2, item)
        metrics = self.table.fontMetrics()
        number_text = str(max((c.id for c in candidates), default=1))
        self.table.setColumnWidth(0, max(metrics.horizontalAdvance('编号'), metrics.horizontalAdvance(number_text)) + 22)
        if central:
            self.table.setColumnWidth(1, max(metrics.horizontalAdvance(s) for s in STATE_LABELS.values()) + 20)
        header.setSectionResizeMode(2 if central else 1, QHeaderView.ResizeMode.Stretch)
        if selected in self._rows: self.table.selectRow(self._rows[selected])
        self.table.verticalScrollBar().setValue(scroll_position)
        self.table.setUpdatesEnabled(True); self.table.blockSignals(False)

    def _refresh(self,*args):
        r = self.result
        self.total_label.setText(f'{r.count:,}' if r else '—'); self.pending_label.setText(f'{r.review_count:,}' if r else '—'); self.confirmed_label.setText(f'{r.confirmed_count:,}' if r else '—')
        self.view.set_candidates(r.candidates if r else [])
        central = self._bio_active();recovery=self._bio_kind()=='recovery'
        self.analysis_view_combo.setVisible(self._central_active() and self._recovery_active())
        self.nuclei_check.setVisible(self._central_active());self.membrane_check.setVisible(self._recovery_active())
        self.central_count_label.caption.setText('DYS 恢复候选' if recovery else '中央核肌纤维')
        self.central_ratio_label.caption.setText('恢复 / 全部肌纤维' if recovery else '中央核 / 全部肌纤维')
        self.central_colors_check.setText('按恢复分类着色' if recovery else '按中央核分类着色')
        self.central_review_group.setTitle('DYS 恢复分类 · 人工复核' if recovery else '中央核分类 · 人工复核')
        self.central_positive_button.setText('判为恢复' if recovery else '判为中央核');self.central_negative_button.setText('判为未恢复' if recovery else '判为非中央核')
        filter_texts=['全部恢复分类','仅 DYS 恢复候选','仅未达阳性条件','仅未确定分类','仅恢复判定有提示'] if recovery else ['全部中央核分类','仅中央核肌纤维','仅非中央核肌纤维','仅未确定分类','仅中央核判定有提示']
        self.central_filter.blockSignals(True)
        for i,t in enumerate(filter_texts):self.central_filter.setItemText(i,t)
        self.central_filter.blockSignals(False)
        for panel in (self.central_summary_panel, self.central_view_options, self.central_review_group, self.central_filter): panel.setVisible(central)
        if central:
            s = recovery_summary(r) if recovery else central_summary(r)
            n=s['recovered_fibers'] if recovery else s['central_fibers'];negative=s['negative_fibers'] if recovery else s['noncentral_fibers']
            self.central_count_label.setText(f'{n:,}')
            percent = s.get('ratio_percent'); self.central_ratio_label.setText('—' if percent is None else f'{percent:.2f}%')
            self.central_summary_hint.setText(f'{n:,} / {s["total_fibers"]:,} 条肌纤维；未达条件 {negative:,}，未确定 {s["unclassified_fibers"]:,}。' + (' 比例为当前分类下限。' if not s.get('classification_complete', False) else ' 自动分类需复核。'))
        else:
            self.central_count_label.setText('—'); self.central_ratio_label.setText('—')
        self.view.set_central_data(r.metadata.get('central_nuclei', {}).get('nuclei', []) if central else [])
        if self.view.overlay:
            self.view.overlay.selected_id = self.selected_id
            self.view.overlay.show_nuclei = central and self.nuclei_check.isChecked(); self.view.overlay.central_colors = central and self.central_colors_check.isChecked()
            self.view.overlay.central_filter = self.central_filter.currentData() if central else 'all'
            self.view.overlay.classification_kind=self._bio_kind();self.view.overlay.show_membrane=self._recovery_active() and self.membrane_check.isChecked()
        self._update_color_legend()
        self._update_adaptive_layout()
        self._fill_table(); self._detail(); self._refresh_buttons()

    def _refresh_buttons(self):
        busy = self._busy; has_image = self.image is not None; has_result = self.result is not None
        for b in (self.open_button, self.project_button, self.batch_button): b.setEnabled(not busy)
        for b in (self.save_button, self.export_button, self.renumber_button): b.setEnabled(not busy and has_result)
        self.count_button.setEnabled(not busy and has_image); self.params_panel.setEnabled(not busy)
        self.undo_button.setEnabled(not busy and bool(self.undo_stack)); self.next_button.setEnabled(not busy and has_result and self.result.review_count > 0)
        for b in (self.delete_button, self.confirm_button): b.setEnabled(not busy and has_result and self.selected_id is not None)
        for b in (self.central_positive_button, self.central_negative_button, self.central_uncertain_button, self.central_auto_button): b.setEnabled(not busy and self._bio_active() and self.selected_id is not None)
        for mode, b in self.mode_buttons.items(): b.setEnabled(not busy and has_image and (mode == 'browse' or not self.original_check.isChecked()))
        for a in getattr(self, 'file_actions', []): a.setEnabled(not busy)
        for a in getattr(self, 'parameter_actions', []): a.setEnabled(not busy)

    def show_about(self):
        dlg = QDialog(self); dlg.setWindowTitle('关于 FACC'); dlg.resize(640, min(700, QApplication.primaryScreen().availableGeometry().height()-60))
        layout = QVBoxLayout(dlg)
        label = QLabel(f'<h1 style="color:#83e1cc">FACC <small>v{__version__}</small></h1><p>{APP_FULL_NAME}</p><p><b>作者：</b>{AUTHOR}<br><b>联系方式：</b><a href="mailto:{CONTACT}" style="color:#87c8ff">{CONTACT}</a></p><hr><p><b>使用流程</b><br>1. 打开图像，选择模式与荧光通道。<br>2. 点击“开始自动计数”。<br>3. 放大检查橙色候选；可添加、移动、删除编号，或标为已人工确认。<br>4. 保存项目或导出结果。批量计数使用相同参数逐图运行。</p><p><b>计数解释</b><br>膜染色模式面向边界清楚、内部较暗的肌纤维/细胞截面。实心模式面向独立的明亮荧光对象。弱染色、断裂边界、强背景及不同组织类型都可能产生误计，需复核候选结果。该版本不是经生物学验证的诊断系统。</p><p>分析在本机完成。PNG/TIFF 编号图、CSV 坐标、离线查看器及包含原始数据的项目可导出保存。没有物理比例尺时，只报告像素坐标与候选内部像素面积。</p>')
        label.setText(label.text() + '<hr><p><b>v1.1 新功能</b><br>单张图像拖入窗口即按当前参数分析；多张图像拖入后选择批量输出位置。可拖入 .facc 项目继续复核。<br>小窗口中“计数设置”和“复核与强度”切换为标签页；两侧可滚动。<br>荧光表同时导出候选内部与边界周带的均值、中位数、最小值、最大值、标准差和积分强度。数据直接读取原文件像素；周带是近似采样区域，未作背景扣除。<br>人工添加编号没有区域时，强度留空；移动编号保留原测量区域。旧版项目需要重新分析才能补充强度。</p>')
        label.setText(label.text() + '<hr><p><b>v1.2 中央核肌纤维分析</b><br>在计数设置中启用“中央核比例分析”。红色膜信号用于分割肌纤维，蓝色减红色选项可抑制紫色膜对 DAPI 核检测的干扰。任一核满足内部判定，则该肌纤维计为中央核；同一肌纤维多个核只计一次。<br>比例 = 中央核肌纤维数 ÷ 当前全部肌纤维候选数。人工补加且没有分割区域的编号先标为未确定，不应直接当作非中央核。右侧可人工更正分类并撤销。<br>核圆环帮助定位核，粉色编号表示中央核；分类颜色与候选质量复核状态独立。移动编号仅改变标签位置，原分割和核归属保持不变。核信号及膜轮廓均需结合原图复核；旧项目须重新分析才能获得自动中央核结果。</p>')
        label.setText(label.text()+'<hr><p><b>v1.3 DYS 恢复分析</b><br>红色血影蛋白确定总肌纤维；绿色阳性膜周长达到阈值（默认30%）计为恢复候选。可查看所选肌纤维的膜采样，手工修正分类、筛选及撤销。<br>阈值、绿色覆盖和膜支持不足提示均可导出；未确定保留在分母，比例为当前分类下限。两项分析可同时开启，使用查看分类选项切换。<br>该比例为DYS阳性肌纤维比例，不代表正常蛋白量或功能恢复；合并图和共享膜需复核。详细参数与方法参考见随包的 docs/肌纤维恢复分析.md。</p>')
        label.setText(label.text()+'<hr><p><b>v1.4 参数与项目体验</b><br>参数按计数、DYS、中央核、强度、高级分组。“设为默认”保存全部分析参数，下次启动自动载入；打开项目仍使用项目参数，不改动个人默认设置。参数菜单可载入出厂参数。<br>数字输入框增大上下箭头点击区域，可输入、点击或按键调整。项目载入支持旧版超过60MB的分析记录，按可用内存预检并显示读取进度。导出复用数据、使用紧凑无损存储，输出项目、编号图、表格和查看器。</p>')
        label.setWordWrap(True); label.setOpenExternalLinks(True); label.setContentsMargins(10,10,10,10)
        scroll=QScrollArea(); scroll.setWidgetResizable(True); scroll.setWidget(label); layout.addWidget(scroll)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok); buttons.accepted.connect(dlg.accept); layout.addWidget(buttons); dlg.exec()

    def closeEvent(self, event):
        if self._busy:
            QMessageBox.information(self, '任务进行中', '请等待当前操作完成，或取消计数后再关闭。'); event.ignore(); return
        if self._guard_changes(): event.accept()
        else: event.ignore()


def configure_application():
    app = QApplication.instance()
    if app is None or app.property('faccConfigured'): return
    for path in (asset_path('fonts/NotoSansSC.ttf'), Path('C:/Windows/Fonts/arial.ttf'), Path('C:/Windows/Fonts/msyh.ttc')):
        if path.exists(): QFontDatabase.addApplicationFont(str(path))
    app.setFont(QFont('Noto Sans SC', 9))
    palette = QPalette()
    for role, color in [(QPalette.ColorRole.Window, '#101722'), (QPalette.ColorRole.WindowText, '#dbe7f5'), (QPalette.ColorRole.Base, '#111c2a'), (QPalette.ColorRole.AlternateBase, '#172438'), (QPalette.ColorRole.Text, '#dbe7f5'), (QPalette.ColorRole.Button, '#22344b'), (QPalette.ColorRole.ButtonText, '#dbe7f5'), (QPalette.ColorRole.Highlight, '#2a5067'), (QPalette.ColorRole.HighlightedText, '#ffffff')]: palette.setColor(role, QColor(color))
    app.setPalette(palette); app.setProperty('faccConfigured', True)


def run_gui(open_path=None):
    app = QApplication.instance() or QApplication([])
    app.setApplicationName('FACC'); app.setOrganizationName(AUTHOR); app.setApplicationVersion(__version__)
    window = MainWindow(); window.show()
    if open_path: QTimer.singleShot(100, lambda: window.open_image_path(open_path))
    return app.exec()
