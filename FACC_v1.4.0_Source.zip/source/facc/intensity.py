"""Traceable ROI measurements on original input values, without display scaling."""
import base64
import zlib
import numpy as np
from scipy import ndimage as ndi

CHANNELS = {'red': '红', 'green': '绿', 'blue': '蓝', 'gray': '灰度'}
REGIONS = {'interior': '候选内部', 'boundary': '边界周带'}
METRICS = {'mean': '均值', 'median': '中位数', 'min': '最小值', 'max': '最大值', 'std': '标准差', 'sum': '积分强度'}
STATUS = {'measured': '已测量', 'manual_no_roi': '人工编号无区域', 'legacy_no_roi': '旧项目无区域', 'empty': '无有效像素'}


def pack_roi(mask, x, y):
    mask = np.asarray(mask, dtype=bool)
    data = zlib.compress(np.packbits(mask.ravel()).tobytes())
    return {'x': int(x), 'y': int(y), 'shape': list(mask.shape),
            'encoding': 'packbits-zlib-base64', 'data': base64.b64encode(data).decode('ascii')}


def unpack_roi(roi):
    if roi.get('encoding') != 'packbits-zlib-base64': raise ValueError('不支持的测量区域编码。')
    h, w = map(int, roi['shape'])
    if min(h, w) <= 0 or h*w > 150_000_000: raise ValueError('测量区域尺寸无效。')
    expected = (h*w + 7)//8
    decoder = zlib.decompressobj()
    packed = decoder.decompress(base64.b64decode(roi['data'], validate=True), expected + 1)
    if len(packed) != expected or not decoder.eof: raise ValueError('测量区域数据损坏。')
    return np.unpackbits(np.frombuffer(packed, np.uint8), count=h*w).reshape(h, w).astype(bool), int(roi['x']), int(roi['y'])


def original_roi(mask, bbox, width, height, sx, sy):
    """Nearest-neighbor assignment of original pixel centers to analysis pixels."""
    ay0, ax0, ay1, ax1 = bbox
    x0, y0 = max(0, int(np.floor(ax0/sx))), max(0, int(np.floor(ay0/sy)))
    x1, y1 = min(width, int(np.ceil(ax1/sx))), min(height, int(np.ceil(ay1/sy)))
    xs = np.floor((np.arange(x0, x1)+.5)*sx).astype(int)-ax0
    ys = np.floor((np.arange(y0, y1)+.5)*sy).astype(int)-ay0
    valid_x, valid_y = (xs >= 0)&(xs < mask.shape[1]), (ys >= 0)&(ys < mask.shape[0])
    mapped = mask[np.clip(ys, 0, mask.shape[0]-1)[:, None], np.clip(xs, 0, mask.shape[1]-1)]
    mapped = mapped & valid_y[:, None] & valid_x
    return pack_roi(mapped, x0, y0)


def validate_rois(candidate, image):
    for roi in candidate.roi.values():
        mask, x, y = unpack_roi(roi)
        if x < 0 or y < 0 or x+mask.shape[1] > image.width or y+mask.shape[0] > image.height:
            raise ValueError('测量区域超出图像范围。')


def boundary_roi(interior, occupied, width):
    mask, x, y = unpack_roi(interior)
    height, image_width = occupied.shape
    x0, y0 = max(0, x-width), max(0, y-width)
    x1, y1 = min(image_width, x+mask.shape[1]+width), min(height, y+mask.shape[0]+width)
    inner = np.zeros((y1-y0, x1-x0), bool)
    inner[y-y0:y-y0+mask.shape[0], x-x0:x-x0+mask.shape[1]] = mask
    band = (ndi.distance_transform_edt(~inner) <= width) & ~occupied[y0:y1, x0:x1]
    return pack_roi(band, x0, y0)


def measurement_channels(image, requested, counting_channel):
    if image.raw.ndim == 2: return ['gray']
    if requested == 'all': return ['red', 'green', 'blue']
    return [counting_channel if requested == 'counting' else requested]


def raw_values(image, roi, channel):
    mask, x, y = unpack_roi(roi)
    data = image.raw[y:y+mask.shape[0], x:x+mask.shape[1]]
    if data.ndim == 2:
        values = data[mask].astype(np.float64)
    elif channel == 'gray':
        values = data[mask].astype(np.float64) @ np.array([.299, .587, .114])
    else:
        values = data[..., {'red': 0, 'green': 1, 'blue': 2}[channel]][mask].astype(np.float64)
    return values[np.isfinite(values)]


def statistics(values):
    if not len(values): return dict(pixel_count=0, **{key: None for key in METRICS})
    return {'pixel_count': int(len(values)), 'mean': float(np.mean(values)),
            'median': float(np.median(values)), 'min': float(np.min(values)),
            'max': float(np.max(values)), 'std': float(np.std(values, ddof=0)),
            'sum': float(np.sum(values, dtype=np.float64))}


def measure_candidates(image, result, progress=None):
    progress = progress or (lambda value, message: None)
    p = result.parameters
    channels = measurement_channels(image, p.intensity_channel, result.metadata.get('channel', 'gray'))
    regions = ['interior', 'boundary'] if p.intensity_regions == 'both' else [p.intensity_regions]
    occupied = np.zeros((image.height, image.width), bool)
    for c in result.candidates:
        if 'interior' in c.roi:
            mask, x, y = unpack_roi(c.roi['interior'])
            occupied[y:y+mask.shape[0], x:x+mask.shape[1]] |= mask
    for i, c in enumerate(result.candidates):
        if i % 40 == 0: progress(94 + int(5*i/max(1, result.count)), '测量原始像素的内部与周带荧光')
        if 'interior' not in c.roi:
            c.intensity = {'status': 'manual_no_roi' if c.origin == 'manual' else 'legacy_no_roi', 'measurements': []}
            continue
        if 'boundary' in regions:
            c.roi['boundary'] = boundary_roi(c.roi['interior'], occupied, p.boundary_width)
        measurements = []
        for region in regions:
            for channel in channels:
                values = raw_values(image, c.roi[region], channel)
                measurements.append(dict(region=region, channel=channel, **statistics(values)))
        c.intensity = {'status': 'measured', 'raw_dtype': str(image.raw.dtype),
                       'boundary_width_px': p.boundary_width, 'measurements': measurements}
    result.metadata['fluorescence'] = {
        'channels': channels, 'regions': regions, 'boundary_width_px': p.boundary_width,
        'units': 'original input intensity (a.u.); integrated intensity = sum of original pixel values',
        'normalization': 'none; no background subtraction or exposure normalization',
        'interior_definition': 'segmented candidate interior mapped to original pixel centers by nearest neighbor',
        'boundary_definition': 'outward Euclidean band within boundary_width_px; excludes every accepted interior at analysis time',
        'overlap': 'bands of neighboring candidates may share membrane pixels; do not sum them as a unique whole-image total',
        'edits': 'moving a number preserves its original measurement ROI; manually added points have no ROI or intensity',
        'std_definition': 'population standard deviation (ddof=0)',
        'roi_snapshot': 'saved in project; candidate deletion/renumbering does not alter other measurement regions',
    }


def intensity_status(candidate):
    return candidate.intensity.get('status') or ('manual_no_roi' if candidate.origin == 'manual' else 'legacy_no_roi')


def fluorescence_rows(candidates):
    for c in candidates:
        values = c.intensity.get('measurements', [])
        if not values: yield c, None
        for m in values: yield c, m


def interior_label_image(image, result):
    dtype = np.uint16 if max((c.id for c in result.candidates), default=0) <= 65535 else np.uint32
    labels = np.zeros((image.height, image.width), dtype=dtype)
    for c in result.candidates:
        if 'interior' in c.roi:
            mask, x, y = unpack_roi(c.roi['interior'])
            labels[y:y+mask.shape[0], x:x+mask.shape[1]][mask] = c.id
    return labels
