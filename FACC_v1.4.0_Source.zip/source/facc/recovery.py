"""Spectrin-guided, approximately arc-length sampled dystrophin positivity.

The result is a DYS-positive fiber candidate fraction, not proof of functional
recovery or treatment-induced expression. No pretrained weights or fixed ROIs.
"""
import time
import numpy as np
from scipy import ndimage as ndi
from skimage import measure
from .image_io import normalize
from .intensity import unpack_roi

LABELS={'positive':'DYS 阳性 / 恢复候选','negative':'未达 DYS 阳性条件','unclassified':'未确定'}
COLORS={'positive':'#b8ef6b','negative':'#75bcff','unclassified':'#aab4c3'}

def recovery_status(candidate):
    d=candidate.recovery or {}
    s=d.get('override') or d.get('auto_status') or 'unclassified'
    return s if s in LABELS else 'unclassified'

def recovery_summary(result):
    counts={s:sum(recovery_status(c)==s for c in result.candidates) for s in LABELS}
    total=result.count
    ratio=counts['positive']/total if total else None
    return dict(total_fibers=total,recovered_fibers=counts['positive'],negative_fibers=counts['negative'],
                unclassified_fibers=counts['unclassified'],ratio=ratio,
                ratio_percent=ratio*100 if ratio is not None else None,
                classification_complete=counts['unclassified']==0,ratio_is_lower_bound=counts['unclassified']>0)

def _background(values):
    values=np.asarray(values);values=values[np.isfinite(values)]
    if not values.size:return 0.,0.
    median=float(np.median(values))
    return median,float(1.4826*np.median(np.abs(values-median)))

def _contour_samples(mask):
    padded=np.pad(ndi.binary_fill_holes(mask),2)
    contours=measure.find_contours(padded.astype(np.uint8),.5)
    if not contours:return np.empty((0,2)),np.empty((0,2))
    contour=max(contours,key=len)
    lengths=np.linalg.norm(np.diff(contour,axis=0),axis=1)
    arc=np.r_[0,np.cumsum(lengths)]
    positions=np.linspace(0,arc[-1],max(8,int(np.ceil(arc[-1]))),endpoint=False)
    points=np.column_stack([np.interp(positions,arc,contour[:,k]) for k in range(2)])
    sdf=ndi.distance_transform_edt(~padded)-ndi.distance_transform_edt(padded)
    gy,gx=np.gradient(sdf)
    normal=np.column_stack([ndi.map_coordinates(v,points.T,order=1) for v in (gy,gx)])
    normal/=np.maximum(np.linalg.norm(normal,axis=1,keepdims=True),1e-6)
    return points-2,normal

def classify_recovery(image,result,progress=None):
    report=progress or (lambda n,s:None);start=time.perf_counter();p=result.parameters
    if image.raw.ndim!=3:raise ValueError('DYS 恢复分析需要红色血影蛋白与绿色 dystrophin 的 RGB 合并图。')
    report(96,'建立血影蛋白肌膜采样区域')
    normalized,limits=normalize(image.raw)
    red=ndi.gaussian_filter(normalized[...,0],.65)
    green=ndi.gaussian_filter(normalized[...,1],.65)
    labels=np.zeros(red.shape,np.int32);cores=[];masks={}
    for c in result.candidates:
        if 'interior' not in c.roi:continue
        mask,x,y=unpack_roi(c.roi['interior']);masks[c.id]=(mask,x,y)
        labels[y:y+mask.shape[0],x:x+mask.shape[1]][mask]=c.id
        core=ndi.binary_erosion(np.pad(mask,3),iterations=3)[3:-3,3:-3]
        if not core.any():core=mask
        values=green[y:y+mask.shape[0],x:x+mask.shape[1]][core]
        cores.append(values[::max(1,len(values)//1000)])
    all_core=np.concatenate(cores) if cores else np.array([],dtype=float)
    global_bg,global_noise=_background(all_core)
    global_threshold=max(p.recovery_min_contrast,global_bg+p.recovery_background_sigma*global_noise)
    # Allocate outward search pixels to the nearest accepted interior. Other
    # fibers' inner pixels and their outward half of the gap are never sampled.
    if masks:
        nearest=ndi.distance_transform_edt(labels==0,return_distances=False,return_indices=True)
        owners=labels[tuple(nearest)];del nearest
    else:owners=labels
    for i,c in enumerate(result.candidates):
        if i%25==0:report(97+int(2*i/max(1,result.count)),'沿肌膜测量绿色信号与阳性覆盖比例')
        c.recovery=dict(auto_status='unclassified',override=None,review_flags=[],measurements={})
        if c.id not in masks:
            c.recovery['reason']='缺少分割内部区域；请人工判定';continue
        mask,x,y=masks[c.id]
        core=ndi.binary_erosion(np.pad(mask,3),iterations=3)[3:-3,3:-3]
        if not core.any():core=mask
        bg,noise=_background(green[y:y+mask.shape[0],x:x+mask.shape[1]][core])
        rbg,rnoise=_background(red[y:y+mask.shape[0],x:x+mask.shape[1]][core])
        threshold=max(p.recovery_threshold if p.recovery_threshold else global_threshold,
                      bg+p.recovery_min_contrast,
                      bg+p.recovery_background_sigma*noise if not p.recovery_threshold else 0)
        spectrin_threshold=max(p.min_intensity,rbg+2*rnoise)
        points,normals=_contour_samples(mask)
        if not len(points):c.recovery['reason']='无法提取闭合外轮廓';continue
        points+=np.array([y,x])
        offsets=np.arange(-1,p.recovery_band_width+.25,.5)
        locations=points[:,None,:]+normals[:,None,:]*offsets[None,:,None]
        coords=np.moveaxis(locations,-1,0)
        owner=ndi.map_coordinates(owners,coords,order=0,mode='constant',cval=0)
        rs=ndi.map_coordinates(red,coords,order=1,mode='constant',cval=0)
        rs[owner!=c.id]=-1
        best=np.argmax(rs,axis=1)
        chosen=locations[np.arange(len(points)),best]
        rv=rs[np.arange(len(points)),best]
        gv=ndi.map_coordinates(green,chosen.T,order=1,mode='constant',cval=0)
        valid=rv>spectrin_threshold
        positive=valid & (gv>=threshold)
        support=float(valid.mean())
        coverage=float(positive.sum()/valid.sum()) if valid.any() else None
        status='positive' if coverage is not None and coverage>=p.recovery_min_coverage else 'negative'
        flags=[]
        if support<p.recovery_min_spectrin_coverage:
            status='unclassified';flags.append('血影蛋白膜支持不足，需复核分割与膜搜索宽度')
        if coverage is not None and abs(coverage-p.recovery_min_coverage)<=.05:flags.append('接近恢复阳性覆盖阈值')
        if c.review_needed:flags.append('肌纤维分割候选有复核提示')
        raw_green=ndi.map_coordinates(image.raw[...,1].astype(np.float32),chosen.T,order=1,mode='constant',cval=0)
        saturated=float(np.mean(raw_green[valid]>=np.iinfo(image.raw.dtype).max)) if valid.any() and np.issubdtype(image.raw.dtype,np.integer) else 0.
        if saturated>.05:flags.append('膜绿色信号存在饱和，强度不能线性比较')
        measurements=dict(perimeter_samples=len(points),spectrin_supported_samples=int(valid.sum()),
                          positive_samples=int(positive.sum()),spectrin_support=support,positive_coverage=coverage,
                          green_threshold=threshold,spectrin_threshold=spectrin_threshold,
                          background_green=bg,background_noise=noise,
                          membrane_green_mean=float(np.mean(gv[valid])) if valid.any() else None,
                          membrane_green_mean_raw=float(np.mean(raw_green[valid])) if valid.any() else None,
                          membrane_green_minus_background=float(np.mean(gv[valid])-bg) if valid.any() else None,
                          saturated_fraction=saturated)
        # Save independent contour and sampling locations for traceable overlays.
        c.recovery.update(auto_status=status,review_flags=flags,measurements=measurements,
            perimeter_xy=np.round(points[:,::-1],2).tolist(),membrane_xy=np.round(chosen[:,::-1],2).tolist(),
            spectrin_supported=valid.astype(int).tolist(),positive_samples=positive.astype(int).tolist())
    result.metadata['recovery']=dict(enabled=True,algorithm='FACC spectrin-guided perimeter sampling v1',
        segmentation_channel='red',protein_channel='green',raw_dtype=str(image.raw.dtype),
        normalization_range=list(limits),global_background_green=global_bg,global_background_noise=global_noise,
        global_auto_threshold=global_threshold,min_positive_coverage=p.recovery_min_coverage,
        membrane_search_width_px=p.recovery_band_width,
        threshold_method='max(manual threshold, local median + minimum contrast)' if p.recovery_threshold else 'max(global and local median + sigma*MAD*1.4826, local median + minimum contrast)',
        coverage_definition='positive approximately 1-pixel arc samples / spectrin-supported arc samples; sampling at the strongest red position along the outward normal, restricted to nearest-fiber ownership',
        interpretation='Dystrophin-positive fiber candidate fraction; not % of normal protein amount, functional recovery, or proof that positivity was treatment-induced. RGB merge and shared membrane boundaries require review.',
        reference='https://pmc.ncbi.nlm.nih.gov/articles/PMC9184255/; 30% perimeter criterion is literature-informed; FACC is an independent approximation, not the validated published implementation.',
        elapsed_seconds=round(time.perf_counter()-start,3))
    return result
