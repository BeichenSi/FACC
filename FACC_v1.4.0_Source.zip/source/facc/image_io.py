from pathlib import Path
import warnings
import numpy as np
from PIL import Image
import tifffile
from .models import ImageData

MAX_PIXELS = 150_000_000
Image.MAX_IMAGE_PIXELS = MAX_PIXELS


def frame_count(path):
    path = Path(path)
    if path.suffix.lower() in (".tif", ".tiff"):
        with tifffile.TiffFile(path) as tf:
            return len(tf.pages)
    with Image.open(path) as im:
        return getattr(im, "n_frames", 1)


def _check_shape(shape):
    if len(shape) < 2 or np.prod(shape, dtype=np.int64) > MAX_PIXELS * 4:
        raise ValueError("图像过大或维度不受支持，请先裁剪为二维图像。")


def normalize(plane):
    a = np.asarray(plane)
    if a.dtype == np.uint8:
        return a.astype(np.float32), (0.0, 255.0)
    if a.dtype == np.bool_:
        return a.astype(np.float32) * 255, (0.0, 1.0)
    a = np.nan_to_num(a.astype(np.float32), nan=0, posinf=0, neginf=0)
    sampled = a[::max(1, a.shape[0] // 1500), ::max(1, a.shape[1] // 1500)]
    lo, hi = np.percentile(sampled, (0.1, 99.8))
    if hi <= lo:
        lo, hi = float(a.min()), float(a.max())
    if hi <= lo:
        return np.zeros(a.shape, np.float32), (float(lo), float(hi))
    return np.clip((a - lo) * (255.0 / (hi - lo)), 0, 255).astype(np.float32), (float(lo), float(hi))


def from_array(raw, name="image", source_path="", page=0, metadata=None):
    raw = np.asarray(raw)
    _check_shape(raw.shape)
    if raw.ndim == 3 and raw.shape[-1] not in (1, 3, 4) and raw.shape[0] in (1, 3, 4):
        raw = np.moveaxis(raw, 0, -1)
    if raw.ndim == 3 and raw.shape[-1] == 1:
        raw = raw[..., 0]
    if raw.ndim == 3 and raw.shape[-1] == 4:
        # Composite transparency on black so invisible RGB values cannot be counted.
        alpha = raw[..., 3].astype(np.float32)
        maximum = np.iinfo(raw.dtype).max if np.issubdtype(raw.dtype, np.integer) else 1.0
        raw = (raw[..., :3].astype(np.float32) * (alpha / maximum)[..., None]).astype(raw.dtype)
    if raw.ndim not in (2, 3) or (raw.ndim == 3 and raw.shape[-1] != 3):
        raise ValueError("只支持二维灰度或 RGB 图像。多通道堆栈请先导出单页/单通道。")
    if raw.shape[0] * raw.shape[1] > MAX_PIXELS:
        raise ValueError("图像超过 1.5 亿像素，请先裁剪或缩小。")
    if raw.dtype == np.uint8:
        view = raw.copy()
        display_range = (0, 255)
    else:
        view, display_range = normalize(raw)
        view = view.astype(np.uint8)
    if view.ndim == 2:
        view = np.repeat(view[..., None], 3, axis=2)
    info = dict(metadata or {})
    info.update(raw_dtype=str(raw.dtype), raw_shape=list(raw.shape), display_range=list(display_range))
    return ImageData(str(name), str(source_path), np.ascontiguousarray(raw), np.ascontiguousarray(view), page, info)


def load_image(path, page=0):
    path = Path(path)
    if path.suffix.lower() in (".tif", ".tiff"):
        with tifffile.TiffFile(path) as tf:
            if not 0 <= page < len(tf.pages):
                raise ValueError("指定的图像页不存在。")
            selected = tf.pages[page]
            _check_shape(selected.shape)
            metadata = {"total_pages": len(tf.pages), "tiff_axes": selected.axes}
            try:
                raw = selected.asarray()
            except (ValueError, ImportError, NotImplementedError) as error:
                # Pillow includes libtiff for common LZW/JPEG TIFFs; the minimal
                # tifffile installation intentionally has no imagecodecs wheel.
                if 'imagecodecs' not in str(error).lower():
                    raise
                try:
                    with Image.open(path) as im:
                        im.seek(page)
                        # Never silently reduce scientific 16-bit RGB to 8-bit.
                        bits = selected.bitspersample
                        if isinstance(bits, tuple): bits = max(bits)
                        if selected.samplesperpixel > 1 and bits > 8:
                            raise ValueError('压缩的高位深多通道 TIFF 请先无损导出为未压缩 TIFF 或单通道 TIFF。')
                        raw = np.array(im)
                        metadata['decoder'] = 'Pillow/libtiff'
                except (OSError, ValueError) as fallback_error:
                    raise ValueError('无法解码此压缩 TIFF。请先无损导出为未压缩 TIFF。' + str(fallback_error)) from error
    else:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(path) as im:
                im.seek(page)
                _check_shape((im.height, im.width))
                if im.mode not in ("L", "I", "F", "I;16", "I;16B", "RGB", "RGBA"):
                    im = im.convert("RGBA" if "transparency" in im.info else "RGB")
                raw = np.array(im)
                metadata = {"total_pages": getattr(im, "n_frames", 1)}
    return from_array(raw, path.name, str(path.resolve()), page, metadata)


def analysis_plane(image, channel="auto"):
    raw = image.raw
    chosen = channel
    if raw.ndim == 2:
        plane, chosen = raw, "gray"
    elif channel == "gray":
        plane = (raw.astype(np.float32) * np.array([0.299, 0.587, 0.114], np.float32)).sum(axis=-1)
        if raw.dtype == np.uint8:
            plane = np.clip(plane, 0, 255).astype(np.uint8)
    else:
        if channel == "auto":
            sample = raw[::max(1, image.height // 1000), ::max(1, image.width // 1000)]
            scores = [np.percentile(sample[..., k], 99.5) - np.percentile(sample[..., k], 20) for k in range(3)]
            chosen = ("red", "green", "blue")[int(np.argmax(scores))]
        plane = raw[..., {"red": 0, "green": 1, "blue": 2}[chosen]]
    plane, limits = normalize(plane)
    return plane, chosen, limits
