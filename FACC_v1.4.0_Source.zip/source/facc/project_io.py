"""Read legacy projects with bounded decompression and memory-aware preflight."""
import ctypes
import io
import json
import math
import os
import zipfile
import numpy as np
from .image_io import MAX_PIXELS
from .engine import Cancelled


def available_memory():
    if os.name == 'nt':
        class MemoryStatus(ctypes.Structure):
            _fields_ = [('length', ctypes.c_ulong), ('load', ctypes.c_ulong)] + [
                (name, ctypes.c_ulonglong) for name in ('total_phys', 'avail_phys', 'total_page',
                                                     'avail_page', 'total_virtual', 'avail_virtual', 'extended')]
        state = MemoryStatus(); state.length = ctypes.sizeof(state)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(state)):
            return min(state.avail_phys, state.avail_virtual)
    elif hasattr(os, 'sysconf'):
        try:
            return os.sysconf('SC_AVPHYS_PAGES') * os.sysconf('SC_PAGE_SIZE')
        except (ValueError, OSError):
            pass
    return None


def check_memory(document_bytes, raw_bytes):
    # JSON numbers/containers cost more than their serialized text. Raw loading is
    # chunked; this budget also reserves display normalization and the GUI overlay.
    estimated = document_bytes * 8 + raw_bytes * 6 + 128 * 1024**2
    available = available_memory()
    if document_bytes > 1024**3:
        raise ValueError('项目分析记录超过 1 GB，超出当前格式的载入范围。请拆分项目。')
    if available is not None and estimated > available * .80:
        raise ValueError(f'当前内存不足以打开此项目：预计需预留约 {estimated / 1024**3:.2f} GB，'
                         f'当前可用 {available / 1024**3:.2f} GB。请关闭其他大型程序后重试，或在内存更大的电脑打开。')


def check_cancel(cancel):
    if cancel is not None and cancel.is_set():
        raise Cancelled()


def read_project(path, progress=None, cancel=None):
    progress = progress or (lambda n, s: None)
    check_cancel(cancel); progress(3, '检查项目结构与可用内存')
    with zipfile.ZipFile(path) as archive:
        listing = archive.infolist()
        entries = {item.filename: item for item in listing}
        if any(sum(item.filename == name for item in listing) != 1 for name in ('project.json', 'raw.npy')):
            raise ValueError('项目缺少记录或图像，或含有重复条目。')
        with archive.open('raw.npy') as raw_stream:
            version = np.lib.format.read_magic(raw_stream)
            if version == (1, 0):
                shape, fortran, dtype = np.lib.format.read_array_header_1_0(raw_stream)
            elif version == (2, 0):
                shape, fortran, dtype = np.lib.format.read_array_header_2_0(raw_stream)
            else:
                raise ValueError('项目内原始图像的 NPY 版本不受支持。')
            if dtype.hasobject or dtype.kind not in 'buif' or dtype.itemsize > 8:
                raise ValueError('项目内原始图像必须是数值像素数组。')
            if len(shape) not in (2, 3) or any(not isinstance(n, int) or n <= 0 for n in shape):
                raise ValueError('项目内图像尺寸无效。')
            dimensions = shape
            if len(shape) == 3:
                if shape[-1] in (1, 3, 4):
                    dimensions = shape[:2]
                elif shape[0] in (1, 3, 4):
                    dimensions = shape[1:]
                else:
                    raise ValueError('项目内图像不是二维灰度或 RGB 图像。')
            if math.prod(dimensions) > MAX_PIXELS:
                raise ValueError('项目图像超过 1.5 亿像素，请拆分项目。')
            raw_bytes = math.prod(shape) * dtype.itemsize
            if raw_stream.tell() + raw_bytes != entries['raw.npy'].file_size:
                raise ValueError('项目内原始图像长度与尺寸记录不一致，文件可能不完整。')
            check_memory(entries['project.json'].file_size, raw_bytes)
            check_cancel(cancel); progress(12, '解压分析记录与人工复核信息')
            with archive.open('project.json') as doc_stream:
                with io.TextIOWrapper(doc_stream, encoding='utf-8-sig') as text_stream:
                    doc = json.load(text_stream)
            if not isinstance(doc, dict) or doc.get('format') != 'facc-project' or doc.get('format_version') not in (1, 2, 3, 4):
                raise ValueError('此项目格式版本不受支持。')
            if not isinstance(doc.get('candidates'), list) or not isinstance(doc.get('parameters'), dict):
                raise ValueError('项目中的编号或参数记录不完整。')
            check_cancel(cancel); progress(35, '解压原始图像')
            raw = np.empty(shape, dtype=dtype, order='F' if fortran else 'C')
            pixels = memoryview(raw.ravel(order='K')).cast('B')
            for offset in range(0, raw_bytes, 4 * 1024**2):
                check_cancel(cancel)
                chunk = pixels[offset:min(offset + 4 * 1024**2, raw_bytes)]
                if raw_stream.readinto(chunk) != len(chunk):
                    raise ValueError('项目内原始图像不完整。')
                progress(35 + int(40 * (offset + len(chunk)) / raw_bytes), '解压原始图像')
            if raw_stream.read(1):
                raise ValueError('项目内原始图像长度异常。')
    check_cancel(cancel)
    return doc, raw
