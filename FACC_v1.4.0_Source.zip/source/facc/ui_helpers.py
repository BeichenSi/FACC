from pathlib import Path
from PySide6.QtCore import QObject, QEvent, Qt, QSize
from PySide6.QtWidgets import QLabel, QWidget, QApplication

IMAGE_SUFFIXES = {'.tif', '.tiff', '.png', '.jpg', '.jpeg', '.bmp'}


class ElidedLabel(QLabel):
    """Long image names stay on one line; the tooltip retains the complete name."""
    def __init__(self, text='', parent=None):
        self.full_text = text
        super().__init__('', parent)
        self.setMinimumWidth(0)
        self.setText(text)

    def setText(self, text):
        self.full_text = str(text)
        self.setToolTip(self.full_text)
        self._update_text()

    def _update_text(self):
        super().setText(self.fontMetrics().elidedText(self.full_text, Qt.TextElideMode.ElideMiddle, max(0, self.contentsRect().width())))

    def resizeEvent(self, event):
        super().resizeEvent(event); self._update_text()

    def sizeHint(self):
        return QSize(240, self.fontMetrics().height()+4)

    def minimumSizeHint(self):
        return QSize(0, self.fontMetrics().height()+4)


class FileDropFilter(QObject):
    """Accept local files across the window, including spin boxes and the canvas."""
    def __init__(self, window):
        super().__init__(window)
        self.window = window
        QApplication.instance().installEventFilter(self)

    @staticmethod
    def paths(mime):
        if not mime.hasUrls(): return []
        urls = mime.urls()
        if not urls or any(not u.isLocalFile() for u in urls): return []
        paths = [u.toLocalFile() for u in urls]
        suffixes = [Path(p).suffix.lower() for p in paths]
        if len(paths) == 1 and suffixes[0] == '.facc': return paths
        return paths if all(s in IMAGE_SUFFIXES for s in suffixes) else []

    def eventFilter(self, watched, event):
        types = (QEvent.Type.DragEnter, QEvent.Type.DragMove, QEvent.Type.Drop)
        if event.type() not in types or not isinstance(watched, QWidget): return False
        if watched.window() is not self.window: return False
        paths = self.paths(event.mimeData())
        if not paths or self.window._busy:
            event.ignore()
            if self.window._busy: self.window.statusBar().showMessage('正在处理图像，请完成或取消后再拖入文件。')
            return True
        event.setDropAction(Qt.DropAction.CopyAction); event.accept()
        if event.type() == QEvent.Type.Drop: self.window.drop_files(paths)
        return True
