import json
import csv
from pathlib import Path
import time
import numpy as np
from .demo import membrane_demo
from .image_io import from_array, load_image
from .engine import count_cells
from .models import Parameters
from .storage import save_project, load_project, export_bundle


def require(condition, message):
    # Keep checks active in optimized, frozen executables as well as in source runs.
    if not condition:
        raise AssertionError(message)


def finish_worker(app, window, timeout=45):
    deadline = time.monotonic() + timeout
    while window._busy and time.monotonic() < deadline:
        app.processEvents(); time.sleep(.02)
    require(not window._busy, 'GUI worker timed out')
    app.processEvents()


def send_file_drop(app, target, paths):
    from PySide6.QtCore import QMimeData, QUrl, QPoint, QPointF, Qt
    from PySide6.QtGui import QDragEnterEvent, QDropEvent
    mime=QMimeData(); mime.setUrls([QUrl.fromLocalFile(str(p)) for p in paths])
    enter=QDragEnterEvent(QPoint(15,15),Qt.DropAction.CopyAction,mime,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier)
    app.sendEvent(target,enter)
    if not enter.isAccepted(): return False
    drop=QDropEvent(QPointF(15,15),Qt.DropAction.CopyAction,mime,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier)
    app.sendEvent(target,drop)
    return drop.isAccepted()


def verify_layouts(app, window, output):
    from PySide6.QtWidgets import QComboBox
    layouts=[]
    for width,height in ((1500,980),(1180,720),(900,600),(760,500)):
        window.resize(width,height)
        for _ in range(4): app.processEvents()
        require(window.width()<=width and window.height()<=height,'Window minimum size exceeds requested layout')
        require(window._compact == (width<1250),'Adaptive sidebar mode mismatch')
        if window._compact: window.side_tabs.setCurrentWidget(window.params_panel)
        for key,control in window.parameter_widgets.items():
            window.show_parameter(key)
            for _ in range(3): app.processEvents()
            if isinstance(control,QComboBox):
                need=control.fontMetrics().horizontalAdvance(control.currentText())+36
                require(control.width()>=need,f'Combo text clipped: {key} at {width}')
            elif hasattr(control,'lineEdit'):
                edit=control.lineEdit(); need=edit.fontMetrics().horizontalAdvance(edit.text())+4
                require(edit.width()>=need,f'Number or units clipped: {key} at {width}')
        window.parameter_tabs.setCurrentIndex(0); window.params_scroll.verticalScrollBar().setValue(0)
        app.processEvents(); window.grab().save(str(output/f'FACC_layout_{width}x{height}.png'))
        if window._compact:
            window.side_tabs.setCurrentWidget(window.review_panel); app.processEvents()
            require(window.review_panel.width()>=250,'Review panel inaccessible')
        layouts.append({'width':width,'height':height,'compact_tabs':window._compact,'text_fit':True})
    return layouts


def smoke_test(output, sample=None, central_sample=False,recovery_sample=False, projects=None):
    """Runs the installed application, including its GUI and bundled libraries."""
    output = Path(output); output.mkdir(parents=True, exist_ok=True)
    import os
    os.environ['FACC_DATA_DIR'] = str(output / 'test_preferences')
    raw, centers = membrane_demo()
    image = from_array(raw, 'FACC_demo_12.png')
    params = Parameters(largest_tissue=False)
    result = count_cells(image, params)
    if result.count != len(centers):
        raise AssertionError(f'Demo expected {len(centers)} closed profiles, got {result.count}')
    path = output / 'roundtrip.facc'
    save_project(path, image, result)
    restored_image, restored_result = load_project(path)
    require(np.array_equal(image.raw, restored_image.raw), 'Project pixel roundtrip failed')
    require([c.to_dict() for c in result.candidates] == [c.to_dict() for c in restored_result.candidates], 'Project candidates roundtrip failed')
    demo_export = export_bundle(image, result, output)
    from PIL import Image
    require(np.array_equal(load_image(Path(demo_export) / 'numbered.tif').raw,
                           np.array(Image.open(Path(demo_export) / 'numbered.png'))), 'LZW TIFF reload failed')
    report = {'demo_expected': len(centers), 'demo_count': result.count, 'project_roundtrip': True, 'lzw_tiff_reload': True, 'demo_export': demo_export}
    require(all(len(c.intensity.get('measurements',[]))==2 for c in result.candidates),'Internal/boundary intensities missing')
    if sample:
        image = load_image(sample)
        result = count_cells(image, Parameters(central_enabled=central_sample,recovery_enabled=recovery_sample, intensity_channel='all' if central_sample or recovery_sample else 'counting'))
        report.update(sample_name=image.name, sample_count=result.count, sample_pending=result.review_count, sample_seconds=result.metadata['elapsed_seconds'])
        report['sample_export'] = export_bundle(image, result, output)
        if central_sample:
            from .central_nuclei import central_summary
            report['sample_central'] = central_summary(result)
        if recovery_sample:
            from .recovery import recovery_summary
            report['sample_recovery']=recovery_summary(result)
    from PySide6.QtWidgets import QApplication, QFileDialog, QMessageBox
    from .storage import asset_path
    from .gui import MainWindow
    app = QApplication.instance() or QApplication([])
    window = MainWindow(); window.resize(1500, 980); window.show()
    window.set_parameters(result.parameters);window._image_loaded(image); window._counted(result); window.dirty = False
    for _ in range(5): app.processEvents(); time.sleep(.05)
    window.view.fit_image(); app.processEvents()
    if window.total_label.text().replace(',', '') != str(result.count): raise AssertionError('GUI count mismatch')
    if not window.grab().save(str(output / 'FACC_overview.png')): raise AssertionError('GUI screenshot failed')
    # Exercise editing on live widgets, then restore the original result.
    before = result.count
    window.add_candidate(5, 5); require(window.result.count == before + 1, 'GUI add failed')
    new_id = window.selected_id
    window.move_candidate(new_id, 10, 10); require(window.result.candidates[-1].x == 10, 'GUI move failed')
    window.confirm_selected(); require(window.result.candidates[-1].state == 'confirmed', 'GUI confirmation failed')
    window.delete_selected(); require(window.result.count == before, 'GUI delete failed')
    window.undo(); require(window.result.count == before + 1, 'GUI undo failed')
    while window.undo_stack: window.undo()
    require(window.result.count == before, 'GUI undo restoration failed')
    if result.candidates:
        choice = result.candidates[min(600, len(result.candidates)-1)].id
        window.select_candidate(choice, True); app.processEvents()
        window.grab().save(str(output / 'FACC_detail.png'))
        window.original_check.setChecked(True); app.processEvents(); window.original_check.setChecked(False)
    report['window_layouts']=verify_layouts(app,window,output)
    window.dirty = False
    gui_errors = []
    window._error = lambda message: gui_errors.append(message)
    window.open_demo(); finish_worker(app, window)
    require(not gui_errors and window.image is not None, 'Demo menu load failed')
    require(not window.get_parameters().largest_tissue, 'Demo parameters not applied')
    window.start_count(); finish_worker(app, window)
    require(not gui_errors and window.result is not None and window.result.count == 12, 'GUI demo count failed')
    window.dirty=False
    require(send_file_drop(app,window.view.viewport(),[asset_path('demo_membrane.png')]),'Image drag/drop rejected')
    finish_worker(app,window)
    require(not gui_errors and window.result.count==12,'Drop did not automatically analyze image')
    window.dirty=False
    require(send_file_drop(app,window,[path]),'Project drag/drop rejected')
    finish_worker(app,window)
    require(not gui_errors and window.result.count==12,'Dropped project failed to restore')
    require(not send_file_drop(app,window,[output/'unsupported.txt']),'Unsupported file accepted')
    window._busy=True
    require(not send_file_drop(app,window,[asset_path('demo_membrane.png')]),'Busy window accepted replacement drop')
    window._busy=False
    # Exercise the actual batch worker; a failed input must not block a later valid image.
    batch_folder = output / 'batch'; batch_folder.mkdir(exist_ok=True)
    original_files, original_folder, original_info = QFileDialog.getOpenFileNames, QFileDialog.getExistingDirectory, QMessageBox.information
    demo_path = str(asset_path('demo_membrane.png'))
    try:
        QFileDialog.getOpenFileNames = lambda *a, **k: ([demo_path, str(output / 'missing_input.tif'), demo_path], '')
        QFileDialog.getExistingDirectory = lambda *a, **k: str(batch_folder)
        QMessageBox.information = lambda *a, **k: QMessageBox.StandardButton.Ok
        require(send_file_drop(app,window,[demo_path,output/'missing_input.tif',demo_path]),'Multiple-image drop rejected')
        finish_worker(app, window)
    finally:
        QFileDialog.getOpenFileNames, QFileDialog.getExistingDirectory, QMessageBox.information = original_files, original_folder, original_info
    require(not gui_errors, f'GUI errors: {gui_errors}')
    batch_reports = sorted(batch_folder.glob('FACC_batch_*.csv'))
    require(bool(batch_reports), 'Batch summary missing')
    with batch_reports[-1].open(encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    require(len(rows) == 3, 'Batch did not process all inputs')
    require(rows[0]['候选总数'] == '12' and rows[2]['候选总数'] == '12', 'Batch successful count mismatch')
    require(rows[1]['状态'].startswith('失败'), 'Batch did not record failed input')
    require(rows[0]['结果文件夹'] != rows[2]['结果文件夹'], 'Batch overwrote repeated filename')
    # Exact synthetic biology rule: three nuclei in two of twelve fibers.
    from .central_nuclei import central_summary, fiber_status
    raw, centers = membrane_demo(); raw = raw.copy()
    yy, xx = np.mgrid[:raw.shape[0], :raw.shape[1]]
    for x,y in [(90,100),(110,100),(255,100),(30,30)]:
        raw[(xx-x)**2+(yy-y)**2 <= 5**2, 2] = 245
    central_image=from_array(raw,'central_demo_12.png')
    central_params=Parameters(central_enabled=True,largest_tissue=False)
    central_result=count_cells(central_image,central_params)
    require(central_summary(central_result)['central_fibers']==2 and central_result.count==12,'Central synthetic count should be 2 fibers, not 3 nuclei')
    require(sum(len(c.central_nuclei['nuclei']) for c in central_result.candidates)==3,'Internal nucleus assignment failed')
    central_path=output/'central_roundtrip.facc'; save_project(central_path,central_image,central_result)
    ci,cr=load_project(central_path);require(central_summary(cr)==central_summary(central_result),'Central project roundtrip failed')
    report['central_demo_export']=export_bundle(central_image,central_result,output)
    window._image_loaded(ci);window._counted(cr);window.dirty=False
    require(window.central_count_label.text()=='2' and window.central_ratio_label.text()=='16.67%','Central GUI statistics mismatch')
    positive=next(c for c in cr.candidates if fiber_status(c)=='positive')
    window.select_candidate(positive.id);window.classify_selected('negative')
    require(window.central_count_label.text()=='1','Central manual override not reflected')
    window.undo();require(window.central_count_label.text()=='2','Central undo failed')
    window.add_candidate(20,20)
    require(central_summary(window.result)['unclassified_fibers']==1 and not central_summary(window.result)['classification_complete'],'Manual point silently classified')
    window.undo();window.resize(1500,980);app.processEvents();window.view.fit_image()
    window.grab().save(str(output/'FACC_central_demo.png'))
    (output/'central_layouts').mkdir(exist_ok=True)
    report['central_window_layouts']=verify_layouts(app,window,output/'central_layouts')
    central_image_path=output/'central_demo.png';Image.fromarray(raw).save(central_image_path)
    window.set_parameters(central_params);window.dirty=False
    require(send_file_drop(app,window.view.viewport(),[central_image_path]),'Central image drop rejected')
    finish_worker(app,window)
    require(not gui_errors and central_summary(window.result)['central_fibers']==2,'Central image drop analysis failed')
    report.update(central_multinuclear_rule=True,central_project_roundtrip=True,central_gui_override_undo=True,central_manual_unclassified=True,central_drag_drop=True)
    from .demo import recovery_demo
    from .recovery import recovery_summary,recovery_status
    raw,_=recovery_demo();ri=from_array(raw,'FACC_recovery_demo.png')
    rp=Parameters(recovery_enabled=True,largest_tissue=False,recovery_threshold=60,intensity_channel='all')
    rr=count_cells(ri,rp);require(rr.count==12 and recovery_summary(rr)['recovered_fibers']==2,'Recovery membrane classification failed')
    report['recovery_demo_export']=export_bundle(ri,rr,output)
    window.set_parameters(rp);window._image_loaded(ri);window._counted(rr);window.dirty=False
    require(window.recovery_count_label.text()=='2' and window.recovery_ratio_label.text()=='16.67%','Recovery GUI ratio failed')
    positive=next(c for c in rr.candidates if recovery_status(c)=='positive')
    window.select_candidate(positive.id);window.classify_selected('negative')
    require(window.recovery_count_label.text()=='1','Recovery manual override failed');window.undo()
    require(window.recovery_count_label.text()=='2','Recovery undo failed')
    window.add_candidate(20,20);require(recovery_summary(window.result)['unclassified_fibers']==1,'Manual recovery point falsely classified');window.undo()
    window.central_filter.setCurrentIndex(window.central_filter.findData('positive'));require(window.table.rowCount()==2,'Recovery filter changed candidate list incorrectly')
    window.central_filter.setCurrentIndex(0);window.resize(1500,980);app.processEvents();window.view.fit_image();window.grab().save(str(output/'FACC_recovery_demo.png'))
    (output/'recovery_layouts').mkdir(exist_ok=True);report['recovery_window_layouts']=verify_layouts(app,window,output/'recovery_layouts')
    ip=output/'recovery_demo.png';Image.fromarray(raw).save(ip);window.dirty=False
    require(send_file_drop(app,window.view.viewport(),[ip]),'Recovery drag rejected');finish_worker(app,window)
    require(recovery_summary(window.result)['recovered_fibers']==2,'Recovery drag analysis failed')
    report.update(recovery_membrane_rule=True,recovery_manual_override_undo=True,recovery_manual_unclassified=True,recovery_drag_drop=True,recovery_filter=True)
    from .qa_settings import verify_settings, verify_large_projects
    report['settings'] = verify_settings(app, window, output)
    if projects: report['large_projects'] = verify_large_projects(app, window, output, projects)
    window.dirty = False; window.close(); app.processEvents()
    report.update(gui_rendered=True, gui_edit_undo=True, gui_demo_count=12,
                  gui_batch_successful=2, gui_batch_expected_failure=1, drag_drop_image=True,
                  drag_drop_project=True, drag_drop_batch=True, raw_intensity_regions=True, errors=[])
    (output / 'smoke_test.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    return report
