# -*- mode: python ; coding: utf-8 -*-
from pathlib import Path
import os
import sys
from PyInstaller.utils.hooks import collect_submodules
root = Path(SPEC).resolve().parent
# Avoid unrelated applications' identically named DLLs on a development machine's PATH.
# Qt's Windows ICU dependency must resolve to Windows, not a Poppler/Conda ICU build.
windows_root = Path(os.environ.get('SystemRoot', r'C:\Windows'))
os.environ['PATH'] = os.pathsep.join([str(Path(sys.executable).parent), str(Path(sys.base_prefix)), str(windows_root / 'System32'), str(windows_root)])
hidden = []
for package in ('skimage.morphology', 'skimage.measure', 'skimage.feature', 'skimage.filters', 'skimage.segmentation', 'skimage.transform'):
    hidden += collect_submodules(package, filter=lambda name: '.tests' not in name)
a = Analysis(
    [str(root / 'main.py')], pathex=[str(root)],
    binaries=[], datas=[(str(root / 'assets'), 'assets'), (str(root / 'docs'), 'docs'),
                       (str(root / 'ThirdPartyLicenses'), 'ThirdPartyLicenses'),
                       (str(root / 'THIRD_PARTY_NOTICES.md'), '.')],
    hiddenimports=hidden + ['PIL.TiffImagePlugin'],
    hookspath=[], hooksconfig={}, runtime_hooks=[],
    excludes=['matplotlib', 'pandas', 'IPython', 'pytest', 'tkinter', 'PySide6.QtQml', 'PySide6.QtQuick', 'PySide6.QtSql', 'PySide6.QtTest', 'PySide6.QtWebEngineCore', 'PySide6.QtWebEngineWidgets'],
    noarchive=False, optimize=1,
)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name='FACC', debug=False,
          bootloader_ignore_signals=False, strip=False, upx=False, console=False,
          disable_windowed_traceback=False, icon=str(root / 'assets' / 'facc.ico'),
          version=str(root / 'version_info.txt'))
cli = EXE(pyz, a.scripts, [], exclude_binaries=True, name='FACC-cli', debug=False,
          bootloader_ignore_signals=False, strip=False, upx=False, console=True,
          icon=str(root / 'assets' / 'facc.ico'), version=str(root / 'version_info.txt'))
coll = COLLECT(exe, cli, a.binaries, a.datas, strip=False, upx=False, name='FACC')
