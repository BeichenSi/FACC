from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from facc.demo import membrane_demo, bright_demo
import tifffile
import json
from dataclasses import asdict
from facc.models import Parameters

root=Path(__file__).parent
assets=root/'assets'; assets.mkdir(exist_ok=True)
icon=Image.new('RGBA',(256,256),(0,0,0,0)); d=ImageDraw.Draw(icon)
d.rounded_rectangle((6,6,250,250),radius=48,fill='#142638',outline='#45697b',width=4)
for box,color in [((34,38,117,125),'#8be3c9'),((133,38,216,125),'#8be3c9'),((34,140,117,226),'#8be3c9'),((133,140,216,226),'#ffbd71')]:
    d.rounded_rectangle(box,radius=28,outline=color,width=6)
font=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf',35)
for i,(x,y) in enumerate([(76,82),(176,82),(76,184),(176,184)],1): d.text((x,y),str(i),font=font,anchor='mm',fill='#f4faff')
icon.save(assets/'facc.ico',sizes=[(16,16),(24,24),(32,32),(48,48),(64,64),(128,128),(256,256)])
icon.save(assets/'facc_icon.png')
raw,centers=membrane_demo(); Image.fromarray(raw).save(assets/'demo_membrane.png')
raw,centers=bright_demo(); tifffile.imwrite(assets/'demo_bright_16bit.tif',raw)
(assets/'default_parameters.json').write_text(json.dumps(asdict(Parameters()),indent=2),encoding='utf-8')
(assets/'demo_parameters.json').write_text(json.dumps(asdict(Parameters(largest_tissue=False)),indent=2),encoding='utf-8')
print('Assets prepared')
