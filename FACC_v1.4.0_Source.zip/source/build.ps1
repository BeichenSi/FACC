$ErrorActionPreference = 'Stop'
$faccRoot = $PSScriptRoot
$faccVenv = Join-Path $faccRoot '.venv'
$faccPython = Join-Path $faccVenv 'Scripts\python.exe'
if (-not (Test-Path -LiteralPath $faccPython)) {
    py -3.12 -m venv $faccVenv
    if ($LASTEXITCODE -ne 0) { throw 'Python 3.12 environment creation failed.' }
}
& $faccPython -m pip install -r (Join-Path $faccRoot 'requirements-build.txt')
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
$env:PYTHONPATH = $faccRoot
& $faccPython -m unittest discover -s (Join-Path $faccRoot 'tests') -v
if ($LASTEXITCODE -ne 0) { throw 'Validation failed.' }
& $faccPython -m PyInstaller --noconfirm --clean --workpath (Join-Path $faccRoot 'build') --distpath (Join-Path $faccRoot 'dist') (Join-Path $faccRoot 'FACC.spec')
if ($LASTEXITCODE -ne 0) { throw 'Packaging failed.' }
Copy-Item -LiteralPath (Join-Path $faccRoot 'README.md'),(Join-Path $faccRoot 'THIRD_PARTY_NOTICES.md') -Destination (Join-Path $faccRoot 'dist\FACC') -Force
Write-Host ('Portable application: ' + (Join-Path $faccRoot 'dist\FACC\FACC.exe'))
